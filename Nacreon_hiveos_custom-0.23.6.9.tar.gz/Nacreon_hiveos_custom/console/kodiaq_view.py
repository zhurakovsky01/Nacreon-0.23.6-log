"""Compact console view: header, one row per GPU, event feed (alex_kodiaq edit).

Original miner and console: Nacreon by liked. This view, the event feed,
the pool reject reasons and logging are alex_kodiaq's changes. All values come
from the existing console data; nothing here touches the miner or the GPUs.
"""
import collections, json, re, subprocess, threading, time

from branding import label, DEVELOPER, EDITOR, EDITION
from design import S, L, number, duration
from local_clock import clock, day
import reject_reasons

FEED_LIMIT = 400
_lock = threading.Lock()
_feed = collections.deque(maxlen=FEED_LIMIT)   # (wall, order, parts)
_order = [0]
_pending = {}                                    # submit id -> wall time sent
_last_share_wall = [None]


_last_reject = [None]   # dict(wall, rid, kind, device, fallback)


def _add(wall, parts, meta=None):
    with _lock:
        _order[0] += 1
        _feed.append((wall, _order[0], parts, meta))


HINTS = {
    'STALE': 'опоздала: пул уже сменил задание',
    'INVALID': 'пул счёл шару неверной',
    'DUPLICATE': 'повтор уже отправленной шары',
}


def _reason(meta):
    rid = meta.get('rid')
    text = reject_reasons.lookup(rid) if type(rid) is int else None
    text = label(text or meta.get('fallback') or '', 60)
    hint = HINTS.get(meta.get('kind'))
    return text + (' — ' + hint if hint else '')


def _stamp(wall):
    return S('[' + day(wall) + ' ' + clock(wall) + '] ', 'dim')


# ---------------------------------------------------------------- raw native lines

NOTIFY = b'[pool-raw] {'
SIMPLE = (
    (b'[net] connection lost', 'пул: связь потеряна', 'red'),
    (b'[pool] Connection lost', 'пул: связь потеряна', 'red'),
    (b'[net] TLS certificate/name verification or handshake failed', 'пул: ошибка TLS / подключения', 'red'),
    (b'[net] pool authorize', 'пул: подключение и авторизация', 'cyan'),
    (b'[net] user session connector stopped', 'пул: сессия остановлена', 'yellow'),
)
PATTERNS = (
    (re.compile(rb'\[plain\] stale share nonce=\d+ dropped'), 'шара устарела до отправки (сменилось задание)', 'yellow'),
    (re.compile(rb'\[plain\] verify failed'), 'ошибка: доказательство не прошло проверку', 'red'),
    (re.compile(rb'\[plain\] proof build failed'), 'ошибка: не удалось собрать доказательство', 'red'),
    (re.compile(rb'\[plain\] submit failed'), 'ошибка: шара не отправлена', 'red'),
    (re.compile(rb'\[net\] proof gzip failed'), 'ошибка: сжатие доказательства', 'red'),
    (re.compile(rb'\[plain\] OOM'), 'ошибка: не хватило памяти', 'red'),
)
SUBMIT = re.compile(rb'\[net\] plain_proof submit id=(\d+) ')
DIFF = re.compile(rb'\[pool\] mining\.set_difficulty ([0-9.]+)')


def observe(raw):
    """Feed every native output line; never raises."""
    try:
        now = time.time()
        m = SUBMIT.match(raw)
        if m:
            with _lock:
                _pending[int(m.group(1))] = now
                while len(_pending) > 64:
                    _pending.pop(next(iter(_pending)))
            return
        if raw.startswith(NOTIFY) and b'mining.notify' in raw:
            body = json.loads(raw[len(b'[pool-raw] '):].decode('utf-8', 'replace'))
            p = body.get('params') or {}
            job = label(p.get('job_id') or '?', 24)
            height = p.get('height')
            text = 'новое задание ' + job + ('' if height is None else '  · высота ' + str(height))
            _add(now, [S(text, 'blue')])
            return
        m = DIFF.match(raw)
        if m:
            _add(now, [S('пул: сложность ' + m.group(1).decode(), 'cyan')])
            return
        for prefix, text, color in SIMPLE:
            if raw.startswith(prefix):
                _add(now, [S(text, color, color == 'red')])
                return
        for pattern, text, color in PATTERNS:
            if pattern.match(raw):
                _add(now, [S(text, color, color == 'red')])
                return
    except Exception:
        return


def share_event(event):
    """Native ledger share result (accepted or rejected) -> feed line."""
    try:
        observed = event.get('observed_at')
        wall = time.time() - max(0.0, time.monotonic() - observed) if isinstance(observed, (int, float)) else time.time()
        rid = event.get('id')
        latency = event.get('latency_ms')
        device = event.get('device')
        gpu = 'GPU' + (str(device) if device is not None else '?') + '  '
        lat = S('[' + (number(latency, 0) if latency is not None else '—').rjust(4) + ' мс]  ', 'dim')
        if event.get('category') == 'accepted':
            _last_share_wall[0] = wall
            _add(wall, [S(gpu, 'text'), S('шара принята    ', 'green', True), lat, S('#' + str(rid), 'dim')])
        else:
            kind = label(event.get('category') or 'отказ', 12).upper()
            meta = dict(rid=rid, fallback=event.get('error'), kind=kind, device=device, wall=wall)
            _last_reject[0] = meta
            _add(wall, [S(gpu, 'text'), S(('ОТКАЗ ' + kind).ljust(16), 'red', True), lat,
                        S('#' + str(rid) + '  ', 'dim'), None], meta)
    except Exception:
        return


# ---------------------------------------------------------------- slow samplers

_gpu_info = {}          # uuid(lower) -> (pci, memory_gb)
_samplers_started = [False]


def _sample_gpu_info():
    try:
        out = subprocess.run(['nvidia-smi', '--query-gpu=uuid,pci.bus_id,memory.total', '--format=csv,noheader,nounits'],
                             stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=3).stdout
        found = {}
        for row in out.splitlines():
            parts = [p.strip() for p in row.split(',')]
            if len(parts) != 3:
                continue
            uuid, bus, mem = parts
            m = re.search(r'([0-9A-Fa-f]{2}):([0-9A-Fa-f]{2})\.([0-7])$', bus)
            pci = (m.group(1) + ':' + m.group(2)).lower() if m else '—'
            try:
                gb = round(float(mem) / 1024)
            except ValueError:
                gb = None
            found[uuid.lower()] = (pci, gb)
        if found:
            _gpu_info.clear()
            _gpu_info.update(found)
    except Exception:
        return


def _sampler():
    while True:
        _sample_gpu_info()
        time.sleep(60)


def start_samplers():
    if _samplers_started[0]:
        return
    _samplers_started[0] = True
    threading.Thread(target=_sampler, name='kodiaq-samplers', daemon=True).start()


# ---------------------------------------------------------------- rendering

def _cell(text, width, color='text', bold=False, right=True):
    text = label(text, 64)
    if len(text) > width:
        text = text[:max(0, width - 1)] + '…'
    return S(text.rjust(width) if right else text.ljust(width), color, bold)


def _row(*cells):
    out = []
    for i, c in enumerate(cells):
        if i:
            out.append(S('  '))
        out.append(c)
    return L(*out)


def _short_name(name):
    name = (name or 'UNKNOWN').removeprefix('NVIDIA ').removeprefix('GeForce ')
    return name.replace('RTX ', '')


def _total(values):
    vals = [v for v in values if v is not None]
    return sum(vals) if vals else None


def build(data, height=40, width=124, notes=()):
    start_samplers()
    s = data['snapshot']
    detail = s.get('detail', {})
    cards = s.get('cards', {})
    rates = data.get('rates') or {}
    counts = data.get('counts') or {}
    now = data['now']
    wall_now = time.time()
    live = s.get('running') and not data.get('stale')
    width = max(90, min(width, 160))

    a = counts.get('accepted') if counts else None
    r = counts.get('rejected') if counts else None
    n = (a or 0) + (r or 0)
    share_pct = 100.0 * a / n if a is not None and n else None
    averages = data.get('averages') or {}
    h1 = _total((averages.get(3600) or {}).values())
    h24 = _total((averages.get(86400) or {}).values())
    session = (data.get('session_metrics') or {}).get('mean_rate')
    job_age = detail.get('job_age_seconds')
    share_age = wall_now - _last_share_wall[0] if _last_share_wall[0] else None
    reconnects = None
    count = s.get('connection_count')
    if type(count) is int and count >= 1 and not data.get('stale'):
        reconnects = count - 1
    status = s.get('connection_status', 'UNKNOWN')
    status_color = 'green' if live and status == 'ESTABLISHED' else 'yellow'

    rows = []
    # ---- header: labelled fields, fixed columns
    if width >= 140:
        c1, c2, c3 = 34, 46, 32
    else:
        c1, c2, c3 = 32, 38, 24
    c4 = max(20, width - c1 - c2 - c3 - 6)
    gap = S('  ')
    def field(name, value, w, color='text', bold=False):
        text = name + ': ' + value
        if len(text) > w:
            text = text[:max(0, w - 1)] + '…'
        return [S(name + ': ', 'dim'), S(text[len(name) + 2:].ljust(w - len(name) - 2), color, bold)]
    def fields(items, w):
        out, used = [], 0
        for i, (name, value, color) in enumerate(items):
            sep = '  ' if i else ''
            out += [S(sep + name + ': ', 'dim'), S(value, color)]
            used += len(sep + name + ': ' + value)
        out.append(S(' ' * max(0, w - used)))
        return out
    title = 'Nacreon ' + label(s.get('version') or '?', 16) + ' · автор ' + DEVELOPER
    pct_color = 'green' if share_pct is None or share_pct >= 99 else 'yellow' if share_pct >= 97 else 'red'
    pool_text = label(detail.get('pool') or '—', 40) + (' · НЕТ СВЯЗИ' if status == 'DISCONNECTED' else ' · TCP')
    pool_color = 'green' if live and status == 'ESTABLISHED' else 'red' if status == 'DISCONNECTED' else 'yellow'
    ack = detail.get('mean_recent_ACK_latency_ms')
    parts = [(k, counts.get(k)) for k in ('stale', 'invalid', 'duplicate')] if counts else []
    other = (r or 0) - sum(v or 0 for _, v in parts)
    if other > 0:
        parts.append(('other', other))
    detail_rejects = ', '.join(k + ' ' + str(v) for k, v in parts if v)
    if len('Отказы: ' + str(r) + ' (' + detail_rejects + ')') > c3:
        short = {'stale': 'S', 'invalid': 'I', 'duplicate': 'D', 'other': 'O'}
        detail_rejects = ' '.join(short[k] + ':' + str(v) for k, v in parts if v)
    rejects_text = '—' if r is None else str(r) + (' (' + detail_rejects + ')' if r and detail_rejects else '')
    rows.append(L(_cell(title, c1, 'cyan', True, False), gap,
                  *field('Пул', pool_text, c2, pool_color), gap,
                  *field('Отказы', rejects_text, c3, 'red' if r else 'dim', bool(r)), gap,
                  *field('Принято', number(share_pct, 1) + '%' if share_pct is not None else '—', c4, pct_color, True)))
    rows.append(L(_cell('изм. и лог: ' + EDITOR + ' ' + EDITION, c1, 'dim', False, False), gap,
                  *fields([('Задание', number(job_age, 0) + ' с' if job_age is not None else '—', 'text'),
                           ('Шара', number(share_age, 0) + ' с' if share_age is not None else '—', 'text'),
                           ('Обрывов', str(reconnects) if reconnects is not None else '—', 'red' if reconnects else 'text')], c2), gap,
                  *field('Ответ пула', number(ack, 0) + ' мс' if ack is not None else '—', c3,
                         'text' if ack is None or ack < 1500 else 'yellow'), gap,
                  *field('Работает', duration(now - data['started']) if data.get('started') is not None else '—', c4)))
    rows.append(L(S('─' * width, 'dim')))

    def centered(lines):
        out = []
        for line in lines:
            pad = max(0, (width - sum(len(t) for t, _, _ in line)) // 2)
            out.append(L(S(' ' * pad), *line))
        return out

    # ---- GPU table: bordered, every column centered
    import rich_design as rd
    wide = width >= 140
    if wide:
        widths = [3, 7, 10, 13, 9, 7, 15, 10, 6, 6, 14, 8]
        heads = ['GPU', 'PCI', 'Модель', 'Хешрейт TH/s', 'Принято', 'Откл.', 'Эффективность', 'Мощность', 'Темп', 'Вент', 'Ядро (смещ.)', 'Память']
    else:
        widths = [3, 5, 9, 9, 7, 5, 13, 7, 4, 4, 11, 6]
        heads = ['GPU', 'PCI', 'Модель', 'TH/s', 'Принято', 'Откл.', 'Эффективность', 'Мощн.', 'Темп', 'Вент', 'Ядро(смещ)', 'Память']
    table = [rd.border(widths, '┌', '┬', '┐'), rd.row(heads, widths, ['cyan'] * len(widths), range(len(widths)), center=True), rd.border(widths)]
    uuids = data.get('uuids') or {}
    shares = detail.get('per_gpu_shares') or {}
    for d in data.get('devices', []):
        card = cards.get(str(d), {})
        info = _gpu_info.get(str(uuids.get(d, '')).lower(), ('—', None))
        name = _short_name(card.get('name')) + (' ' + str(info[1]) + 'G' if info[1] else '')
        speed = rates.get(d)
        mean = (data.get('mean_power') or {}).get(d)
        eff = speed / mean if speed is not None and mean else None
        per = shares.get(str(d))
        try:
            import core_offsets
            offset = core_offsets.verified(card)
        except Exception:
            offset = None
        core = number(card.get('core'), 0) + (' (' + f'{offset:+d}' + ')' if offset is not None else '')
        temp = card.get('temp')
        values = ['#' + str(d), info[0], name, number(speed), str(per['accepted']) if per else '—', str(per['rejected']) if per else '—',
                  number(eff, 3), number(card.get('power'), 0) + ' W', number(temp, 0) + '°', number(card.get('fan'), 0) + '%', core, number(card.get('memory'), 0)]
        colors = ['cyan', 'text', 'cyan', 'green', 'green', 'red' if per and per['rejected'] else 'dim', 'text', 'text',
                  'red' if temp is not None and temp >= 80 else 'text', 'text', 'text', 'text']
        table.append(rd.row(values, widths, colors, (3,), center=True))
    if len(data.get('devices', [])) > 1:
        speed = _total(rates.values())
        power = _total(cards.get(str(d), {}).get('power') for d in data.get('devices', []))
        mean = _total((data.get('mean_power') or {}).values())
        eff = speed / mean if speed is not None and mean else None
        table += [rd.border(widths), rd.row(['', '', 'ИТОГО', number(speed), str(a) if a is not None else '—', str(r) if r is not None else '—',
                                             number(eff, 3), number(power, 0) + ' W', '', '', '', ''], widths, ['yellow'] * len(widths), (2, 3), center=True)]
    table.append(rd.border(widths, '└', '┴', '┘'))
    rows += centered(table)

    # ---- CPU / RAM / disk gauges from the original console
    try:
        import host_gauges
        rows += host_gauges.host_gauge_lines(data, width)
    except Exception:
        pass

    # ---- period statistics: bordered, centered, with efficiency
    try:
        pw = [10, 14, 11, 15, 9, 7, 9]
        ph = ['Период', 'Средний TH/s', 'Средн. Вт', 'Эффективность', 'Принято', 'Откл.', 'Откл. %']
        ptable = [rd.border(pw, '┌', '┬', '┐'), rd.row(ph, pw, ['cyan'] * 7, range(7), center=True), rd.border(pw)]
        metrics = data.get('metrics') or {}
        for seconds, name in rd.PERIODS:
            sp = _total(((data.get('averages') or {}).get(seconds) or {}).values())
            m = metrics.get(seconds, {})
            watts = m.get('mean_power')
            eff = sp / watts if sp is not None and watts else None
            vals = [name, number(sp) if sp is not None else 'сбор данных', number(watts, 1), number(eff, 3),
                    rd.count(m.get('accepted')), rd.count(m.get('rejected')), number(m.get('rejected_percent'))]
            base = 'blue' if sp is not None else 'dim'
            cols = [base, base, base, base, 'green' if m.get('accepted') is not None else 'dim',
                    'red' if m.get('rejected') else 'dim', 'red' if m.get('rejected') else 'dim']
            ptable.append(rd.row(vals, pw, cols, (0, 1), center=True))
        m = data.get('session_metrics') or {}
        vals = ['За сеанс', number(m.get('mean_rate')), number(m.get('mean_power'), 1), number(m.get('efficiency'), 3),
                rd.count(m.get('accepted')), rd.count(m.get('rejected')), number(m.get('rejected_percent'))]
        ptable.append(rd.border(pw))
        ptable.append(rd.row(vals, pw, ['blue', 'blue', 'blue', 'blue', 'green', 'red' if m.get('rejected') else 'dim', 'red' if m.get('rejected') else 'dim'], (0, 1), center=True))
        ptable.append(rd.border(pw, '└', '┴', '┘'))
        rows += centered(ptable)
    except Exception:
        pass
    rows.append(L(S('─' * width, 'dim')))
    for text in list(notes)[-1:]:
        rows.append(L(S('консоль: ', 'yellow'), S(label(text, 110), 'dim')))

    last = _last_reject[0]
    if last:
        ago = wall_now - last['wall']
        rows.append(L(S('Последний отказ: ', 'red', True),
                      S(day(last['wall']) + ' ' + clock(last['wall']) + '  GPU' + str(last['device'] if last['device'] is not None else '?')
                        + '  ' + last['kind'] + '  ', 'red'),
                      S(_reason(last), 'red', True),
                      S('  · ' + __import__('rich_design').elapsed_age(ago) + ' назад', 'dim')))
    else:
        rows.append(L(S('Последний отказ: отказов за сеанс нет', 'dim')))
    space = max(0, height - 1 - len(rows))
    with _lock:
        feed = sorted(_feed, key=lambda e: (e[0], e[1]))[-space:] if space else []
    if not feed and space:
        rows.append(L(S('ожидание событий…', 'dim')))
    for wall, _, parts, meta in feed:
        parts = [p if p is not None else S(_reason(meta), 'red') for p in parts]
        rows.append(L(_stamp(wall), *parts))
    return rows
