"""alex_kodiaq: readable line log when the output is not a terminal.

Used for the oxzd `gpu_idle_command` (its output goes to /var/log/miner/custom/custom.log
through tee) and for pipes. One short line per event instead of ~27 telemetry lines a second:

  [2026/10/27 12:00:01 PRL] пул: авторизация OK
  [2026/10/27 12:00:02 PRL] задание 97f834f1 · высота 134518
  [2026/10/27 12:00:15 PRL] шара №1 принята [83 мс] · 431.2 TH/s
  [2026/10/27 12:01:02 PRL] ОТКАЗ STALE шара №2 (id 3) [1397 мс]: 21 stale-work
  [2026/10/27 12:02:00 PRL] итог: 430.8 TH/s · принято 57 · отказов 1 (stale 1) · ответ пула 85 мс · работает 00:02:00

Errors, faults and unknown lines are always shown (rate-limited per kind, never dropped
silently). Wording avoids the patterns oxzd's h-stats.sh parses ("Total |", "GPU0 [",
"Solution was accepted", "OXZD x.y.z").
"""
import collections, datetime, json, os, re, select, signal, statistics, sys, threading, time, importlib.util, pathlib

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
try:
    import local_clock
    ZONE = local_clock.ZONE
except Exception:
    ZONE = None
try:
    import branding
    EDITION = branding.EDITION
except Exception:
    EDITION = ''
try:
    from work_counter import advance
except Exception:
    def advance(previous, raw):
        if previous is not None and raw < previous:
            raise ValueError('counter went back')
        return raw

WORK_WINDOW = 30.0  # seconds, same window as the console table

SUMMARY_EVERY = int(os.environ.get('NACREON_LINE_SUMMARY', '60') or 60)
LIMIT_PER_MIN = 5  # visible unknown/diagnostic lines per kind per minute

QUIET_TYPES = {
    'native-device-work', 'native-device-idle', 'native-job-owner', 'native-job',
    'native-batch-timing', 'native-row-slice', 'native-row-admission', 'native-lazy-repack',
    'native-lazy-basis', 'native-input-prep', 'native-computation-cycle',
    'native-byte-conversion-admission', 'host-phase', 'compute-v1-public-preparation-chunk',
    'compute-v1-public-math-gate',
}
QUIET_TEXT = (
    re.compile(r'\[compute-resource\] '),
    re.compile(r'\[share-map\] '),
    re.compile(r'\[native-pool-response\] '),
    re.compile(r'\[v383-fence-occupancy\] '),
    re.compile(r'\[plain\] verify OK '),
    re.compile(r'\[plain\] share submitted; pool ack pending'),
    re.compile(r'\[net\] plain_proof submit sent '),
    re.compile(r'\[net\] pool reader started'),
    re.compile(r'\[net\] new job \S+ while mining'),
    re.compile(r'Developed by '),
)
PROOF = re.compile(r'\[plain\] proof ready .*\(hs=(\d+)\)')
SUBMIT = re.compile(r'\[net\] plain_proof submit id=(\d+) job=(\S+)')
VERSION = re.compile(r'Nacreon \| (\S+)\s*$')


class State:
    def __init__(self):
        self.lock = threading.Lock()
        self.started = time.time()
        self.number = 0
        self.pending = {}          # rpc id -> (share number, sent monotonic)
        self.accepted = 0
        self.kinds = {}            # reject kind -> count
        self.acks = []             # recent reply latencies, ms
        self.work = {}             # device -> deque of (miner monotonic s, lifetime completed MACs)
        self.hidden = 0
        self.budget = {}           # kind -> (window start, shown)
        self.activity = False


S = State()
OUT = sys.stdout.buffer
ALIVE = [True]
LOST = threading.Event()
BIN_DIR = str((HERE.parent / 'bin').resolve())


def miner_pid():
    """PID of this run's miner (h-run.sh exports it), only while it is still our Nacreon."""
    try:
        pid = int(os.environ.get('NACREON_EXPECTED_PID', ''))
    except ValueError:
        return None
    try:
        exe = os.readlink('/proc/%d/exe' % pid).replace(' (deleted)', '')
        argv = pathlib.Path('/proc/%d/cmdline' % pid).read_bytes().split(b'\0')
    except OSError:
        return None
    paths = [exe] + [os.path.realpath(a.decode('utf-8', 'replace')) for a in argv[1:2] if a]
    return pid if any(p.startswith(BIN_DIR + os.sep) for p in paths) else None


def stop_miner():
    """Nobody reads our output any more (oxzd stopped or died): stop the miner like a broken pipe would."""
    pid = miner_pid()
    if pid is None:
        return
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        return
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        time.sleep(0.5)
        if miner_pid() != pid:
            return
    try:
        os.kill(pid, signal.SIGKILL)
    except OSError:
        pass


def lost():
    if not LOST.is_set():
        LOST.set()
        ALIVE[0] = False
        threading.Thread(target=stop_miner, name='kodiaq-stop', daemon=True).start()


def output_watch(stop):
    """POLLERR on our stdout means the reading side (oxzd / its tee) is gone."""
    try:
        poller = select.poll()
        poller.register(sys.stdout.fileno(), select.POLLERR | select.POLLHUP)
    except (OSError, ValueError, AttributeError):
        return
    while not stop.wait(2):
        try:
            events = poller.poll(0)
        except (OSError, ValueError):
            return
        if events and events[0][1] & (select.POLLERR | select.POLLHUP):
            lost()
            return


def stamp(now=None):
    now = time.time() if now is None else now
    when = datetime.datetime.fromtimestamp(now, ZONE) if ZONE is not None else datetime.datetime.fromtimestamp(now)
    return when.strftime('%Y/%m/%d %H:%M:%S')


def emit(text):
    line = ('[' + stamp() + ' PRL] ' + text.rstrip('\r\n') + '\n').encode('utf-8', 'replace')
    with S.lock:
        if not ALIVE[0]:
            return
        try:
            OUT.write(line)
            OUT.flush()
            return
        except (OSError, ValueError):
            pass
    lost()  # keep draining the miner so it never blocks; stop it because nobody reads the output


def limited(kind, text):
    now = time.monotonic()
    with S.lock:
        start, shown = S.budget.get(kind, (now, 0))
        if now - start >= 60:
            start, shown = now, 0
        if shown >= LIMIT_PER_MIN:
            S.budget[kind] = (start, shown)
            S.hidden += 1
            return
        S.budget[kind] = (start, shown + 1)
    emit(text)


def clean(text, limit=160):
    return ''.join(c for c in str(text) if c.isprintable() and c != '\x1b')[:limit]


def ths(value):
    return format(value / 1e12, '.1f') + ' TH/s'


def record_work(record):
    """native-device-work: the same completed-work counter the console table uses for TH/s."""
    d, raw, t = record.get('device'), record.get('raw_completed_macs_total'), record.get('monotonic_seconds')
    if type(d) is not int or type(raw) is not int or not isinstance(t, (int, float)):
        return
    t = float(t)
    with S.lock:
        hist = S.work.setdefault(d, collections.deque())
        try:
            total = advance(hist[-1][1] if hist else None, raw)
        except ValueError:
            hist.clear()  # counter reset: start a fresh window
            total = raw
        hist.append((t, total))
        while len(hist) > 2 and hist[1][0] <= t - WORK_WINDOW:
            hist.popleft()


def work_rate():
    """Completed MACs per second over the last ~30 s, summed over GPUs (like the console table)."""
    total, seen = 0.0, False
    with S.lock:
        for hist in S.work.values():
            if len(hist) >= 2:
                (t0, n0), (t1, n1) = hist[0], hist[-1]
                if t1 - t0 >= 1.0:
                    total += (n1 - n0) / (t1 - t0)
                    seen = True
    return total if seen else None


def kind_of(code, message):
    low = (message or '').lower()
    if code == 21 or 'stale' in low or 'job not found' in low or 'expired' in low:
        return 'STALE'
    if code == 22 or 'duplicate' in low:
        return 'DUPLICATE'
    if code == 23 or 'invalid' in low or 'low difficulty' in low or 'bad' in low:
        return 'INVALID'
    return 'ОТКАЗ'


def error_parts(error):
    code = message = None
    if isinstance(error, dict):
        code = error.get('code')
        message = error.get('message') or error.get('msg')
    elif isinstance(error, list) and error:
        code = error[0]
        message = error[1] if len(error) > 1 else None
    elif isinstance(error, (int, str)):
        code, message = (error, None) if isinstance(error, int) else (None, error)
    return (code if isinstance(code, int) else None), (clean(message, 120) if message else '')


def on_submit_response(body):
    try:
        reply = json.loads(body)
    except ValueError:
        limited('pool', 'пул: ' + clean(body))
        return
    if not isinstance(reply, dict):
        return
    rid = reply.get('id')
    now = time.monotonic()
    with S.lock:
        number, sent = S.pending.pop(rid, (None, None))
        if number is None:
            S.number += 1
            number = S.number
        ms = int((now - sent) * 1000) if sent is not None else None
        if ms is not None:
            S.acks = (S.acks + [ms])[-50:]
        S.activity = True
    lat = (' [' + str(ms) + ' мс]') if ms is not None else ''
    error = reply.get('error')
    if reply.get('result') is True and error is None:
        with S.lock:
            S.accepted += 1
        rate = work_rate()
        emit('шара №' + str(number) + ' принята' + lat + ((' · ' + ths(rate)) if rate else ''))
        return
    code, message = error_parts(error)
    kind = kind_of(code, message)
    with S.lock:
        S.kinds[kind] = S.kinds.get(kind, 0) + 1
    reason = ' '.join(x for x in (str(code) if code is not None else '', message) if x) or 'причина не указана'
    emit('ОТКАЗ ' + kind + ' шара №' + str(number) + ' (id ' + str(rid) + ')' + lat + ': ' + reason)


def on_pool_raw(body):
    try:
        message = json.loads(body)
    except ValueError:
        return
    if not isinstance(message, dict):
        return
    method = message.get('method')
    params = message.get('params')
    if method == 'mining.notify':
        job = height = None
        if isinstance(params, dict):
            job, height = params.get('job_id'), params.get('height')
        elif isinstance(params, list) and params:
            job = params[0]
        short = clean(str(job).split('_')[0], 16) if job is not None else '?'
        with S.lock:
            S.activity = True
        emit('задание ' + short + ((' · высота ' + str(height)) if isinstance(height, int) else ''))
    elif method == 'mining.set_difficulty':
        emit('пул: сложность ' + clean(json.dumps(params), 60))
    elif method:
        limited('pool-method', 'пул: ' + clean(method, 40) + ' ' + clean(json.dumps(params), 100))


def on_jsonrpc(body):
    try:
        reply = json.loads(body)
    except ValueError:
        return
    if not isinstance(reply, dict) or reply.get('id') != 1:
        if isinstance(reply, dict) and reply.get('error') is not None:
            code, message = error_parts(reply['error'])
            limited('pool-error', 'пул: ошибка ' + ' '.join(x for x in (str(code) if code is not None else '', message) if x))
        return
    if reply.get('result') is True and reply.get('error') is None:
        emit('пул: авторизация OK')
    else:
        code, message = error_parts(reply.get('error'))
        emit('пул: ОШИБКА авторизации ' + ' '.join(x for x in (str(code) if code is not None else '', message) if x))


def on_json(record, raw):
    if record.get('type') == 'native-device-work':
        record_work(record)
    for key in ('error', 'last_execution_error'):
        if record.get(key) is not None:
            limited('json-error', 'ОШИБКА: ' + clean(raw, 300))
            return
    kind = record.get('type')
    if kind == 'native-device-idle' and not (record.get('valid') is True and record.get('execution_valid') is True
                                             and record.get('execution_errors_total') == 0):
        limited('device-idle', 'ПРЕДУПРЕЖДЕНИЕ GPU: ' + clean(raw, 300))
        return
    if kind in QUIET_TYPES:
        if kind == 'compute-v1-public-math-gate' and record.get('status') != 'PASS':
            emit('ПРОВЕРКА GPU НЕ ПРОЙДЕНА: ' + clean(raw, 300))
        return
    if kind == 'compute-v1-pearl-admission':
        if record.get('status') == 'PASS':
            emit('проверка GPU: OK (ядро ' + clean(record.get('kernel_version'), 12) + ', sm' + clean(record.get('sm'), 4) + ')')
        else:
            emit('ПРОВЕРКА GPU НЕ ПРОЙДЕНА: ' + clean(raw, 300))
        return
    if kind == 'pool-lifecycle':
        if record.get('stage') == 'reader-connection-lost':
            emit('пул: связь потеряна')
        return
    if kind == 'native-device-fault':
        emit('ОШИБКА GPU: ' + clean(raw, 300))
        return
    limited('json:' + str(kind)[:40], clean(raw, 300))


def handle(raw):
    try:
        text = raw.decode('utf-8', 'replace').rstrip('\r\n')
    except Exception:
        return
    if not text.strip():
        return
    if text.startswith('{'):
        try:
            record = json.loads(text)
        except ValueError:
            record = None
        if isinstance(record, dict):
            on_json(record, text)
            return
    if text.startswith('[pool] submit response: '):
        on_submit_response(text[len('[pool] submit response: '):])
        return
    if text.startswith('[pool-raw] '):
        on_pool_raw(text[len('[pool-raw] '):])
        return
    if text.startswith('[pool] jsonrpc: '):
        on_jsonrpc(text[len('[pool] jsonrpc: '):])
        return
    if PROOF.search(text):
        return  # per-proof TMAC/s is the miner's internal figure (~20% below the table); not shown
    m = SUBMIT.match(text)
    if m:
        with S.lock:
            S.number += 1
            S.pending[int(m.group(1))] = (S.number, time.monotonic())
            if len(S.pending) > 256:
                S.pending.pop(next(iter(S.pending)))
        return
    if text.startswith('[net] pool authorize'):
        emit('пул: подключение и авторизация…')
        return
    m = VERSION.search(text)
    if m:
        emit('Nacreon ' + clean(m.group(1), 20) + ' · автор liked · вывод alex_kodiaq ' + EDITION)
        return
    if any(p.match(text) for p in QUIET_TEXT):
        return
    head = text.split(' ', 1)[0][:24] if text.startswith('[') else 'text'
    limited('text:' + head, clean(text, 300))


def stats_rate():
    path = os.environ.get('NACREON_STATS_FILE')
    if not path:
        return None
    try:
        spec = importlib.util.spec_from_file_location('kodiaq_hstats', str(HERE.parent / 'h-stats.py'))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        snapshot = module.read_console_snapshot(path)
        values = [d.get('hs') for d in snapshot.get('devices', [])]
        values = [v for v in values if isinstance(v, (int, float)) and v > 0]
        return sum(values) if values else None
    except Exception:
        return None


def summary(final=False):
    with S.lock:
        accepted, kinds, acks, hidden = S.accepted, dict(S.kinds), list(S.acks), S.hidden
        S.hidden = 0
    rejected = sum(kinds.values())
    detail = (' (' + ', '.join(k.lower() + ' ' + str(v) for k, v in sorted(kinds.items())) + ')') if rejected else ''
    up = int(time.time() - S.started)
    parts = []
    if not final:
        rate = work_rate() or stats_rate()
        parts.append(ths(rate) if rate else 'хешрейт —')
    parts += ['принято ' + str(accepted), 'отказов ' + str(rejected) + detail]
    if acks:
        parts.append('ответ пула ' + str(int(statistics.mean(acks))) + ' мс')
    parts.append(('работал ' if final else 'работает ') + '%02d:%02d:%02d' % (up // 3600, up // 60 % 60, up % 60))
    if hidden:
        parts.append('скрыто служебных строк ' + str(hidden))
    return ' · '.join(parts)


def summary_loop(stop):
    while not stop.wait(SUMMARY_EVERY):
        with S.lock:
            if not S.activity and not S.accepted and not S.kinds:
                continue
        emit('итог: ' + summary())


def main():
    # The miner owns INT/TERM/HUP; this reader drains until the miner's output ends.
    for name in ('SIGINT', 'SIGTERM', 'SIGHUP', 'SIGQUIT'):
        try:
            signal.signal(getattr(signal, name), signal.SIG_IGN)
        except (AttributeError, OSError, ValueError):
            pass
    stop = threading.Event()
    threading.Thread(target=summary_loop, args=(stop,), name='kodiaq-summary', daemon=True).start()
    threading.Thread(target=output_watch, args=(stop,), name='kodiaq-output', daemon=True).start()
    try:
        for raw in iter(lambda: sys.stdin.buffer.readline(1 << 20), b''):
            try:
                handle(raw)
            except Exception:
                pass
    finally:
        stop.set()
        try:
            emit('PRL остановлен · ' + summary(final=True))
        except Exception:
            pass
    return 0


if __name__ == '__main__':
    sys.exit(main())
