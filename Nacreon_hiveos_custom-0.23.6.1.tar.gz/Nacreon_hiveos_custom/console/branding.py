"""Public branding; version always comes from the running build snapshot."""
NAME = 'Nacreon Miner'
DEVELOPER = 'liked'
REPOSITORY = 'https://github.com/liked-lab/Nacreon-Miner'

def label(value, limit=96):
    return ''.join(c for c in str(value) if c.isprintable() and c != '\x1b')[:limit]

def title(snapshot):
    return NAME + ' | ' + label(snapshot.get('version') or 'версия неизвестна', 64)

def startup(snapshot):
    return [title(snapshot), 'Разработчик: '+DEVELOPER,
            'GitHub: '+REPOSITORY,
            'Build ELF: '+label(snapshot.get('native_sha256') or 'нет данных', 64)]
