#!/usr/bin/env bash
# Nacreon generated-config launcher; internal qualification candidate.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
source ./h-manifest.conf
export NACREON_STATS_FILE="${NACREON_STATS_FILE:-/run/nacreon/hive-stats.json}"
# Keep the native process as the launcher PID; the reader only filters its output.
# Extra config --log: keep a daily log on disk (see nac-log.sh).
NACREON_LOG_DIR="${NACREON_LOG_DIR:-/home/user/nacreon-logs}"
nacreon_log=0
[[ -f "$(dirname -- "$CUSTOM_CONFIG_FILENAME")/log-enabled" ]] && nacreon_log=1
if [[ "${NACREON_RAW_CONSOLE:-0}" == "1" ]] || ! python3 -I -c 'import sys; sys.exit(sys.version_info < (3, 10))' >/dev/null 2>&1; then
    if [[ $nacreon_log == 1 ]]; then
        exec ./nacreon --config "$CUSTOM_CONFIG_FILENAME" > >(tee -p >(./nac-log.sh "$NACREON_LOG_DIR")) 2>&1
    fi
    exec ./nacreon --config "$CUSTOM_CONFIG_FILENAME"
fi
# $$ becomes the native PID after exec; the read-only console pins its stats to it.
export NACREON_EXPECTED_PID=$$
export NACREON_CONSOLE_CONFIG="$CUSTOM_CONFIG_FILENAME"
if [[ $nacreon_log == 1 ]]; then
    exec ./nacreon --config "$CUSTOM_CONFIG_FILENAME" > >(tee -p >(./nac-log.sh "$NACREON_LOG_DIR") | python3 -I -B ./console/public_console.py) 2>&1
fi
exec ./nacreon --config "$CUSTOM_CONFIG_FILENAME" > >(exec python3 -I -B ./console/public_console.py) 2>&1
