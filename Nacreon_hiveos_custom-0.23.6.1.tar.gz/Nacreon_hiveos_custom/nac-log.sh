#!/bin/bash
# Daily miner log for Extra config --log. Drops per-second GPU counter lines,
# stamps every line with local time, keeps 14 days. Never blocks the miner.
dir="$1"
mkdir -p "$dir" 2>/dev/null
find "$dir" -name 'nacreon-*.log' -mtime +14 -delete 2>/dev/null
grep --line-buffered -a -v -E 'native-device-(work|idle)|compute-resource' | while IFS= read -r line; do
    printf -v day '%(%F)T' -1
    printf '%(%F %T)T %s\n' -1 "$line" >> "$dir/nacreon-$day.log" 2>/dev/null
done
