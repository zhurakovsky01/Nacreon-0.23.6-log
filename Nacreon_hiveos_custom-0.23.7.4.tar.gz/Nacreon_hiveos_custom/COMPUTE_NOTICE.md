# Compute modules

The Pearl search and preparation compute images are external binary modules,
retained byte-for-byte. They are not authored by Nacreon. The Nacreon host and
adapters are separate; an external miner host executable is not included.
This private candidate does not assert ownership or redistribution rights for
those images. Existing Nacreon and dependency notices remain in LICENSE.txt
and licenses/. Internal provenance and historical evidence are retained.

## Exact compute image SHA256

- compute_sm120_prep_image: `24ce2a029373cfbc3aeb06292153fd191c50c5373e101e22a3127e117f64e0f0`

- compute_sm120_search_image: `b6cb7457f760a0225057a60b74857970341a58b5e2f37de532b3390fcd5ac3ee`

- compute_sm86_capture_image: `d0d510dcd906b10d1779188376eea52391f2aedd1dace94deb57fd0a3791e4b2`

- compute_sm86_prep_image: `6464cea90c02c1543b0ee1c7cc9112d354d6ef5c5ea5ca8c5718ce505cd381fd`

- compute_sm86_search_image: `3ca5c359599ba4ce0cce9cd6022b7b76e76178d82350d62f2fd43c06c4b073df`

- compute_sm89_prep_image: `9343a4ff8792d620a0d0f0662e9d0242aa58832ddb9689120e5d87bf89027e18`

- compute_sm89_search_image: `58e15b66619e9fa4f1274c3216d9a038c39a4252b63400a6cd75cfd807cc0d4c`
