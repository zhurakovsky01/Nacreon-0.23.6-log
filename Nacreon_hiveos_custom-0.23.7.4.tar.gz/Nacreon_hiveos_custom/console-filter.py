"""Hide routine native diagnostics; pass through errors and unknown output."""
import json
import sys
import csv
import io
import math
import os
import pathlib
import re
import subprocess
import threading
import importlib.util


def display(line):
    try:
        record = json.loads(line)
    except (ValueError, UnicodeError):
        # Suppress only known successful diagnostics. Unknown/error lines survive.
        if re.fullmatch(rb'\[v383-fence-occupancy\] device=\d+ maximum_resident_blocks=\d+ registers_sm=\d+ shared_sm=\d+ threads=\d+ dynamic=\d+\s*', line):
            return b''
        for prefix in (b'[pool-raw] ', b'[pool] jsonrpc: ', b'[pool] submit response: '):
            if line.startswith(prefix):
                try:
                    message = json.loads(line[len(prefix):])
                except (ValueError, UnicodeError):
                    return line
                if isinstance(message, dict) and message.get('error') is None:
                    if message.get('result') is True:
                        return b''  # Confirmed counts are displayed from the owned stats snapshot.
                    if message.get('method') == 'mining.notify':
                        return b''
                return line
        patterns = (
            rb'\[plain\] verify OK \(nonce=\d+ cert_version=\d+\)',
            rb'\[plain\] proof ready \(\d+ chars\) (?:nonce=\d+ )?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)? (?:[kKMGTPE]?MAC/s) \(hs=\d+\)',
            rb'\[share-map\] id=\d+ job=[A-Za-z0-9_-]+ epoch=\d+ tile=\d+ target=[0-9a-fA-F]+',
            rb'\[net\] plain_proof submit id=\d+ job=[A-Za-z0-9_-]+ b64_len=\d+ json_len=\d+ hs=\d+',
            rb'\[net\] plain_proof submit sent \(nonce=\d+\)',
            rb'\[plain\] share submitted; pool ack pending \(reader will log \[pool\] submit response\)',
            rb'\[net\] pool authorize \(configured identity\)',
            rb'\[net\] pool reader started \(always on\)',
            rb'\[net\] new job [A-Za-z0-9_-]+ while mining(?: [A-Za-z0-9_-]+)?\s+- cancelling stale work',
        )
        if any(re.fullmatch(pattern, line.rstrip(b'\r\n')) for pattern in patterns):
            return b''
        return line
    if not isinstance(record, dict):
        return line
    # Never discard an explicitly reported error, even on a routine event.
    for key in ('error', 'last_execution_error'):
        if record.get(key) is not None:
            return line
    kind = record.get('type')
    if kind == 'native-device-idle':
        if (record.get('valid') is True and record.get('execution_valid') is True
                and type(record.get('execution_errors_total')) is int
                and record['execution_errors_total'] == 0):
            return b''
    elif kind == 'host-phase':
        if set(record) == {'type', 'cpu_seconds', 'device', 'ended_monotonic_ns',
                           'stage', 'started_monotonic_ns', 'tid', 'wall_seconds'}:
            return b''
    elif kind == 'pool-lifecycle':
        stage, outcome = record.get('stage'), record.get('outcome')
        if stage == 'reader-connection-lost':
            return b'[pool] Connection lost.\n'
        ordinary = {'reply-dispatch', 'notify-seen', 'notify-published',
                    'submit-begin', 'submit-gzip-ready', 'submit-send-begin'}
        if (stage in ordinary and outcome == -2) or (stage == 'submit-send-return' and outcome == 1):
            return b''
    return line


def sensors():
    fields = 'uuid,temperature.gpu,fan.speed,clocks.current.graphics,clocks.current.memory,power.draw'
    try:
        p = subprocess.run(['nvidia-smi', '--query-gpu=' + fields,
                            '--format=csv,noheader,nounits'], capture_output=True, text=True, timeout=2)
        if p.returncode or len(p.stdout) > 65536:
            return {}
        out = {}
        for row in csv.reader(io.StringIO(p.stdout), skipinitialspace=True):
            if len(row) != 6:
                continue
            uuid = row[0].strip().lower()
            if not re.fullmatch(r'gpu-[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', uuid):
                continue
            if uuid in out:
                return {}
            values = []
            for field, maximum in zip(row[1:], (150, 100, 10000, 30000, 2000)):
                try:
                    value = float(field)
                except ValueError:
                    value = float('nan')
                values.append(value if math.isfinite(value) and 0 <= value <= maximum else None)
            out[uuid] = values
        return out
    except (OSError, subprocess.SubprocessError, UnicodeError):
        return {}


def render(snapshot, values):
    def number(value, digits=0):
        return '-' if value is None else format(value, '.' + str(digits) + 'f')
    up = snapshot['uptime']
    lines = ['\nNacreon ' + snapshot['version'] + ' | Pearl | Uptime %02d:%02d:%02d' % (up // 3600, up // 60 % 60, up % 60),
             'GPU    TH/s   Temp C  Fan %  Core MHz  Memory MHz  Power W']
    for device in snapshot['devices']:
        v = values.get(device['uuid'].lower(), [None] * 5)
        lines.append('%3d %8.2f %8s %6s %9s %11s %8s' % (
            device['index'], device['hs'] / 1e12, *(number(x) for x in v)))
    shares = snapshot['shares']['user']['total']
    known = shares['unknown'] == 0
    lines.append('Total: %.2f TH/s | Shares accepted: %s | rejected: %s%s\n' % (
        sum(d['hs'] for d in snapshot['devices']) / 1e12,
        str(shares['accepted']) if known else '-', str(shares['rejected']) if known else '-',
        '' if known else ' | response status unknown'))
    return ('\n'.join(lines)).encode('utf-8')


def main():
    stop = threading.Event()
    lock = threading.Lock()
    def write(data):
        with lock:
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()
    def status():
        path = os.environ.get('NACREON_STATS_FILE')
        if not path:
            return
        try:
            spec = importlib.util.spec_from_file_location('hive_stats', pathlib.Path(__file__).with_name('h-stats.py'))
            stats = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(stats)
        except (OSError, ImportError):
            return
        while not stop.is_set():
            try:
                snapshot = stats.read_snapshot(path)
                values = sensors()
                stats.convert(snapshot)  # Recheck identity and freshness after the sensor query.
                if not stop.is_set():
                    write(render(snapshot, values))
            except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError):
                if not stop.is_set():
                    write(b'[Nacreon] Waiting for fresh miner statistics.\n')
            stop.wait(15)
    worker = threading.Thread(target=status, daemon=True)
    worker.start()
    try:
        for line in sys.stdin.buffer:
            visible = display(line)
            if visible:
                write(visible)
    finally:
        stop.set()
        worker.join(timeout=3)


if __name__ == '__main__':
    main()
