#!/usr/bin/env bash
# Nacreon generated-config launcher; internal qualification candidate.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
source ./h-manifest.conf
export NACREON_STATS_FILE="${NACREON_STATS_FILE:-/run/nacreon/hive-stats.json}"
# Keep the native process as the launcher PID; the reader only filters its output.
# Extra config --log: keep a daily log on disk (see nac-log.sh).
NACREON_LOG_DIR="${NACREON_LOG_DIR:-/home/user/nacreon-logs}"
nacreon_run_dir="$(dirname -- "$CUSTOM_CONFIG_FILENAME")"
nacreon_log=0
if [[ -n "${NACREON_CLI_CONFIG:-}" ]]; then
    # alex_kodiaq: manual console start (kodiaq_cli.py) uses its own config; --log comes from its command line.
    CUSTOM_CONFIG_FILENAME="$NACREON_CLI_CONFIG"
    [[ "${NACREON_CLI_LOG:-0}" == "1" ]] && nacreon_log=1
else
    [[ -f "$nacreon_run_dir/log-enabled" ]] && nacreon_log=1
fi
# Extra config --tz: clock for the console and the log (miner itself is unaffected).
# A command-line start uses only its own --tz (already in the environment), never a flight sheet's leftovers.
if [[ -z "${NACREON_CLI_CONFIG:-}" && -s "$nacreon_run_dir/console-tz" && -s "$nacreon_run_dir/posix-tz" ]]; then
    export NACREON_TZ="$(head -c 64 "$nacreon_run_dir/console-tz")"
    export NACREON_LOG_TZ="$(head -c 64 "$nacreon_run_dir/posix-tz")"
fi
if [[ "${NACREON_RAW_CONSOLE:-0}" == "1" ]] || ! python3 -I -c 'import sys; sys.exit(sys.version_info < (3, 10))' >/dev/null 2>&1; then
    if [[ $nacreon_log == 1 ]]; then
        exec ./nacreon --config "$CUSTOM_CONFIG_FILENAME" > >(tee -p >(./nac-log.sh "$NACREON_LOG_DIR")) 2>&1
    fi
    exec ./nacreon --config "$CUSTOM_CONFIG_FILENAME"
fi
# alex_kodiaq: without a terminal (oxzd gpu_idle_command, pipes) a readable line log replaces the screen.
nacreon_view=./console/public_console.py
if [[ "${NACREON_LINE_MODE:-0}" == "1" ]]; then
    nacreon_view=./console/kodiaq_lines.py
fi
# $$ becomes the native PID after exec; the read-only console pins its stats to it.
export NACREON_EXPECTED_PID=$$
export NACREON_CONSOLE_CONFIG="$CUSTOM_CONFIG_FILENAME"
if [[ $nacreon_log == 1 ]]; then
    exec ./nacreon --config "$CUSTOM_CONFIG_FILENAME" > >(tee -p >(./nac-log.sh "$NACREON_LOG_DIR") | python3 -I -B "$nacreon_view") 2>&1
fi
exec ./nacreon --config "$CUSTOM_CONFIG_FILENAME" > >(exec python3 -I -B "$nacreon_view") 2>&1
