from pathlib import Path
import sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R));sys.path.insert(0,str(R/'console'))
from reject_runtime import tap_main
tap_main()
