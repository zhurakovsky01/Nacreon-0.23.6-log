#!/usr/bin/env bash
# HiveOS callback. Configuration only; no miner start, eval or GPU writes.
CUSTOM_URL="${CUSTOM_URL:-}" CUSTOM_TEMPLATE="${CUSTOM_TEMPLATE:-}" \
CUSTOM_PASS="${CUSTOM_PASS:-x}" CUSTOM_ALGO="${CUSTOM_ALGO:-pearlhash}" \
CUSTOM_USER_CONFIG="${CUSTOM_USER_CONFIG:-}" WORKER_NAME="${WORKER_NAME:-}" \
CUSTOM_CONFIG_FILENAME="${CUSTOM_CONFIG_FILENAME:-/run/nacreon/hive-args.conf}" \
python3 - <<'PY'
import os, pathlib, re, shlex, sys, tempfile

def parse_tz(value):
    m = re.fullmatch(r'(?:UTC|GMT)?([+-])(\d{1,2})(?::?(\d{2}))?', value)
    if m and int(m.group(2)) * 60 + int(m.group(3) or 0) <= 14 * 60:
        # POSIX TZ has the inverted sign: +2 hours east of UTC is UTC-2.
        posix = 'UTC' + ('-' if m.group(1) == '+' else '+') + m.group(2) + (':' + m.group(3) if m.group(3) else '')
        return value, posix
    if re.fullmatch(r'[A-Za-z][A-Za-z0-9_+-]*(?:/[A-Za-z0-9_+-]+){0,2}', value) and os.path.isfile('/usr/share/zoneinfo/' + value):
        return value, value
    print('Nacreon: --tz ' + value[:40] + ' not recognised; rig local time is used', file=sys.stderr)
    return None

def build(env):
    login = env.get('CUSTOM_TEMPLATE', '').strip()
    urls = env.get('CUSTOM_URL', '').split()
    algorithm = env.get('CUSTOM_ALGO') or 'pearlhash'
    if not login or not urls:
        raise ValueError('Nacreon: wallet template and pool URL are required')
    if algorithm not in ('pearl', 'pearlhash'):
        raise ValueError('Nacreon supports Pearl only')
    if any(mark in login for mark in ('%WAL%', '%WORKER_NAME%')):
        raise ValueError('HiveOS must expand the wallet/worker template')
    suffix = login.rsplit('.', 1)[1] if '.' in login else ''
    worker = suffix or env.get('WORKER_NAME') or 'worker'
    base = login.rsplit('.', 1)[0] if '.' in login else login
    extra = env.get('CUSTOM_USER_CONFIG', '').replace('%WAL%', base).replace('%WORKER_NAME%', worker)
    args = ['--algorithm', 'pearlhash', '--wallet', login, '--password', env.get('CUSTOM_PASS') or 'x']
    for url in urls:
        args += ['--pool', url]
    extra_args = shlex.split(extra, posix=True)
    log_enabled = '--log' in extra_args
    extra_args = [value for value in extra_args if value != '--log']
    # alex_kodiaq: --tz NAME|+H[:MM] sets the console/log clock; never reaches the miner.
    tz = None
    while '--tz' in extra_args:
        at = extra_args.index('--tz')
        value = extra_args[at + 1] if at + 1 < len(extra_args) else ''
        del extra_args[at:at + 2]
        tz = parse_tz(value)
    if not suffix and env.get('WORKER_NAME') and not any(v in ('--worker', '-r') for v in extra_args):
        args += ['--worker', worker]
    args += extra_args
    if any('\0' in value or '\n' in value or '\r' in value for value in args):
        raise ValueError('Nacreon: invalid config token')
    payload = b'NACREON_ARGS_V1\0' + b''.join(value.encode('utf-8') + b'\0' for value in args)
    if len(payload) > 65536 or len(args) > 256:
        raise ValueError('Nacreon: configuration too large')
    return payload, log_enabled, tz

def main():
    payload, log_enabled, tz = build(os.environ)
    target = pathlib.Path(os.environ['CUSTOM_CONFIG_FILENAME'])
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    flag = target.parent / 'log-enabled'
    if log_enabled:
        flag.write_text('1\n')
    elif flag.exists():
        flag.unlink()
    for name, index in (('console-tz', 0), ('posix-tz', 1)):
        path = target.parent / name
        if tz:
            path.write_text(tz[index] + '\n')
        elif path.exists():
            path.unlink()
    if target.is_symlink():
        raise ValueError('Nacreon: config symlink refused')
    descriptor, name = tempfile.mkstemp(prefix='.nacreon-', dir=target.parent)
    try:
        with os.fdopen(descriptor, 'wb') as file:
            file.write(payload)
        os.chmod(name, 0o600)
        os.replace(name, target)
    finally:
        if os.path.exists(name):
            os.unlink(name)

if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError):
        raise SystemExit('Nacreon: cannot generate configuration; check Flight Sheet fields')
PY
