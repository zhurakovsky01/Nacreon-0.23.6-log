"""Own exec trampoline: same child PID and parent-death binding; no GPU calls."""
import ctypes,os,signal,sys
parent=int(sys.argv[1]);path=sys.argv[2]
lib=ctypes.CDLL(None)
if lib.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:raise SystemExit(2)
os.execv(path,[path,'--config','-'])
