"""Read-only Hive adapter. User shares only; stale/unowned data stays unavailable."""
import csv,io,json,math,os,pathlib,re,stat,subprocess,sys,time
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent/"console"))
from snapshot_contract import validate_snapshot

def require(value):
    if not value:raise ValueError('invalid statistics')
def integer(value,low=0,high=2**64-1):
    require(type(value) is int and low<=value<=high);return value
def rate(value):
    require(type(value) in (int,float) and math.isfinite(value) and value>=0);return value
def unique_object(pairs):
    out={}
    for name,value in pairs:
        require(name not in out);out[name]=value
    return out
def verify_process(snapshot):
    pid=integer(snapshot['pid'],1,2**31-1);ticks=integer(snapshot['start_ticks'],1)
    process=pathlib.Path('/proc')/str(pid)
    text=(process/'stat').read_text();end=text.rfind(')');require(end>=0)
    require(int(text[end+1:].split()[19])==ticks)
    require(snapshot['boot_id']==pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip())
    return process.stat().st_uid
def convert(snapshot,now=None,identity=verify_process,allow_unmeasured=False):
    now=time.monotonic() if now is None else now
    snapshot=validate_snapshot(snapshot,now)
    require(snapshot['schema']=='NACREON_STATS_USER_ONLY_V2' and snapshot['product']=='Nacreon' and snapshot['coin']=='Pearl' and snapshot['algo']=='pearlhash')
    require(snapshot['running'] is True and snapshot['hs_units']=='hs')
    stamp=rate(snapshot['monotonic_seconds']);require(0<=now-stamp<=5)
    identity(snapshot)
    uptime=integer(snapshot['uptime']);version=snapshot['version'];require(isinstance(version,str) and re.fullmatch(r'[A-Za-z0-9._+-]{1,64}',version))
    devices=snapshot['devices'];require(isinstance(devices,list) and 1<=len(devices)<=32)
    hs=[];buses=[];ordinals=set();uuids=set()
    nullable=allow_unmeasured and snapshot.get('rate_method')=='confirmed_backend_batch_MAC_per_host_submit_to_finish_second' and snapshot.get('rate_scope')=='latest_completed_backend_batch_per_device' and snapshot.get('rate_clock')=='monotonic_seconds'
    for device in devices:
        ordinal=integer(device['index'],0,2**31-1);bus=integer(device['bus_number'],0,255);uuid=device['uuid']
        require(device['valid'] is True and isinstance(uuid,str) and re.fullmatch(r'GPU-[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}',uuid))
        require(ordinal not in ordinals and uuid not in uuids and bus not in buses)
        ordinals.add(ordinal);uuids.add(uuid);buses.append(bus);hs.append(None if nullable and device['hs'] is None else rate(device['hs']))
    user=snapshot['shares']['user']['total'];accepted=integer(user['accepted']);rejected=integer(user['rejected'])
    # Console can observe startup/unknown batch metadata without inventing zero rates.
    # Hive convert remains strict by default and receives no fabricated speed.
    if nullable and any(value is None for value in hs):
        integer(user['unknown']);return None,None
    # Keep confirmed USER ACK totals; never estimate shares or fabricate sensors.
    result=dict(hs=[value / 1e6 for value in hs],hs_units='mhs',bus_numbers=buses,uptime=uptime,ver=version,algo='pearlhash')
    integer(user['unknown'])  # Unconfirmed submissions do not erase confirmed ACK totals.
    result['ar']=[accepted,rejected]
    return format(rate(sum(hs))/1000,'.6f'),json.dumps(result,separators=(',',':'),allow_nan=False)
def parse_sensors(text):
    values={}
    for row in csv.reader(io.StringIO(text),skipinitialspace=True):
        if len(row)!=3:continue
        uuid=row[0].strip().lower()
        if not re.fullmatch(r'gpu-[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}',uuid):continue
        if uuid in values:return {}
        def number(value,maximum):
            try:value=float(value)
            except (ValueError,TypeError):return None
            return value if math.isfinite(value) and 0<=value<=maximum else None
        values[uuid]=(number(row[1],150),number(row[2],100))
    return values

def read_sensors():
    try:
        result=subprocess.run(['nvidia-smi','--query-gpu=uuid,temperature.gpu,fan.speed',
                               '--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=2)
        if result.returncode!=0 or len(result.stdout)>65536:return {}
        return parse_sensors(result.stdout)
    except (OSError,subprocess.SubprocessError,UnicodeError):return {}

def attach_sensors(encoded,devices,values):
    result=json.loads(encoded)
    matched=[values.get(device['uuid'].lower(),(None,None)) for device in devices]
    result['temp']=[value[0] for value in matched]
    result['fan']=[value[1] for value in matched]
    return json.dumps(result,separators=(',',':'),allow_nan=False)

def read_snapshot(path,allow_unmeasured=False):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    with os.fdopen(fd,'rb') as file:
        info=os.fstat(file.fileno());require(stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_mode&0o077==0 and info.st_size<=1024*1024)
        payload=file.read(1024*1024+1);require(len(payload)<=1024*1024)
    snapshot=json.loads(payload,object_pairs_hook=unique_object,parse_constant=lambda _:require(False))
    require(info.st_uid==verify_process(snapshot))
    convert(snapshot,identity=verify_process,allow_unmeasured=allow_unmeasured)
    return snapshot

def read_console_snapshot(path):
    return read_snapshot(path,allow_unmeasured=True)

def load(path):
    snapshot=read_snapshot(path)
    values=read_sensors()
    khs,encoded=convert(snapshot)
    return khs,attach_sensors(encoded,snapshot['devices'],values)
def main():
    try:khs,stats=load(sys.argv[1])
    except (OSError,ValueError,KeyError,TypeError,IndexError,AttributeError):khs,stats='0','null'
    print(khs);print(stats)
if __name__=='__main__':main()
