#!/usr/bin/env bash
# Sourced Hive callback: do not change caller options/directory or evaluate JSON.
khs=0
stats=null
_nacreon_stats_dir="$(dirname -- "${BASH_SOURCE[0]}")"
_nacreon_stats_output="$(python3 "$_nacreon_stats_dir/h-stats.py" "${NACREON_STATS_FILE:-/run/nacreon/hive-stats.json}" 2>/dev/null)" || _nacreon_stats_output=''
mapfile -t _nacreon_stats_rows <<< "$_nacreon_stats_output"
if [[ ${#_nacreon_stats_rows[@]} -eq 2 && ${_nacreon_stats_rows[0]} =~ ^[0-9]+([.][0-9]+)?$ && ${_nacreon_stats_rows[1]} == \{*\} ]]; then
  khs="${_nacreon_stats_rows[0]}"
  stats="${_nacreon_stats_rows[1]}"
fi
unset _nacreon_stats_dir _nacreon_stats_output _nacreon_stats_rows
