"""Read-only bounded NVIDIA Xid observation, not a hardware defect diagnosis.

Nothing here signals a miner, changes clocks, reads complete journal history,
exports raw messages, or folds pool/CUDA/ECC/thermal counters into Xid counts.
"""
import hashlib
import json
import math
import re
import selectors
import subprocess
import threading
import time

SCHEMA = 'NACREON_GPU_XID_V1'
PCI = re.compile(r'^(?:([0-9a-fA-F]{4}|[0-9a-fA-F]{8}):)?([0-9a-fA-F]{2}):([0-9a-fA-F]{2})(?:\.([0-7]))?$')
XID = re.compile(r'\bNVRM:\s+Xid\s*\(([^)]+)\):\s*(\d+)\b')
RUN = re.compile(r'^[A-Za-z0-9_.-]{1,96}$')
UUID = re.compile(r'^GPU-[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$')
BOOT = re.compile(r'^[a-fA-F0-9]{32}$')


def pci_key(value):
    """Normalize NVIDIA 4/8-domain forms, preserving PCI function if present."""
    match = PCI.fullmatch(str(value))
    if not match:
        raise ValueError('invalid_pci')
    domain, bus, device, function = match.groups()
    domain = int(domain or '0', 16)
    if domain > 65535 or int(device, 16) > 31:
        raise ValueError('invalid_pci')
    return f'{domain:04x}:{bus.lower()}:{device.lower()}', function


class ReadFailure(Exception):
    pass


def bounded_journal(argv, timeout=3, max_bytes=1024*1024):
    """Linux-only read. Raw stdout exists in bounded RAM and is never persisted.

    Read every kernel record since the anchor, not just Xid matches. A cursor
    anchor that was vacuumed away, suppressed output, failed read, or a capped
    batch can therefore never silently produce a complete zero.
    """
    proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL, close_fds=True)
    data = bytearray()
    selector = selectors.DefaultSelector()
    selector.register(proc.stdout, selectors.EVENT_READ)
    deadline = time.monotonic()+timeout
    try:
        while selector.get_map():
            remaining = deadline-time.monotonic()
            if remaining <= 0:
                raise ReadFailure('journal_timeout')
            for key, _ in selector.select(min(remaining, .2)):
                chunk = key.fileobj.read1(min(65536, max_bytes+1-len(data)))
                if not chunk:
                    selector.unregister(key.fileobj)
                else:
                    data.extend(chunk)
                    if len(data) > max_bytes:
                        raise ReadFailure('journal_batch_limit')
        if proc.wait(timeout=max(.01, deadline-time.monotonic())) != 0:
            raise ReadFailure('journal_read_failed')
        return bytes(data)
    except (OSError, subprocess.TimeoutExpired):
        raise ReadFailure('journal_read_failed') from None
    finally:
        selector.close()
        if proc.poll() is None:
            proc.kill()
        proc.wait()
        proc.stdout.close()


class XidObserver:
    """One run/boot/fresh PCI→UUID mapping; partial coverage never heals to zero.

    lifecycle: establish_before_run() BEFORE native launch; poll() outside the
    compute/display loops; snapshot() is a pure in-memory read for the viewer.
    The caller pins run_start_us to the monotonic launch boundary after anchor.
    """
    def __init__(self, run_id, boot_id, run_start_us, mapping, runner=bounded_journal,clock_us=None):
        if not RUN.fullmatch(run_id) or not BOOT.fullmatch(boot_id) or type(run_start_us) is not int or run_start_us < 0:
            raise ValueError('invalid_run_scope')
        self.run_id, self.boot_id, self.start = run_id, boot_id.lower(), run_start_us
        self.runner, self.cursor, self.anchor_us = runner, None, None
        self.clock_us=clock_us or (lambda:time.monotonic_ns()//1000)
        self.counts, self.mapping = {}, {}
        for pci, uuid in mapping.items():
            base, function = pci_key(pci)
            if not UUID.fullmatch(uuid) or uuid in self.counts or base in self.mapping:
                raise ValueError('ambiguous_mapping')
            # Xid messages often omit function; never choose among multifunction aliases.
            if function not in (None, '0'):
                raise ValueError('unsupported_nonzero_function')
            self.mapping[base] = uuid
            self.counts[uuid] = 0
        if not self.mapping:
            raise ValueError('empty_mapping')
        self.seen, self.events, self.reasons = set(), [], set()
        self.complete, self.last_poll_us, self.last_snapshot_us = False, None, None

    def _args(self, cursor=None, latest=False):
        args = ['journalctl','-k','--boot='+self.boot_id,'--output=json','--no-pager',
                '--output-fields=__CURSOR,_BOOT_ID,__MONOTONIC_TIMESTAMP,_TRANSPORT,MESSAGE']
        if latest:
            args.append('--lines=1')
        elif cursor is not None:
            args.append('--cursor='+cursor)  # Includes anchor to detect vacuum/cursor loss.
        return args

    def gap(self, reason):
        # Public, fixed enum only; never stderr, arbitrary exceptions or raw messages.
        allowed = {'journal_timeout','journal_batch_limit','journal_read_failed','journal_unavailable',
                   'invalid_records','anchor_missing','anchor_after_run','boot_changed',
                   'cursor_lost','timestamp_regression','malformed_xid','kernel_gap',
                   'event_limit','stale_poll','scope_changed'}
        self.reasons.add(reason if reason in allowed else 'journal_read_failed')
        self.complete = False

    def _read(self, args):
        try:
            raw = self.runner(args)
            if not isinstance(raw, bytes) or len(raw)>1024*1024:
                raise ReadFailure('journal_batch_limit')
            rows = [json.loads(line) for line in raw.decode('utf-8').splitlines() if line]
            if len(rows)>4096:
                raise ReadFailure('journal_batch_limit')
            for row in rows:
                if not isinstance(row,dict) or not isinstance(row.get('__CURSOR'),str) or not row['__CURSOR'] or len(row['__CURSOR'])>1024:
                    raise ValueError()
                if not isinstance(row.get('MESSAGE'),str) or row.get('_TRANSPORT')!='kernel':
                    raise ValueError()
                if not BOOT.fullmatch(row.get('_BOOT_ID','')):
                    raise ValueError()
                if not str(row.get('__MONOTONIC_TIMESTAMP','')).isdigit():
                    raise ValueError()
            return rows
        except ReadFailure as exc:
            self.gap(str(exc));return None
        except (OSError,ValueError,TypeError,UnicodeError):
            self.gap('invalid_records');return None

    def establish_before_run(self):
        if self.cursor is not None:
            raise ValueError('already_established')
        rows = self._read(self._args(latest=True))
        if rows is None:return False
        if len(rows)!=1:
            self.gap('anchor_missing');return False
        row=rows[0]
        if row['_BOOT_ID'].lower()!=self.boot_id:
            self.gap('boot_changed');return False
        at=int(row['__MONOTONIC_TIMESTAMP'])
        if at>self.start:
            self.gap('anchor_after_run');return False
        self.cursor,self.anchor_us=row['__CURSOR'],at
        self.seen.add(self.cursor)
        # Coverage becomes valid only after the first successful complete poll.
        return True

    def bind_launch_boundary(self, monotonic_us):
        """Pin actual current native launch boundary after pre-launch anchor.

        Call immediately before spawning native, before sampler/poll starts.
        This excludes Xids between setup and launch without backfilling history.
        """
        if self.cursor is None or self.last_poll_us is not None or self.events:
            raise ValueError('invalid_launch_binding')
        if type(monotonic_us) is not int or monotonic_us<max(self.start,self.anchor_us):
            raise ValueError('invalid_launch_boundary')
        self.start=monotonic_us

    def poll(self, now_us, current_boot_id, mapping):
        if type(now_us) is not int or now_us < self.start:
            self.gap('invalid_records');return self.snapshot(now_us)
        if not isinstance(current_boot_id,str) or current_boot_id.lower()!=self.boot_id:
            self.gap('boot_changed');return self.snapshot(now_us)
        try:
            normalized={pci_key(p)[0]:u for p,u in mapping.items() if pci_key(p)[1] in (None,'0')}
            if len(normalized)!=len(mapping):normalized=None
        except (ValueError,AttributeError):
            normalized=None
        if normalized!=self.mapping:
            self.gap('scope_changed');return self.snapshot(now_us)
        if self.cursor is None:
            self.gap('anchor_missing');return self.snapshot(now_us)
        rows=self._read(self._args(self.cursor))
        read_completed=max(now_us,self.clock_us())
        if rows is None:return self.snapshot(read_completed)
        if not rows or rows[0]['__CURSOR']!=self.cursor:
            self.gap('cursor_lost');return self.snapshot(now_us)
        previous=self.anchor_us
        for row in rows:
            if row['_BOOT_ID'].lower()!=self.boot_id:
                self.gap('boot_changed');return self.snapshot(now_us)
            at=int(row['__MONOTONIC_TIMESTAMP'])
            if at<previous or at>read_completed:
                self.gap('timestamp_regression');return self.snapshot(read_completed)
            previous=at
            if row['__CURSOR'] in self.seen:continue
            self.seen.add(row['__CURSOR'])
            if len(self.seen)>65536:
                self.gap('event_limit');return self.snapshot(now_us)
            message=row['MESSAGE']
            # Known explicit kernel loss notice; generic Xid-like malformed entries fail closed.
            if re.search(r'(?i)(?:dropped|suppressed|lost)\s+\d+\s+(?:messages|callbacks|records)',message):
                self.gap('kernel_gap')
            match=XID.search(message)
            if not match:
                if 'NVRM:' in message and 'Xid' in message:self.gap('malformed_xid')
                continue
            if at<self.start:continue
            try:base,function=pci_key(match.group(1))
            except ValueError:
                self.gap('malformed_xid');continue
            uuid=self.mapping.get(base)
            if uuid is None or function not in (None,'0'):continue
            code=int(match.group(2))
            if not 1<=code<=65535:
                self.gap('malformed_xid');continue
            if len(self.events)>=1024:
                self.gap('event_limit');continue
            self.counts[uuid]+=1
            # No channel, process, application, address, raw MESSAGE or cursor is exported.
            self.events.append(dict(run_id=self.run_id,boot_id=self.boot_id,monotonic_us=at,
                                    pci=base,uuid=uuid,xid=code))
        self.cursor,self.anchor_us=rows[-1]['__CURSOR'],int(rows[-1]['__MONOTONIC_TIMESTAMP'])
        self.last_poll_us=read_completed
        self.complete=not self.reasons
        return self.snapshot(read_completed)

    def snapshot(self, now_us, max_age_us=6000000):
        fresh=type(now_us) is int and self.last_poll_us is not None and 0<=now_us-self.last_poll_us<=max_age_us
        complete=self.complete and fresh
        reasons=sorted(self.reasons|({'stale_poll'} if self.last_poll_us is not None and not fresh else set()))
        return dict(schema=SCHEMA,run_id=self.run_id,boot_id=self.boot_id,
            source='kernel_journal',classification='NVIDIA_DRIVER_XID_REPORT',severity='UNCLASSIFIED',
            read_access='OBSERVED_READABLE' if complete else 'UNKNOWN_OR_GAPPED',
            categories_combined=False,incident_dedup='Journal cursor only; no cross-source or root-cause incident inference',
            execution_source=dict(coverage='UNKNOWN',source='NOT_INTEGRATED',count=None),
            run_start_monotonic_us=self.start,observed_through_monotonic_us=self.last_poll_us,
            coverage='COMPLETE_OBSERVED_JOURNAL' if complete else 'UNKNOWN',gap_reasons=reasons,
            xid_by_uuid=dict(self.counts),events=list(self.events),
            cursor_sha256=hashlib.sha256(self.cursor.encode()).hexdigest() if self.cursor else None,
            meaning='Observed NVIDIA driver Xid reports, not proven hardware faults; pool rejects/stale/CUDA/ECC/throttle excluded')


def fault_cell(snapshot, uuid):
    """Four-column renderer. Incomplete coverage is unknown, never a fake zero."""
    if not isinstance(snapshot,dict) or snapshot.get('schema')!=SCHEMA:return '—'
    value=snapshot.get('xid_by_uuid',{}).get(uuid)
    if type(value) is not int or value<0:return '—'
    complete=snapshot.get('coverage')=='COMPLETE_OBSERVED_JOURNAL'
    if not complete:return '—'
    return str(value) if value<10000 else '999+'


def validated_faults(data):
    """Viewer input is pinned by consumer to current run/boot/UUID, not GPU index."""
    value=data.get('gpu_faults');scope=data.get('fault_scope') or {}
    if not isinstance(value,dict) or value.get('schema')!=SCHEMA:return None
    if value.get('run_id')!=scope.get('run_id') or value.get('boot_id')!=scope.get('boot_id'):return None
    uuids=scope.get('device_uuids',{})
    if not uuids or len(set(uuids.values()))!=len(uuids):return None
    if any(u not in value.get('xid_by_uuid',{}) for u in uuids.values()):return None
    at=value.get('observed_through_monotonic_us')
    now=data.get('now')
    if not isinstance(now,(int,float)):return None
    if type(at) is not int or not 0<=now*1000000-at<=6000000:
        value=dict(value,coverage='UNKNOWN')
    return value


def gpu_fault_cell(data, device):
    value=validated_faults(data)
    uuid=(data.get('fault_scope') or {}).get('device_uuids',{}).get(str(device))
    return fault_cell(combined_reports(data,value),uuid)


def combined_reports(data, driver):
    """Conservative source-report display, NOT deduplicated physical incidents.

    The checked-call native producer supplies an independently scoped typed
    schema; missing or incomplete generation coverage remains UNKNOWN.
    Missing execution coverage never turns an Xid-only zero into ALL-fault zero.
    """
    if driver is None:return None
    execution=data.get('gpu_execution_faults')
    scope=data.get('fault_scope',{})
    selected=scope.get('device_uuids',{}).values()
    counts=dict(driver['xid_by_uuid']);valid=False;execution_complete=False;overlap_ambiguous=False
    if isinstance(execution,dict) and execution.get('schema')=='NACREON_GPU_EXECUTION_V1':
        at=execution.get('observed_through_monotonic_us');now=data.get('now')
        values=execution.get('reports_by_uuid',{})
        valid=(execution.get('run_id')==scope.get('run_id') and execution.get('boot_id')==scope.get('boot_id')
               and execution.get('source')=='NATIVE_TYPED_CUDA' and type(at) is int
               and isinstance(now,(int,float))
               and isinstance(values,dict) and all(type(values.get(u)) is int and values[u]>=0 for u in selected))
        if valid:
            for u in selected:
                # Two sources may describe one incident. Do not silently sum.
                if counts[u]>0 and values[u]>0:
                    counts[u]=max(counts[u],values[u]);overlap_ambiguous=True
                else:counts[u]+=values[u]
            execution_complete=execution.get('coverage')=='COMPLETE_OBSERVED_EXECUTION' and 0<=now*1000000-at<=6000000
    complete=driver['coverage']=='COMPLETE_OBSERVED_JOURNAL' and valid and execution_complete and not overlap_ambiguous
    return dict(driver,xid_by_uuid=counts,coverage='COMPLETE_OBSERVED_JOURNAL' if complete else 'UNKNOWN',
                total_semantics='When both sources have positive reports, display >=max(source counts), not unexplained sum or claimed unique incidents',
                overlap_ambiguous=overlap_ambiguous)


def possible_overlap_groups(driver_events, execution_events, tolerance_us=2000000):
    """Deterministic same-UUID temporal annotations, never causal deduplication.

    Counts/categories remain separate. At most one match per source event.
    Timing proximity does not prove one hardware fault or justify a reset.
    """
    groups=[];used=set()
    ordered=sorted(enumerate(execution_events[:1024]),key=lambda item:(item[1].get('monotonic_us',-1),item[0]))
    for driver in sorted(driver_events[:1024],key=lambda item:item.get('monotonic_us',-1)):
        at=driver.get('monotonic_us');uuid=driver.get('uuid')
        if type(at) is not int or not isinstance(uuid,str):continue
        candidates=[(abs(at-event['monotonic_us']),event['monotonic_us'],index,event)
            for index,event in ordered if index not in used and event.get('uuid')==uuid
            and type(event.get('monotonic_us')) is int and abs(at-event['monotonic_us'])<=tolerance_us]
        if candidates:
            _,_,index,event=min(candidates,key=lambda x:x[:3]);used.add(index)
            groups.append(dict(uuid=uuid,driver_monotonic_us=at,execution_monotonic_us=event['monotonic_us'],
                driver_xid=driver.get('xid'),execution_category=event.get('category'),
                relationship='POSSIBLE_TEMPORAL_OVERLAP_NOT_CAUSAL',counts_merged=False))
    return groups


def total_fault_cell(data):
    value=validated_faults(data)
    value=combined_reports(data,value)
    if value is None:return '—'
    uuids=data['fault_scope']['device_uuids'].values()
    counts=[value['xid_by_uuid'][u] for u in uuids]
    if any(type(n) is not int or n<0 for n in counts):return '—'
    return fault_cell(dict(schema=SCHEMA,coverage=value['coverage'],xid_by_uuid={'total':sum(counts)}),'total')


class FaultSampler:
    """Independent low-frequency observer; no rendering or compute-loop polling.

    scope_provider returns (fresh boot ID, fresh checked PCI→UUID mapping).
    sink receives only the sanitized public snapshot (never journal messages).
    Lifecycle is owned by the existing controller; this class never stops mining.
    """
    def __init__(self, observer, scope_provider, sink, interval=2.0):
        if interval<1 or interval>10:raise ValueError('poll_interval')
        self.observer,self.scope_provider,self.sink=observer,scope_provider,sink
        self.interval=interval;self.stop_event=threading.Event();self.thread=None

    def start(self):
        if self.thread is not None:raise ValueError('already_started')
        def work():
            while not self.stop_event.is_set():
                began=time.monotonic()
                now_us=time.monotonic_ns()//1000
                try:
                    boot,mapping=self.scope_provider()
                    snapshot=self.observer.poll(now_us,boot,mapping)
                except Exception:
                    self.observer.gap('journal_unavailable')
                    snapshot=self.observer.snapshot(now_us)
                try:self.sink(snapshot)
                except Exception:self.observer.gap('journal_unavailable')
                self.stop_event.wait(max(.01,self.interval-(time.monotonic()-began)))
        self.thread=threading.Thread(target=work,name='nacreon-xid-readonly',daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread:self.thread.join(timeout=4)
        return self.thread is None or not self.thread.is_alive()


class NativeExecutionAdapter:
    """Consume only root-bound native generation's cumulative checked-CUDA rows.

    No regex search of arbitrary stdout. Native producer owns execution_valid,
    known-slot CUDA classification and cumulative counters. Missing/invalid
    producer cannot establish zero. Consumer drops/gaps do not erase cumulative
    counters, but producer reset/decrease within generation invalidates coverage.
    """
    SCOPE='KNOWN_CHECKED_NATIVE_CUDA_DRIVER_CALLS_V1'
    def __init__(self, run_id, boot_id, native_generation, device_uuids):
        if not RUN.fullmatch(run_id) or not BOOT.fullmatch(boot_id) or not native_generation:
            raise ValueError('execution_scope')
        if not device_uuids or len(set(device_uuids.values()))!=len(device_uuids):raise ValueError('execution_mapping')
        if any(not UUID.fullmatch(u) for u in device_uuids.values()):raise ValueError('execution_mapping')
        self.run_id,self.boot,self.generation=run_id,boot_id,native_generation
        self.devices={str(k):v for k,v in device_uuids.items()}
        self.rows={};self.gaps=set();self.events=[];self.event_ids=set();self.error_high={}

    def _event(self, record):
        device=str(record.get('device'));uuid=self.devices.get(device)
        code=record.get('code');at=record.get('monotonic');sequence=record.get('error_sequence')
        if uuid is None or record.get('uuid')!=uuid:return
        if not isinstance(code,str) or not re.fullmatch(r'CUDA_ERROR_[A-Z0-9_]+',code):return
        if not isinstance(at,(int,float)) or not math.isfinite(at) or at<0 or type(sequence) is not int or sequence<1:return
        identity=(uuid,sequence)
        self.error_high[uuid]=max(sequence,self.error_high.get(uuid,0))
        if identity in self.event_ids or len(self.events)>=256:return
        self.event_ids.add(identity)
        self.events.append(dict(run_id=self.run_id,boot_id=self.boot,uuid=uuid,monotonic_us=int(at*1000000),
            category='CHECKED_CUDA_DRIVER_ERROR',code=code,event_reference=self.generation+':'+uuid+':'+str(sequence),
            description='Checked CUDA driver call returned '+code,severity='UNCLASSIFIED'))

    def consume(self, record):
        if not isinstance(record,dict) or record.get('type') not in ('native-device-idle','native-device-fault'):return
        if record.get('schema')!=1:return
        if record.get('generation')!=self.generation:return
        if record.get('type')=='native-device-fault':
            if record.get('scope')!=self.SCOPE:return
            self._event(record);return
        device=str(record.get('device'));uuid=self.devices.get(device)
        if uuid is None:return
        if record.get('uuid')!=uuid:
            self.gaps.add('execution_uuid_mismatch');return
        value=record.get('execution_errors_total');sequence=record.get('sequence');through=record.get('execution_through')
        scope=record.get('execution_scope',record.get('checkedcalls_scope'))
        if type(value) is not int or value<0 or type(sequence) is not int or sequence<1 or not isinstance(through,(int,float)) or not math.isfinite(through):
            self.gaps.add('execution_invalid_record');return
        previous=self.rows.get(uuid)
        if previous and (sequence<previous['sequence'] or value<previous['count'] or through<previous['through']):
            self.gaps.add('execution_counter_regression');return
        if previous and sequence==previous['sequence']:
            if value!=previous['count']:self.gaps.add('execution_duplicate_conflict')
            return
        self.rows[uuid]=dict(count=value,sequence=sequence,through=through,
                            valid=record.get('execution_valid') is True and scope==self.SCOPE)
        last=record.get('last_execution_error')
        if isinstance(last,dict):
            self._event(dict(last,error_sequence=value))

    def snapshot(self, now_us):
        covered=not self.gaps and len(self.rows)==len(self.devices)
        covered=covered and all(row['valid'] and 0<=now_us-row['through']*1000000<=6000000 for row in self.rows.values())
        covered=covered and all(self.error_high.get(u,0)<=r['count'] for u,r in self.rows.items())
        through=min((int(r['through']*1000000) for r in self.rows.values()),default=None)
        if through is None and self.events:through=max(e['monotonic_us'] for e in self.events)
        return dict(schema='NACREON_GPU_EXECUTION_V1',source='NATIVE_TYPED_CUDA',run_id=self.run_id,boot_id=self.boot,
            native_generation=self.generation,observed_through_monotonic_us=through,
            coverage='COMPLETE_OBSERVED_EXECUTION' if covered else 'UNKNOWN',
            reports_by_uuid={u:max(self.rows.get(u,{}).get('count',0),self.error_high.get(u,0)) for u in set(self.rows)|set(self.error_high)},gap_reasons=sorted(self.gaps),
            events=list(self.events),event_details_complete=len(self.events)==sum(r['count'] for r in self.rows.values()),
            checkedcalls_scope=self.SCOPE,classification='KNOWN_CHECKED_NATIVE_CUDA_DRIVER_REPORTS',
            severity='UNCLASSIFIED',meaning='Observed known-slot checked CUDA driver-call reports; not all possible GPU execution failures')


class NativeLaunchExecutionAdapter:
    """Aggregate reconnect generations from ONE exact pinned native PID/owned stream.

    New generation resets its own counters, never launch totals. A transition
    without a typed final-coverage record cannot prove the former generation's
    tail complete, so whole-launch coverage becomes UNKNOWN while positive
    reports in future valid generations continue to count. No subprocess/PID
    discovery is performed: root must pin exact native PID/owned public stream.
    """
    def __init__(self,run_id,boot_id,native_pid,launch_start_us,device_uuids):
        if type(native_pid) is not int or native_pid<=0 or type(launch_start_us) is not int:raise ValueError('native_pin')
        self.run_id,self.boot,self.pid,self.start=run_id,boot_id,native_pid,launch_start_us
        self.devices=device_uuids;self.generations={};self.current=None;self.gaps=set();self.first_idle=set()

    def gap(self,reason='owned_stream_gap'):
        self.gaps.add(reason if reason in {'owned_stream_gap','generation_limit','generation_reset','first_idle_missing','invalid_generation','generation_transition_tail_unknown'} else 'owned_stream_gap')

    def consume(self,record):
        if not isinstance(record,dict) or record.get('type') not in ('native-device-idle','native-device-fault'):return
        generation=record.get('generation','')
        match=re.fullmatch(r'([1-9][0-9]*)-([1-9][0-9]*)',generation) if isinstance(generation,str) else None
        if not match or int(match[1])!=self.pid or int(match[2])<self.start*1000:
            self.gap('invalid_generation');return
        if generation not in self.generations:
            if len(self.generations)>=32:
                self.gap('generation_limit');return
            if self.current is not None:
                if int(match[2])<=int(self.current.split('-')[1]):self.gap('generation_reset')
                self.gap('generation_transition_tail_unknown')
            self.current=generation
            self.generations[generation]=NativeExecutionAdapter(self.run_id,self.boot,generation,self.devices)
        if record.get('type')=='native-device-idle' and generation not in self.first_idle:
            self.first_idle.add(generation)
            if record.get('sequence')!=1:self.gap('first_idle_missing')
        self.generations[generation].consume(record)

    def snapshot(self,now_us):
        snapshots={g:a.snapshot(now_us) for g,a in self.generations.items()}
        totals={u:0 for u in self.devices.values()};events=[]
        for s in snapshots.values():
            for u,n in s['reports_by_uuid'].items():totals[u]+=n
            events.extend(s['events'])
        current=snapshots.get(self.current,{})
        complete=not self.gaps and len(snapshots)==1 and self.current in self.first_idle and current.get('coverage')=='COMPLETE_OBSERVED_EXECUTION'
        return dict(schema='NACREON_GPU_EXECUTION_V1',source='NATIVE_TYPED_CUDA',run_id=self.run_id,boot_id=self.boot,
            pinned_native_pid=self.pid,native_generation=self.current,observed_through_monotonic_us=current.get('observed_through_monotonic_us'),
            coverage='COMPLETE_OBSERVED_EXECUTION' if complete else 'UNKNOWN',reports_by_uuid=totals,
            gap_reasons=sorted(self.gaps),generations={g:dict(coverage=s['coverage'],reports_by_uuid=s['reports_by_uuid']) for g,s in snapshots.items()},
            events=events[-256:],classification='KNOWN_CHECKED_NATIVE_CUDA_DRIVER_REPORTS',severity='UNCLASSIFIED')
