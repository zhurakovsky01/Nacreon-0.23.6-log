"""Unsigned64 cumulative counter to unbounded integer, without a GPU assumption.

Serial-number arithmetic rejects backwards/reset jumps of half the range or
more. Native reports arrive far more often than a half-range worth of work.
Process generation remains the reset boundary; reconnect/viewer are irrelevant.
"""
MODULUS=1<<64
def advance(previous,raw):
    if type(raw) is not int or not 0<=raw<MODULUS:raise ValueError('invalid unsigned64 work counter')
    if previous is None:return raw
    if type(previous) is not int or previous<0:raise ValueError('invalid lifetime work counter')
    delta=(raw-previous%MODULUS)%MODULUS
    if delta>=MODULUS//2:raise ValueError('completed-work counter decreased or observation ambiguous')
    return previous+delta
