"""Read-only «Сбои» scope for the public console; reuses packaged gpu_faults observers.

Pins typed native CUDA rows and kernel-journal Xid reports to the ONE native
launch whose PID/start_ticks/boot the secure h-stats.py snapshot verified.
Missing permission, late attach, cursor loss, mapping change or an unprovable
launch boundary stay UNKNOWN (dash), never zero. Reports are counted, not
physical incidents; nothing here diagnoses hardware, signals the miner,
writes files or exports raw kernel messages. All state is bounded RAM.
"""
import collections,csv,io,os,pathlib,re,subprocess,threading,time
from gpu_faults import XidObserver,NativeLaunchExecutionAdapter,FaultSampler,bounded_journal

QUEUE=512          # typed rows buffered before the first validated stats snapshot
ANCHOR_LINES=2048  # finite recent kernel batch (runner itself caps 1MiB/4096 rows/3s)
ANCHOR_TRIES=3;POLL=3.0;SKEW_US=50000
TYPES=('native-device-idle','native-device-fault')
XID_PCI=re.compile(r'(\bNVRM:\s+Xid\s*\()PCI:')

def normalize_boot(value):
    value=str(value).strip().replace('-','').lower()
    if not re.fullmatch(r'[0-9a-f]{32}',value):raise ValueError('boot')
    return value

def read_boot():return normalize_boot(pathlib.Path('/proc/sys/kernel/random/boot_id').read_text()[:64])

def clock_skew_us():
    """BOOTTIME-MONOTONIC: total suspend time. /proc starttime counts boot-time ticks."""
    before=time.monotonic();boot=time.clock_gettime(time.CLOCK_BOOTTIME);after=time.monotonic()
    if not 0<=after-before<=.05:raise ValueError('clock_sample')
    return max(0,int((boot-before)*1e6)+1)  # conservative upper bound, including read latency

def launch_start_us(start_ticks,hz=None,skew_us=None):
    """Lower bound of the native process start on CLOCK_MONOTONIC (µs), else None.

    start_ticks is already checked by h-stats.py against /proc/<pid>/stat.
    After a suspend BOOTTIME and MONOTONIC diverge; the conversion is refused.
    """
    try:
        hz=os.sysconf('SC_CLK_TCK') if hz is None else hz
        skew_us=clock_skew_us() if skew_us is None else skew_us
    except (AttributeError,OSError,ValueError):return None
    if type(start_ticks) is not int or start_ticks<1 or type(hz) is not int or hz<=0:return None
    if type(skew_us) is not int or not 0<=skew_us<=SKEW_US:return None
    return max(0,start_ticks*1000000//hz-skew_us)

def query_pci(uuids,run=subprocess.run):
    """One bounded read-only nvidia-smi query -> {pci_bus_id: uuid} for the pinned UUIDs."""
    p=run(['nvidia-smi','--query-gpu=uuid,pci.bus_id','--format=csv,noheader'],stdin=subprocess.DEVNULL,
          capture_output=True,text=True,timeout=2)
    if p.returncode or len(p.stdout)>65536:raise ValueError('pci_query')
    found={}
    for row in csv.reader(io.StringIO(p.stdout),skipinitialspace=True):
        if len(row)!=2:continue
        uuid=row[0].strip().lower()
        if uuid in found:raise ValueError('ambiguous_uuid')
        found[uuid]=row[1].strip()
    mapping={}
    for uuid in uuids.values():
        pci=found.get(uuid.lower())
        if not pci or pci in mapping:raise ValueError('pci_mapping')
        mapping[pci]=uuid
    return mapping

class RetrospectiveXidObserver(XidObserver):
    """Anchor = last retained kernel record at/before the launch boundary.

    The reader starts concurrently with native, so a 'latest record' anchor is
    usually after launch. Instead select from one finite recent batch; when no
    record at/before the boundary is retained in it, coverage stays UNKNOWN.
    Wall-clock '--since' is never used as monotonic proof.
    """
    def _read(self,args):
        # Driver prints 'NVRM: Xid (PCI:0000:01:00): 79'; packaged pci_key() accepts
        # the bare address only. Strip exactly that prefix in RAM; all else unchanged.
        rows=super()._read(args)
        for row in rows or ():row['MESSAGE']=XID_PCI.sub(r'\1',row['MESSAGE'])
        return rows

    def establish_at_or_before(self,boundary_us):
        if self.cursor is not None:raise ValueError('already_established')
        rows=self._read(self._args()+['--lines='+str(ANCHOR_LINES)])
        if rows is None:return False
        anchor=None;previous=-1;completed=self.clock_us()
        for row in rows:
            if row['_BOOT_ID'].lower()!=self.boot_id:
                self.gap('boot_changed');return False
            at=int(row['__MONOTONIC_TIMESTAMP'])
            if at<previous or at>completed:
                self.gap('timestamp_regression');return False
            previous=at
            if at<=boundary_us:anchor=(row['__CURSOR'],at)
        if anchor is None:
            self.gap('anchor_missing');return False
        self.cursor,self.anchor_us=anchor
        self.seen.add(self.cursor)
        return True  # complete only after the first successful cursor poll

class FaultMonitor:
    """Typed rows arrive from the reader thread; the Xid journal is polled off the display loop."""
    def __init__(self,expected_pid,runner=bounded_journal,mapper=query_pci,boot_reader=read_boot,
                 clock_us=None,hz=None,skew_us=None,threads=True):
        self.pid=expected_pid;self.runner=runner;self.mapper=mapper;self.boot_reader=boot_reader
        self.clock_us=clock_us or (lambda:time.monotonic_ns()//1000);self.hz=hz;self.skew_us=skew_us;self.threads=threads
        self.lock=threading.Lock();self.stop=threading.Event();self.queue=collections.deque();self.overflow=False
        self.scope=None;self.execution=None;self.broken=False;self.xid=None;self.xid_snapshot=None;self.sampler=None;self.worker=None

    def consume(self,record):
        """Full typed record, BEFORE the display filter or idle-row field stripping."""
        if not isinstance(record,dict) or record.get('type') not in TYPES:return
        with self.lock:
            if self.execution is not None:
                try:self.execution.consume(record)
                except (ValueError,TypeError,AttributeError,KeyError):self.broken=True
            elif self.scope is None:
                if len(self.queue)>=QUEUE:self.overflow=True  # lost rows can never be repaired
                else:self.queue.append(record)

    def bind(self,view):
        """Pin to the first validated snapshot of the expected native PID. Returns True when scoped."""
        with self.lock:
            if self.scope is not None:
                if self.scope['generation']!=view['generation'] or self.scope['device_uuids']!={str(d):u for d,u in view['uuids'].items()}:self.broken=True
                return not self.broken
            pid,ticks,boot=view['generation']
            try:boot=normalize_boot(boot)
            except ValueError:boot=None
            start=launch_start_us(ticks,self.hz,self.skew_us)
            uuids={str(d):u for d,u in view['uuids'].items()}
            self.scope=dict(generation=view['generation'],run_id='native-%d-%d'%(pid,ticks),boot_id=boot,device_uuids=uuids,start_us=start)
            queued=list(self.queue);self.queue.clear()
            if pid!=self.pid or boot is None or start is None:return True  # unprovable scope: UNKNOWN
            try:
                self.execution=NativeLaunchExecutionAdapter(self.scope['run_id'],boot,pid,start,uuids)
                for record in queued:self.execution.consume(record)
            except (ValueError,TypeError,AttributeError,KeyError):self.broken=True
            if self.overflow and self.execution is not None:self.execution.gap('owned_stream_gap')
        if self.threads:
            self.worker=threading.Thread(target=self._xid_worker,name='nacreon-console-xid',daemon=True);self.worker.start()
        return True

    # ------------------------------------------------------------ Xid journal
    def _provider(self):
        return self.boot_reader(),self.mapper(self.scope['device_uuids'])

    def _sink(self,snapshot):
        with self.lock:self.xid_snapshot=snapshot

    def establish(self):
        """One bounded anchor attempt with a fresh observer (gap reasons never heal)."""
        s=self.scope
        if s is None or s['start_us'] is None or s['boot_id'] is None:return False
        try:observer=RetrospectiveXidObserver(s['run_id'],s['boot_id'],s['start_us'],self.mapper(s['device_uuids']),
                                              runner=self.runner,clock_us=self.clock_us)
        except Exception:return False
        ok=observer.establish_at_or_before(s['start_us'])
        self.xid=observer;self._sink(observer.snapshot(self.clock_us()))
        return ok

    def poll_once(self,now_us=None):
        """Same step as FaultSampler, for deterministic callers."""
        now_us=self.clock_us() if now_us is None else now_us
        try:snapshot=self.xid.poll(now_us,*self._provider())
        except Exception:
            self.xid.gap('journal_unavailable');snapshot=self.xid.snapshot(now_us)
        self._sink(snapshot)

    def _xid_worker(self):
        for attempt in range(ANCHOR_TRIES):
            if self.stop.is_set():return
            if self.establish():break
            if self.stop.wait(10):return
        else:return  # published snapshot stays UNKNOWN
        with self.lock:
            if not self.stop.is_set():
                self.sampler=FaultSampler(self.xid,self._provider,self._sink,interval=POLL);self.sampler.start()

    def close(self):
        with self.lock:self.stop.set();sampler=self.sampler
        if sampler is not None:sampler.stop()
        if self.worker is not None:self.worker.join(timeout=6)

    # ------------------------------------------------------------ viewer
    def public(self,now,generation):
        """Renderer inputs for gpu_faults.gpu_fault_cell/total_fault_cell; {} when unscoped."""
        with self.lock:
            s=self.scope
            if self.broken or s is None or s['generation']!=generation or s['boot_id'] is None:return {}
            out=dict(fault_scope=dict(run_id=s['run_id'],boot_id=s['boot_id'],device_uuids=dict(s['device_uuids'])))
            if self.execution is not None and not self.broken:
                out['gpu_execution_faults']=self.execution.snapshot(int(now*1000000))
            if self.xid_snapshot is not None:out['gpu_faults']=self.xid_snapshot
            return out
