"""Closed native scheduler-idle intervals; no extrapolation or synthetic zeros.

The displayed value is a LOWER BOUND on time without owned Nacreon GPU work.
Broad prep/owned scan intervals stay busy. This does not measure whole-GPU idle.
"""
import bisect
import math
import re

SCOPE = 'nacreon-no-owned-device-work-lower-bound-v1'

def numeric(x):
    return type(x) in (int, float) and math.isfinite(x)

def valid_record(r, device):
    return (isinstance(r, dict) and type(r.get('schema')) is int and r['schema'] == 1 and
            type(r.get('device')) is int and r['device'] == device and
            isinstance(r.get('generation'), str) and
            re.fullmatch(r'[0-9]+-[0-9]+', r['generation']) is not None and
            isinstance(r.get('uuid'), str) and
            re.fullmatch(r'GPU-[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', r['uuid']) is not None and
            type(r.get('sequence')) is int and r['sequence'] > 0 and
            all(numeric(r.get(k)) for k in ('coverage_since', 'through', 'idle_seconds')) and
            0 <= r['coverage_since'] <= r['through'] and
            0 <= r['idle_seconds'] <= r['through']-r['coverage_since']+1e-6 and
            type(r.get('valid')) is bool)

class IdleMetrics:
    def __init__(self, devices):
        self.devices = tuple(devices)
        self.history = {d: [] for d in self.devices}
        self.last = {}
        self.chain = dict.fromkeys(self.devices, 0)

    def observe(self, detail, now):
        rows = detail.get('per_gpu_idle_samples', {})
        for d in self.devices:
            supplied = rows.get(str(d))
            if not isinstance(supplied, list) or not supplied:
                self.last.pop(d, None)
                self.chain[d] += 1
                continue
            for r in supplied:
                if not valid_record(r, d):
                    self.last.pop(d, None)
                    self.chain[d] += 1
                    continue
                # stdout idle counters and the JSON snapshot are independent streams.
                # A well-formed newer record is deferred, not a broken native chain.
                if r['through'] > now+1e-6:
                    continue
                previous = self.last.get(d)
                if previous and r['generation'] == previous['generation'] and r['sequence'] == previous['sequence']:
                    if r != previous:
                        self.last.pop(d, None)
                        self.chain[d] += 1
                    continue
                if not r['valid']:
                    self.last[d] = dict(r)
                    self.chain[d] += 1
                    continue
                if self.history[d] and r['through'] <= self.history[d][-1][0]:
                    # After a missing snapshot, a retained ring contains old
                    # endpoints. They must not be re-appended out of order or
                    # reconnect coverage across the missing observation.
                    continue
                if previous and r['through'] < previous['through']:
                    # Snapshot rings repeat previously consumed records.
                    continue
                connected = (previous is not None and r['valid'] and previous['valid'] and
                    r['generation'] == previous['generation'] and r['uuid'] == previous['uuid'] and
                    r['coverage_since'] == previous['coverage_since'] and
                    r['sequence'] == previous['sequence']+1 and
                    0 < r['through']-previous['through'] <= 3 and
                    0 <= r['idle_seconds']-previous['idle_seconds'] <= r['through']-previous['through']+1e-6)
                if not connected:
                    self.chain[d] += 1
                self.last[d] = dict(r)
                if r['valid']:
                    self.history[d].append((r['through'], r['idle_seconds'], self.chain[d]))
            cutoff = now-86404
            # Indexed lists make six rolling windows O(log n), rather than
            # rescanning a whole day of per-device counters on every frame.
            old = max(0, bisect.bisect_right(self.history[d], (cutoff, math.inf, math.inf))-1)
            if old >= 4096:
                del self.history[d][:old]

    def window(self, now, seconds):
        empty = dict(idle_seconds=None, idle_percent=None, idle_per_gpu=None,
                     idle_as_of=None, idle_upper_seconds=None, idle_scope=SCOPE,
                     idle_measurement='NACREON_SCHEDULER_CONFIRMED_IDLE_LOWER_BOUND',
                     idle_upper_bound_seconds=None, idle_lag_seconds=None,
                     idle_exact=False, idle_scheduler_counter_exact=None)
        if not self.devices or not numeric(seconds) or seconds <= 0:
            return empty
        if any(d not in self.last or not self.last[d]['valid'] for d in self.devices):
            return empty
        end = min(self.last[d]['through'] for d in self.devices)
        if not 0 <= now-end <= 3:
            return empty
        start = end-seconds
        low, high = {}, {}
        for d in self.devices:
            points = self.history[d]
            if not points or points[0][0] > start or points[-1][0] < end:
                return empty
            first = max(0, bisect.bisect_right(points, (start, math.inf, math.inf))-1)
            last = min(len(points)-1, bisect.bisect_left(points, (end, -math.inf, -math.inf)))
            chain = self.chain[d]
            # Chain ids increase on EVERY missing/invalid/reset segment; equal
            # endpoint ids prove the validated interior contains no such gap.
            if points[first][2] != chain or points[last][2] != chain:
                return empty
            def bounds(at):
                index = max(0, bisect.bisect_right(points, (at, math.inf, math.inf))-1)
                a = points[index]
                if a[0] == at:
                    return a[1], a[1]
                b = points[index+1]
                if a[2] != chain or b[2] != chain:
                    return None
                # Counters locate a bounded amount, not a uniform distribution.
                return max(a[1], b[1]-(b[0]-at)), min(b[1], a[1]+at-a[0])
            begin, finish = bounds(start), bounds(end)
            if begin is None or finish is None:
                return empty
            low[d] = max(0.0, finish[0]-begin[1])
            high[d] = min(seconds, finish[1]-begin[0])
        mean = sum(low.values())/len(self.devices)
        upper = sum(high.values())/len(self.devices)
        # An ambiguous clipped-edge lower bound of zero is not measured zero.
        # Keep the existing UI unknown marker rather than display a false 0.
        shown = None if mean <= 1e-9 and upper > 1e-6 else mean
        return dict(idle_seconds=shown, idle_percent=None if shown is None else 100*shown/seconds,
                    idle_per_gpu=low, idle_as_of=end,
                    idle_lower_seconds=mean, idle_upper_seconds=upper, idle_scope=SCOPE,
                    idle_measurement='NACREON_SCHEDULER_CONFIRMED_IDLE_LOWER_BOUND',
                    idle_upper_bound_seconds=upper, idle_lag_seconds=now-end,
                    idle_exact=False, idle_scheduler_counter_exact=abs(upper-mean)<=1e-6)
