"""Public operator state. Mining/guards own this object; viewers only read snapshots."""
import collections,json,math,os,pathlib,re,subprocess,time
from work_counter import advance

def public_label(value,limit=120):
 value=str(value)
 return ''.join(c for c in value if 32<=ord(c)<127)[:limit]

class OperatorState:
 def __init__(self,worker,build_sha,devices,started=None):
  assert re.fullmatch(r'[A-Za-z0-9_-]{1,63}',worker)
  assert re.fullmatch('[0-9a-f]{64}',build_sha)
  self.started=time.monotonic() if started is None else started
  self.worker=worker;self.build_sha=build_sha;self.devices=tuple(devices)
  self.totals={d:None for d in self.devices};self.history=collections.deque()
  self.connections=set();self.authorized=set();self.auth_ids=set();self.submits={};self.responses={}
  self.job=None;self.phase='Waiting for completed GPU work';self.last_share=None
  self.observer_error=False;self.errors=collections.deque(maxlen=8);self.running=True
  self.socket_states=None
 def native(self,line):
  # Only a small explicit event schema is consumed; raw stdout never reaches UI.
  if len(line)>8192 or not line.startswith('{'):return
  try:v=json.loads(line)
  except (ValueError,TypeError):return
  if v.get('type')=='native-device-work':
   d=v.get('device');n=v.get('raw_completed_macs_total')
   if type(d) is not int or d not in self.totals or type(n) is not int or n<0:return
   old=self.totals[d]
   try:n=advance(old,n)
   except ValueError:
    self.error('Completed-work counter decreased; rate UNKNOWN');self.totals[d]=None;return
   self.totals[d]=n;self.phase='Mining; completed device work observed'
  elif v.get('type')=='native-job':
   epoch=v.get('epoch')
   if type(epoch) is int:self.phase='Job epoch '+str(epoch)+' drained'
 def wire(self,record,now=None):
  now=time.monotonic() if now is None else now
  kind=record.get('type');connection=record.get('connection')
  if not isinstance(connection,str) or not re.fullmatch(r'c\d{1,2}',connection):return
  key=(connection,record.get('id'))
  if kind=='authorize':self.connections.add(connection);self.auth_ids.add(key)
  elif kind=='notify':
   self.connections.add(connection);self.job=public_label(record.get('job_id','UNKNOWN'),100)
   self.phase='New job received; preparation progress UNKNOWN'
  elif kind=='submit':self.submits.setdefault(key,now)
  elif kind=='response':
   if key in self.auth_ids and record.get('result') is True and record.get('error') is None:self.authorized.add(connection)
   self.responses.setdefault(key,dict(result=record.get('result'),error=record.get('error'),when=now))
  if key in self.submits and key in self.responses:self.last_share=self.responses[key]['when']
 def error(self,category):
  self.observer_error=True;self.errors.append(public_label(category))
 def snapshot(self,now=None,cards=None):
  now=time.monotonic() if now is None else now
  if not self.history:self.history.append((self.started,{d:0 for d in self.devices}))
  self.history.append((now,dict(self.totals)))
  while len(self.history)>2 and self.history[1][0]<=now-30:self.history.popleft()
  stamp,old=self.history[0];duration=now-stamp
  rates={d:(max(0,n-old[d])/duration/1e12 if n is not None and old[d] is not None and duration>0 and self.running else None) for d,n in self.totals.items()}
  counts=dict(accepted=0,invalid=0,stale=0,duplicate=0,other_rejected=0,unknown=0)
  for key in self.submits:
   reply=self.responses.get(key)
   if reply is None:continue
   error=reply['error'];value=reply['result']
   if value is True and error is None:category='accepted'
   elif value is False or error is not None:
    text=str(error).lower();category='invalid' if 'invalid' in text else 'stale' if 'stale' in text else 'duplicate' if 'duplicate' in text else 'other_rejected'
   else:category='unknown'
   counts[category]+=1
  counts['rejected']=sum(counts[k] for k in ('invalid','stale','duplicate','other_rejected'))
  inflight=sum(key not in self.responses for key in self.submits)
  total=sum(rates.values()) if all(n is not None for n in rates.values()) and rates else None
  allowed_cards={}
  for d,card in (cards or {}).items():
   if d not in self.devices:continue
   clean={'name':public_label(card.get('name','UNKNOWN'),64)}
   for k in ('power','temp','fan','core','memory'):
    x=card.get(k);clean[k]=x if type(x) in (int,float) and math.isfinite(x) else None
   from core_offsets import verified
   value=verified(card)
   if value is not None:
    clean['uuid']=card['uuid'];clean['core_offset']=dict(status=card['core_offset']['status'],uuid=card['uuid'],value_mhz=value)
   allowed_cards[str(d)]=clean
  connection='UNKNOWN' if self.socket_states is None else 'ESTABLISHED' if '01' in self.socket_states else 'DISCONNECTED' if not self.socket_states else 'TCP_TRANSITION'
  if not self.running:connection='DISCONNECTED'
  return dict(schema='NACREON_OPERATOR_V1',version='protocol-console-20261016+continuous-r1+idle-r1',native_sha256=self.build_sha,worker=self.worker,updated_unix_ns=time.time_ns(),updated_monotonic=now,uptime_seconds=max(0,int(now-self.started)),running=self.running,connection_count=len(self.connections),authorized_connection_count=len(self.authorized),owned_tcp_states=self.socket_states,connection_status=connection,job=self.job,phase=self.phase,rate_method='Completed canonical raw MAC / full elapsed observation window; includes prep/idle/drain; not pool credited hashrate',rate_unit='TMAC/s',rate_window_seconds=duration,per_gpu_rates={str(k):v for k,v in rates.items()},total_rate=total,counts=counts if not self.observer_error else None,observed_counts=counts,counts_complete=not self.observer_error,inflight_observed=inflight,last_share_age_seconds=None if self.last_share is None else max(0,now-self.last_share),errors=list(self.errors),cards=allowed_cards,pool_worker_UI_verified=False)

def publish(path,value):
 path=pathlib.Path(path);temporary=path.with_name(path.name+'.next')
 data=json.dumps(value,allow_nan=False);assert len(data)<65536
 with temporary.open('w',encoding='utf-8') as f:f.write(data)
 os.replace(temporary,path)

class Publisher:
 def __init__(self,base,worker,build_sha,devices):
  self.path=pathlib.Path(base)/'operator-state.json';self.state=OperatorState(worker,build_sha,devices)
  self.record_offset=0;self.log_offsets=[0,0];self.next_publish=0;self.cards={}
 def update(self,reader,capture,now=None,force=False):
  now=time.monotonic() if now is None else now
  if not force and now<self.next_publish:return
  self.next_publish=now+1
  # Incremental consumption uses the Reader's own lock; no log/proof body copy.
  with reader.lock:
   for index,parts in enumerate(reader.parts):
    for line in parts[self.log_offsets[index]:]:self.state.native(line)
    self.log_offsets[index]=len(parts)
   if reader.errors:self.state.error('Host reader incomplete')
  records=capture.public.records
  for record in records[self.record_offset:]:self.state.wire(record,now)
  self.record_offset=len(records)
  if capture.errors:self.state.error('Public wire observer incomplete; full counters UNKNOWN')
  self.state.socket_states=None
  if getattr(capture,'pid',None) is not None:
   try:
    proc=pathlib.Path('/proc')/str(capture.pid)
    assert (proc/'stat').read_text().rsplit(')',1)[1].split()[19]==capture.start_ticks
    inodes=set()
    for fd in (proc/'fd').iterdir():
     try:
      link=str(fd.readlink())
      if link.startswith('socket:['):inodes.add(link[8:-1])
     except FileNotFoundError:pass
    self.state.socket_states=[f[3] for row in pathlib.Path('/proc/net/tcp').read_text().splitlines()[1:] if (f:=row.split())[9] in inodes and int(f[2].split(':')[1],16)==7048]
   except (OSError,AssertionError,ValueError):pass
  if int(now)%5==0:
   try:
    from legacy_console import gpu_query
    self.cards=gpu_query()
   except (OSError,ValueError,subprocess.SubprocessError):self.cards={}
  publish(self.path,self.state.snapshot(now,self.cards))
