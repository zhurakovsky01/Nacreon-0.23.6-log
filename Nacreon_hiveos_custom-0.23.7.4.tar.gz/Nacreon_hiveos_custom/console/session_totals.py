"""Bounded lifetime aggregates, owned by collector, independent of viewer/pool.

Power is a snapshot-sampled board-power estimate. Any uncovered prefix/gap stays
unknown for this session. Idle keeps the existing native lower-bound semantics.
No lifetime event list or raw journal is created by this module.
"""
import hashlib,json,math,os,pathlib
from idle_metrics import valid_record

POWER_MAX_AGE=6.0  # Same bounded sensor-cache age as public_console.SENSOR_AGE.

def finite(x):return type(x) in (int,float) and math.isfinite(x)
def session_key(pin,boot_id):
    value=[boot_id,pin['pid'],pin['start_stamp'],pin['exe_sha256']]
    return hashlib.sha256(json.dumps(value,separators=(',',':')).encode()).hexdigest()

class SessionTotals:
    def __init__(self,key,devices,started,path=None,capture_from_start=False,power_seed=None):
        self.key=key;self.devices=tuple(devices);self.started=started;self.path=pathlib.Path(path) if path else None;self.restored=False
        assert self.devices and len(set(self.devices))==len(self.devices) and finite(started)
        self.state=dict(schema=1,key=key,devices=list(self.devices),started=started,through=started,
            work={str(d):None for d in self.devices},work_ok=True,counts=None,counts_ok=capture_from_start,
            power_energy=0.,power_seconds=0.,power_ok=True,power_point=None,idle_generation={},idle_tail={},idle_ok=True,idle_value=None,idle_upper=None,log_offsets=[0,0])
        if self.path and self.path.exists():
            try:
                assert self.path.stat().st_size<=32768
                old=json.loads(self.path.read_text())
                if old['key']==key:
                    assert old['schema']==1 and old['devices']==list(self.devices) and old['started']==started
                    assert set(old)==set(self.state)
                    assert finite(old['through']) and old['through']>=started
                    assert isinstance(old['work'],dict) and set(old['work'])=={str(d) for d in self.devices}
                    assert all(n is None or (type(n) is int and 0<=n<1<<1024) for n in old['work'].values())
                    assert all(type(old[k]) is bool for k in ('work_ok','counts_ok','power_ok','idle_ok'))
                    assert old['counts'] is None or (type(old['counts']) is list and len(old['counts'])==2 and all(type(n) is int and n>=0 for n in old['counts']))
                    assert finite(old['power_energy']) and old['power_energy']>=0 and finite(old['power_seconds']) and 0<=old['power_seconds']<=old['through']-started+1e-6
                    assert type(old['log_offsets']) is list and len(old['log_offsets'])==2 and all(type(n) is int and n>=0 for n in old['log_offsets'])
                    self.state=old
                    self.restored=True
                    # A collector restart cannot attest unseen wire replies.
                    # Retain totals, never turn a missing interval into zeros.
                    if not capture_from_start:self.state['counts_ok']=False
            except (OSError,ValueError,KeyError,AssertionError,TypeError):
                self.state.update(work_ok=False,counts_ok=False,power_ok=False,idle_ok=False)
        if self.state['power_point'] is None and power_seed is not None:
            stamp,cards=power_seed;power=self._power(cards)
            if finite(stamp) and stamp<=started and power is not None:self.state['power_point']=[stamp,power]

    def _power(self,cards):
        if not isinstance(cards,dict):return None
        points=[]
        for d in self.devices:
            card=cards.get(str(d),cards.get(d,{}));points.append(card.get('power') if isinstance(card,dict) else None)
        return sum(points) if all(finite(p) and p>=0 for p in points) else None

    def _idle(self,detail,now):
        totals=[];upper=[]
        for d in self.devices:
            rows=detail.get('per_gpu_idle_samples',{}).get(str(d),[])
            if not rows:return None,None
            # Defer newer stdout records until this JSON snapshot catches up.
            if any(not valid_record(r,d) for r in rows):return None,None
            eligible=[r for r in rows if r['through']<=now+1e-6]
            if not eligible:return None,None
            r=eligible[-1]
            if not r['valid'] or not 0<=now-r['through']<=3:return None,None
            # The scheduler starts after the process. Its missing prefix remains
            # unknown in the upper bound; the cumulative idle is still a valid
            # lower bound for the full native lifetime. Never invent a zero.
            if r['coverage_since']<self.started-1e-6:return None,None
            old=self.state['idle_generation'].get(str(d))
            tail=self.state['idle_tail'].get(str(d))
            scope=[r['generation'],r['uuid']]
            if old is not None and old!=scope:self.state['idle_ok']=False
            if tail and (r['through']<tail[0] or r['idle_seconds']<tail[1] or (r['through']==tail[0] and r['idle_seconds']!=tail[1])):self.state['idle_ok']=False
            self.state['idle_generation'][str(d)]=scope
            self.state['idle_tail'][str(d)]=[r['through'],r['idle_seconds']]
            if not self.state['idle_ok']:return None,None
            totals.append(r['idle_seconds']);upper.append(r['idle_seconds']+max(0.,r['coverage_since']-self.started)+max(0.,now-r['through']))
        low=sum(totals)/len(totals);high=sum(upper)/len(upper)
        return (None if low<=1e-9 and high>1e-6 else low),high

    def observe(self,snapshot,totals,cards=None,power_stamp=None):
        t=snapshot['updated_monotonic'];s=self.state
        if not finite(t) or t<self.started or t<s['through']:return self.summary(s['through'])
        if t==s['through'] and t!=self.started:return self.summary(t)
        for d in self.devices:
            n=totals.get(d,totals.get(str(d)))
            if n is None:continue
            old=s['work'][str(d)]
            if type(n) is not int or n<0 or (old is not None and n<old):s['work_ok']=False
            else:s['work'][str(d)]=n
        counts=snapshot.get('counts') if snapshot.get('counts_complete') is True else None
        pair=[counts.get('accepted'),counts.get('rejected')] if isinstance(counts,dict) else None
        if pair is None or not all(type(n) is int and n>=0 for n in pair):s['counts_ok']=False
        elif s['counts'] is not None and any(n<old for n,old in zip(pair,s['counts'])):s['counts_ok']=False
        else:s['counts']=pair
        p=self._power(cards if cards is not None else snapshot.get('cards',{}))
        # A sensor reading may be newer than the latest native JSON frame. Both
        # are local monotonic observations; bounded skew is not a missing sample.
        fresh=finite(power_stamp) and abs(t-power_stamp)<=POWER_MAX_AGE
        previous=s['power_point']
        if previous is None or p is None or not fresh:
            if t>self.started:s['power_ok']=False
        elif t>previous[0]:
            dt=t-previous[0];lo=max(self.started,previous[0])
            if dt>10 or previous[0]>self.started+s['power_seconds']+1e-6:s['power_ok']=False
            if dt<=10 and t>lo:
                p0=previous[1]+(p-previous[1])*(lo-previous[0])/dt
                s['power_energy']+=(p0+p)/2*(t-lo);s['power_seconds']+=t-lo
        if p is not None and fresh:s['power_point']=[t,p]
        else:s['power_point']=None
        idle,upper=self._idle(snapshot.get('detail',{}),t)
        s['through']=t
        s['idle_value']=idle;s['idle_upper']=upper
        summary=self.summary(t)
        if self.path:
            data=json.dumps(s,allow_nan=False,separators=(',',':'));assert len(data)<=32768
            temporary=self.path.with_name(self.path.name+'.next');temporary.write_text(data);os.replace(temporary,self.path)
        return summary

    def summary(self,now):
        s=self.state;elapsed=now-self.started
        idle=s['idle_value'];upper=s['idle_upper']
        work=list(s['work'].values());speed=sum(work)/elapsed/1e12 if elapsed>0 and s['work_ok'] and all(type(n) is int for n in work) else None
        power=s['power_energy']/elapsed if elapsed>0 and s['power_ok'] and abs(s['power_seconds']-elapsed)<=1e-6 else None
        counts=s['counts'] if s['counts_ok'] else None
        denominator=sum(counts) if counts else 0
        return dict(schema=1,scope=self.key,started=self.started,through=now,elapsed_seconds=max(0,elapsed),
            mean_rate=speed,mean_power=power,efficiency=speed/power if speed is not None and power else None,
            accepted=counts[0] if counts else None,rejected=counts[1] if counts else None,
            rejected_percent=100*counts[1]/denominator if denominator else None,
            idle_seconds=idle,idle_percent=100*idle/elapsed if idle is not None and elapsed>0 else None,
            idle_upper_seconds=upper,idle_measurement='NACREON_SCHEDULER_CONFIRMED_IDLE_LOWER_BOUND',
            power_method='Snapshot-sampled board-power integral over full session; bounded fresh samples, no missing prefix/gap filled',
            work_method='Lifetime raw completed MAC counter / full native session elapsed; not pool credited work')

def viewer_summary(snapshot,key,started,stale=False):
    v=snapshot.get('session_metrics')
    if stale or not isinstance(v,dict) or type(v.get('schema')) is not int or v['schema']!=1 or v.get('scope')!=key:return {}
    if v.get('started')!=started or v.get('through')!=snapshot.get('updated_monotonic'):return {}
    if not finite(v.get('through')) or v['through']<started:return {}
    if any(x is not None and (not finite(x) or x<0) for x in (v.get(k) for k in ('mean_rate','mean_power','efficiency','idle_seconds','idle_percent','rejected_percent'))):return {}
    if any(v.get(k) is not None and (type(v[k]) is not int or v[k]<0) for k in ('accepted','rejected')):return {}
    return v
