"""Pure USER-only V2 snapshot contract; no process, network or device access."""
import math,re
SCHEMA='NACREON_STATS_USER_ONLY_V2'
UUID=re.compile(r'GPU-[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}')
def need(ok):
    if not ok:raise ValueError('invalid USER snapshot')
def integer(n,high=2**64-1):
    need(type(n) is int and 0<=n<=high);return n
def number(n):
    need(type(n) in (int,float) and math.isfinite(n) and n>=0);return n
def counter(v):
    need(type(v) is list and len(v)==1 and type(v[0]) is str and re.fullmatch(r'[0-9]{1,39}',v[0]) is not None)
    n=int(v[0]);need(n<2**128);return n
def share_row(row):
    need(type(row) is dict and set(row)=={'accepted','rejected','unknown','pending'})
    return tuple(integer(row[k]) for k in ('accepted','rejected','unknown','pending'))

def canonical_snapshot(s):
    """Project the exact legacy USER-only contract without inventing work/rates.

    Nonzero developer work or shares is incompatible with this release reader.
    The original object remains untouched; ownership and freshness checks stay
    in the callers, and the unchanged V2 validator checks the projected frame.
    """
    if type(s) is not dict or s.get('schema')!='NACREON_STATS_V1':return s
    need(s.get('developer_ready') is False)
    routes=s.get('shares');need(type(routes) is dict and set(routes)=={'user','developer'})
    dev=routes['developer'];need(type(dev) is dict and {'total','devices'}<=set(dev)<={'total','devices','telemetry'})
    need(share_row(dev['total'])==(0,0,0,0));need(type(dev['devices']) is dict)
    for key,row in dev['devices'].items():
        need(type(key) is str and re.fullmatch('[0-9]+',key) is not None);need(share_row(row)==(0,0,0,0))
    if 'telemetry' in dev:
        t=dev['telemetry'];need(type(t) is dict and t.get('events')==[] and type(t.get('last_serial')) is int and t['last_serial']==0)
        c=t.get('connection');need(type(c) is dict and c.get('connected') is False and type(c.get('connections')) is int and c['connections']==0 and type(c.get('reconnections')) is int and c['reconnections']==0)
        rej=t.get('rejected');need(type(rej) is dict and set(rej)=={'invalid','stale','duplicate','other'} and all(type(x) is int and x==0 for x in rej.values()))
    need(type(s.get('devices')) is list)
    out=dict(s);out['schema']=SCHEMA;out.pop('developer_ready');out['shares']={'user':routes['user']};out['devices']=[]
    for d in s['devices']:
        need(type(d) is dict);row=dict(d)
        for key in ('raw_macs','current_macs'):
            v=d.get(key);need(type(v) is list and len(v)==2);counter([v[0]]);need(counter([v[1]])==0);row[key]=[v[0]]
        out['devices'].append(row)
    return out

def validate_snapshot(s,now):
    s=canonical_snapshot(s)
    need(type(s) is dict and set(s)<={'schema','product','version','coin','algo','running','pid','start_ticks','boot_id','monotonic_seconds','uptime','rate_window_seconds','full_wall_rate_window_seconds','rate_method','rate_scope','rate_clock','batch_rate_age_limit','full_wall_rate_method','hs_units','pool_credited_speed_proven','devices','user_ready','shares'})
    need(type(s['version']) is str and re.fullmatch(r'[A-Za-z0-9._+-]{1,64}',s['version']) is not None)
    need(s['rate_method']=='confirmed_backend_batch_MAC_per_host_submit_to_finish_second' and s['rate_scope']=='latest_completed_backend_batch_per_device' and s['rate_clock']=='monotonic_seconds')
    if 'pool_credited_speed_proven' in s:need(s['pool_credited_speed_proven'] is False)
    need(type(s) is dict and s['schema']==SCHEMA and s['product']=='Nacreon' and s['coin']=='Pearl' and s['algo']=='pearlhash' and s['hs_units']=='hs')
    need(type(s['running']) is bool and type(s['user_ready']) is bool)
    integer(s['pid'],2**31-1);need(s['pid']>0);integer(s['start_ticks']);need(s['start_ticks']>0)
    need(type(s['boot_id']) is str and 1<=len(s['boot_id'])<=128);integer(s['uptime'])
    stamp=number(s['monotonic_seconds']);number(now);need(0<=now-stamp<=5)
    need(type(s['shares']) is dict and set(s['shares'])=={'user'})
    user=s['shares']['user'];need(type(user) is dict and {'total','devices'}<=set(user)<= {'total','devices','telemetry'});share_row(user['total'])
    need(type(user['devices']) is dict)
    ds=s['devices'];need(type(ds) is list and 1<=len(ds)<=32);ids=set();uuids=set();buses=set()
    for d in ds:
        need(type(d) is dict);idx=integer(d['index'],2**31-1);bus=integer(d['bus_number'],255);uuid=d['uuid']
        need(type(uuid) is str and UUID.fullmatch(uuid) is not None and idx not in ids and uuid.lower() not in uuids and bus not in buses)
        ids.add(idx);uuids.add(uuid.lower());buses.add(bus);need(type(d['valid']) is bool)
        raw=counter(d['raw_macs']);current=counter(d['current_macs']);need(current<=raw)
        b=d['batch'];need(type(b) is dict);seq=integer(b['sequence']);integer(b['timing_errors']);need(type(b['valid']) is bool and type(b['complete_window']) is bool)
        need(b['route']==('user' if seq else None));need(b['canonical_macs'] is None if not seq else type(b['canonical_macs']) is int)
        if seq:integer(b['canonical_macs'])
        need(b['scope'] in {'none','measured','timing_invalid','no_confirmed_work','clock_mismatch','device_invalid','stopped','expired'})
        for k in ('submitted_at','completed_at','elapsed_seconds','age_seconds','max_age_seconds'):
            if b[k] is not None:number(b[k])
        for k in ('full_wall_hs','completed_current_hs'):
            if d[k] is not None:number(d[k])
        if d['hs'] is not None:
            hs=number(d['hs']);sent=number(b['submitted_at']);done=number(b['completed_at']);elapsed=number(b['elapsed_seconds']);age=number(b['age_seconds']);limit=number(b['max_age_seconds'])
            need(s['running'] and d['valid'] and b['valid'] and b['scope']=='measured' and seq>0 and b['canonical_macs']>0)
            need(sent<done<=stamp+1e-3 and 0<elapsed<=600 and abs(done-sent-elapsed)<=1e-3)
            need(abs(limit-min(120.,max(10.,4*elapsed)))<=1e-3 and 0<=age<=limit and abs(max(0.,stamp-done)-age)<=1e-3)
            need(hs>0 and abs(hs-b['canonical_macs']/elapsed)<=1e-9*hs)
    need(set(user['devices'])<={str(i) for i in ids})
    for row in user['devices'].values():share_row(row)
    return s
