"""Viewer-only rolling metrics. Gaps/late starts never create historical zeros.

Power and link outage are estimates from snapshot samples, not PSU readings or
continuous packet tracing. Device idle requires explicit device timing counters;
neither low power nor a quiet share stream proves an idle GPU.
"""
import bisect
import math
from collections import deque
from history24 import WINDOWS
from idle_metrics import IdleMetrics

NEGATIVE = {'invalid', 'stale', 'duplicate', 'other_rejected'}

def finite(value):
    return type(value) in (int, float) and math.isfinite(value)

class PeriodMetrics:
    def __init__(self, devices):
        self.devices = tuple(devices)
        self.samples = deque()
        self.events = {}
        self.share_since = None
        self.last_counts = None
        self.last_rejected = None
        self.idle_metrics = IdleMetrics(self.devices)

    def observe(self, snapshot):
        stamp = snapshot['updated_monotonic']
        if self.samples and stamp <= self.samples[-1][0]:
            return
        detail = snapshot.get('detail', {})
        self.idle_metrics.observe(detail, stamp)
        counts = snapshot.get('counts') if snapshot.get('counts_complete') else None
        pair = (counts['accepted'], counts['rejected']) if counts else None
        fresh = []
        for event in detail.get('recent_events', []):
            key = (event['connection'], event['id'])
            if key in self.events or not finite(event.get('observed_at')):
                continue
            if event['observed_at'] > stamp:
                continue
            fresh.append(event)
            self.events[key] = dict(event)
            if event['category'] in NEGATIVE and (self.last_rejected is None or event['observed_at'] > self.last_rejected['observed_at']):
                self.last_rejected = dict(event)
        previous = self.samples[-1][0] if self.samples else None
        new_a = sum(e['category'] == 'accepted' and e['observed_at'] > (previous if previous is not None else -math.inf) for e in fresh)
        new_r = sum(e['category'] in NEGATIVE and e['observed_at'] > (previous if previous is not None else -math.inf) for e in fresh)
        if pair is None:
            self.share_since = None
        elif previous is None or self.last_counts is None:
            self.share_since = stamp
        elif stamp-previous > 10 or pair != (self.last_counts[0]+new_a, self.last_counts[1]+new_r):
            # More replies than retained events, a capture failure, or reset.
            self.share_since = stamp
        self.last_counts = pair
        power = {d: snapshot.get('cards', {}).get(str(d), {}).get('power') for d in self.devices}
        # Idle uses its own closed native timestamps/coverage (IdleMetrics).
        # Preserve the existing sample tuple shape used by power-only views.
        idle = dict.fromkeys(self.devices)
        link = snapshot.get('connection_status')
        connection_count = snapshot.get('connection_count')
        link_valid = snapshot.get('counts_complete') is True and not snapshot.get('errors') and type(connection_count) is int and connection_count >= 1
        link_valid = link_valid and (not self.samples or type(self.samples[-1][4]) is not int or connection_count >= self.samples[-1][4])
        link = (0 if link == 'ESTABLISHED' else 1 if link == 'DISCONNECTED' else None) if link_valid else None
        self.samples.append((stamp, power, link, idle, connection_count if link_valid else None))
        cutoff = stamp-86400
        while len(self.samples) > 2 and self.samples[1][0] <= cutoff:
            self.samples.popleft()
        self.events = {k:e for k,e in self.events.items() if e['observed_at'] >= cutoff}

    def window(self, now, seconds):
        result = dict(accepted=None, rejected=None, rejected_percent=None,
                      mean_power=None, idle_seconds=None, idle_percent=None,
                      idle_per_gpu=None, offline_seconds=None, reconnects=None)
        result.update(self.idle_metrics.window(now, seconds))
        start = now-seconds
        if self.share_since is not None and self.share_since <= start and self.samples and now-self.samples[-1][0] <= 10:
            events = [e for e in self.events.values() if start < e['observed_at'] <= now]
            result['accepted'] = sum(e['category'] == 'accepted' for e in events)
            result['rejected'] = sum(e['category'] in NEGATIVE for e in events)
            n = result['accepted']+result['rejected']
            result['rejected_percent'] = 100*result['rejected']/n if n else None
        samples = list(self.samples)
        if not samples or samples[0][0] > start or samples[-1][0] < now:
            return result
        first = max(0, bisect.bisect_right([s[0] for s in samples], start)-1)
        selected = samples[first:]
        power_energy = 0
        power_ok = link_ok = True
        offline = 0
        for earlier, later in zip(selected, selected[1:]):
            lo, hi = max(start, earlier[0]), min(now, later[0])
            if hi <= lo:
                continue
            dt = later[0]-earlier[0]
            if dt > 10:
                power_ok = link_ok = False
                continue
            for d in self.devices:
                p, q = earlier[1][d], later[1][d]
                if not finite(p) or not finite(q) or p < 0 or q < 0:
                    power_ok = False
                else:
                    p0 = p+(q-p)*(lo-earlier[0])/dt
                    p1 = p+(q-p)*(hi-earlier[0])/dt
                    power_energy += (p0+p1)/2*(hi-lo)
            if earlier[2] is None or later[2] is None:
                link_ok = False
            else:
                offline += earlier[2]*(hi-lo)
        result['mean_power'] = power_energy/seconds if power_ok else None
        result['offline_seconds'] = offline if link_ok else None
        begin, end = samples[first][4], selected[-1][4]
        # Connection creation count is exact only at sampled boundaries.
        if first < len(samples) and samples[first][0] == start and samples[-1][0] == now and type(begin) is int and type(end) is int and end >= begin:
            result['reconnects'] = end-begin
        return result

    def windows(self, now):
        return {seconds:self.window(now, seconds) for seconds in WINDOWS}
