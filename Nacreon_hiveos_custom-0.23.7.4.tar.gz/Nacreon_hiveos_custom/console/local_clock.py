"""Display clock for the console (alex_kodiaq edit).

Default: the rig's own local time (HiveOS timezone). Extra config
`--tz Europe/Kyiv` or `--tz +2` overrides it through NACREON_TZ.
"""
import datetime, os, re

def _zone():
    name = os.environ.get('NACREON_TZ', '').strip()
    if not name:
        return None
    m = re.fullmatch(r'(?:UTC|GMT)?([+-])(\d{1,2})(?::?(\d{2}))?', name)
    if m:
        minutes = int(m.group(2)) * 60 + int(m.group(3) or 0)
        if minutes <= 14 * 60:
            return datetime.timezone(datetime.timedelta(minutes=minutes if m.group(1) == '+' else -minutes))
        return None
    try:
        import zoneinfo
        return zoneinfo.ZoneInfo(name)
    except Exception:
        return None

ZONE = _zone()

def day(value):
    when = datetime.datetime.fromtimestamp(value, ZONE) if ZONE is not None else datetime.datetime.fromtimestamp(value)
    return when.strftime('%d.%m')

def clock(value):
    """HH:MM:SS of a unix timestamp in the configured zone or rig local time."""
    when = datetime.datetime.fromtimestamp(value, ZONE) if ZONE is not None else datetime.datetime.fromtimestamp(value)
    return when.strftime('%H:%M:%S')
