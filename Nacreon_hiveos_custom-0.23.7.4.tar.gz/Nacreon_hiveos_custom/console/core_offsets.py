"""Read-only NVML driver readback by physical UUID; never infer from clocks/config."""
import ctypes as C,json,subprocess,time
class Offset(C.Structure):
 _fields_=[('version',C.c_uint),('type',C.c_int),('pstate',C.c_int),('clockOffsetMHz',C.c_int),('minClockOffsetMHz',C.c_int),('maxClockOffsetMHz',C.c_int)]
assert C.sizeof(Offset)==24
ALLOW={'nvmlInit_v2','nvmlShutdown','nvmlSystemGetDriverVersion','nvmlDeviceGetHandleByUUID','nvmlDeviceGetUUID','nvmlDeviceGetPerformanceState','nvmlDeviceGetClockOffsets','nvmlDeviceGetGpcClkVfOffset'}
def query(cards):
 lib=C.CDLL('libnvidia-ml.so.1')
 def bind(name,args):
  assert name in ALLOW
  fn=getattr(lib,name,None)
  if fn is not None:fn.argtypes=args;fn.restype=C.c_int
  return fn
 init=bind('nvmlInit_v2',[]);shutdown=bind('nvmlShutdown',[]);assert init and init()==0
 try:
  driver=C.create_string_buffer(96);getdriver=bind('nvmlSystemGetDriverVersion',[C.c_void_p,C.c_uint]);assert getdriver(driver,len(driver))==0
  handle_fn=bind('nvmlDeviceGetHandleByUUID',[C.c_char_p,C.POINTER(C.c_void_p)])
  uuid_fn=bind('nvmlDeviceGetUUID',[C.c_void_p,C.c_void_p,C.c_uint])
  pstate_fn=bind('nvmlDeviceGetPerformanceState',[C.c_void_p,C.POINTER(C.c_int)])
  modern=bind('nvmlDeviceGetClockOffsets',[C.c_void_p,C.POINTER(Offset)])
  legacy=bind('nvmlDeviceGetGpcClkVfOffset',[C.c_void_p,C.POINTER(C.c_int)])
  rows=[]
  for index,card in cards.items():
   uuid=card.get('uuid');pci=card.get('bus')
   if not isinstance(uuid,str) or not uuid.startswith('GPU-'):continue
   handle=C.c_void_p();row=dict(index=index,uuid=uuid,pci=pci,value_mhz=None,status='UNKNOWN')
   if handle_fn(uuid.encode(),C.byref(handle))!=0:rows.append(row);continue
   actual=C.create_string_buffer(96)
   if uuid_fn(handle,actual,len(actual))!=0 or actual.value.decode()!=uuid:row['status']='UUID_MISMATCH';rows.append(row);continue
   pstate=C.c_int();rc=pstate_fn(handle,C.byref(pstate));row['pstate_rc']=rc;row['pstate']=pstate.value if rc==0 else None
   info=Offset();info.version=C.sizeof(Offset)|(1<<24);info.type=0;info.pstate=pstate.value
   mr=modern(handle,C.byref(info)) if modern is not None and rc==0 else 13
   value=C.c_int();lr=legacy(handle,C.byref(value)) if legacy is not None else 13
   last=C.c_int();pr=pstate_fn(handle,C.byref(last))
   row.update(modern_rc=mr,modern_mhz=info.clockOffsetMHz if mr==0 else None,legacy_rc=lr,legacy_mhz=value.value if lr==0 else None)
   if pr!=0 or rc!=0 or last.value!=pstate.value:row['status']='PSTATE_UNSTABLE_OR_UNKNOWN'
   elif mr==0 and lr==0 and info.clockOffsetMHz!=value.value:row['status']='DRIVER_READBACK_CONFLICT'
   elif mr==0 and lr in (0,3,13,25) and info.minClockOffsetMHz<=info.clockOffsetMHz<=info.maxClockOffsetMHz:row.update(status='VERIFIED_DRIVER_READBACK',value_mhz=info.clockOffsetMHz,source='nvmlDeviceGetClockOffsets/currentPState/GRAPHICS',min_mhz=info.minClockOffsetMHz,max_mhz=info.maxClockOffsetMHz)
   elif mr in (3,13,25) and lr==0:row.update(status='VERIFIED_LEGACY_DRIVER_READBACK',value_mhz=value.value,source='nvmlDeviceGetGpcClkVfOffset')
   else:row['status']='UNSUPPORTED_OR_QUERY_ERROR'
   rows.append(row)
  return dict(status='READ_ONLY_CORE_OFFSET_PROBE',driver=driver.value.decode(),wall_ns=time.time_ns(),rows=rows,OC_modified=False,memory_offset_queried=False,source='NVML driver readback, not config intent or frequency difference')
 finally:shutdown()

def attach(cards):
 """Fail closed without suppressing other sensor readings."""
 try:
  result=query(cards)
  rows={r['index']:r for r in result['rows']}
 except Exception:
  rows={}
 return {d:dict(card,core_offset=rows.get(d,{})) for d,card in cards.items()}

def verified(card):
 r=card.get('core_offset',{})
 if not isinstance(r,dict):return None
 value=r.get('value_mhz')
 if (r.get('status') not in ('VERIFIED_DRIVER_READBACK','VERIFIED_LEGACY_DRIVER_READBACK')
     or not isinstance(card.get('uuid'),str) or r.get('uuid')!=card['uuid']
     or type(value) is not int or not -10000<=value<=10000):return None
 return value

def cell(card):
 value=verified(card)
 return '—' if value is None else f'{value:+d}'
