"""Encode only the approved muted gauges for the available terminal protocol.

GNU Screen4.09 converts SGR38;2 into dim/default foreground. Use its verified
256-color protocol. Direct terminals advertising truecolor retain exact RGB.
The other console colors and the user's terminal palette are never modified.
"""
import os

GAUGE_RGB={'gauge_base':(69,168,117),'gauge_amber':(192,147,68),'gauge_red':(189,91,91)}
# Muted accents. Neutral text and the terminal palette are deliberately intact.
# "30% softer" is a visual target, not a claim about monitor luminance.
TEXT_RGB={'cyan':(56,184,184),'green':(86,184,86),'yellow':(184,184,86),
          'red':(210,105,105),'blue':(138,138,214),'magenta':(190,115,190)}

def xterm_rgb(index):
    if not 16<=index<=255:raise ValueError('nonportable_basic_palette')
    if index>=232:return (8+10*(index-232),)*3
    n=index-16;levels=(0,95,135,175,215,255)
    return levels[n//36],levels[(n//6)%6],levels[n%6]

def nearest_index(rgb):
    # Entries0..15 depend on the user's theme; do not use/redefine them.
    return min(range(16,256),key=lambda n:sum((a-b)**2 for a,b in zip(rgb,xterm_rgb(n))))

def gauge_mode(environ=None):
    env=os.environ if environ is None else environ
    term=env.get('TERM','').lower()
    if env.get('STY') or term.startswith('screen'):return '256'
    if env.get('COLORTERM','').lower() in ('truecolor','24bit') or term.endswith('-direct'):return 'truecolor'
    return '256'

def gauge_codes(mode=None):
    mode=gauge_mode() if mode is None else mode
    if mode=='truecolor':return {k:'38;2;'+(';'.join(map(str,v))) for k,v in GAUGE_RGB.items()}
    if mode=='256':return {k:'38;5;'+str(nearest_index(v)) for k,v in GAUGE_RGB.items()}
    raise ValueError('gauge_color_mode')

def text_codes(mode=None):
    mode=gauge_mode() if mode is None else mode
    if mode=='truecolor':return {k:'38;2;'+(';'.join(map(str,v))) for k,v in TEXT_RGB.items()}
    if mode=='256':return {k:'38;5;'+str(nearest_index(v)) for k,v in TEXT_RGB.items()}
    raise ValueError('text_color_mode')

def gauge_background_codes(mode=None):
    # Derive the same approved shades, changing only foreground -> background.
    return {'gauge_fill_'+k.removeprefix('gauge_'):'48;'+v[3:]
            for k,v in gauge_codes(mode).items()}
