import re
ANSI=re.compile(r'\x1b\[[0-9;]*m')
def clip(text,width):
 out=[];count=0;cursor=0
 for match in ANSI.finditer(text):
  segment=text[cursor:match.start()];take=segment[:max(0,width-count)];out.append(take);count+=len(take)
  if count>=width:break
  out.append(match.group());cursor=match.end()
 else:out.append(text[cursor:cursor+max(0,width-count)])
 return ''.join(out)+'\x1b[0m'
class StableRenderer:
 def __init__(self,write):self.write=write;self.previous=[];self.started=False;self.size=None
 def render(self,rows,columns=120,height=40):
  width=max(1,columns-1);limit=max(1,height-1);rows=[clip(r,width) for r in rows[:limit]];pieces=[]
  if not self.started:pieces=['\x1b[?1049h','\x1b[?25l','\x1b[H\x1b[2J'];self.started=True
  # The terminal may have been changed by local echo, screen or another writer.
  # Cached row equality cannot prove that a row is still visible: repaint the
  # whole owned viewport IN PLACE, including borders and static headings.
  # Clear only when entering the alternate screen. Clearing before each frame
  # creates a visible blank interval on HiveOS/screen/web terminals.
  for i in range(limit):
   new=rows[i] if i<len(rows) else '';old=self.previous[i] if i<len(self.previous) else None
   a=len(ANSI.sub('',new))
   pieces.append(f'\x1b[{i+1};1H'+new+' '*max(0,width-a))
  if pieces:self.write(''.join(pieces))
  self.previous=rows;self.size=(columns,height)
 def close(self):
  if self.started:self.write('\x1b[0m\x1b[?25h\x1b[?1049l');self.started=False

class TerminalInputGuard:
 """Suppress typed-character echo only; keep canonical input and signals intact."""
 def __init__(self,fd):self.fd=fd;self.saved=None
 def __enter__(self):
  try:
   import termios
   old=termios.tcgetattr(self.fd);new=list(old)
   new[3]&=~(termios.ECHO|termios.ECHONL)
   termios.tcsetattr(self.fd,termios.TCSANOW,new);self.saved=old
  except (ImportError,OSError,ValueError):pass
  return self
 def __exit__(self,*args):
  if self.saved is not None:
   try:
    import termios
    termios.tcsetattr(self.fd,termios.TCSANOW,self.saved)
   except (ImportError,OSError,ValueError):pass
