"""Exact completed-counter windows, including idle; retain a full24h boundary."""
import bisect,json,pathlib
from work_counter import advance
WINDOWS=(60,900,3600,21600,43200,86400)
class History:
 def __init__(self,devices,started):
  self.devices=tuple(devices);self.started=started;self.samples={d:([started],[0]) for d in self.devices};self.observed=set();self.complete=True
 def add(self,device,stamp,total):
  if device not in self.samples or type(total) is not int or total<0:self.complete=False;return
  times,values=self.samples[device]
  if stamp<times[-1]:self.complete=False;return
  try:total=advance(values[-1],total)
  except ValueError:self.complete=False;return
  times.append(stamp);values.append(total);self.observed.add(device)
  cut=bisect.bisect_right(times,stamp-86400)-1
  if cut>1024:del times[:cut];del values[:cut]
 def counters(self,now):
  result={}
  for d,(times,values) in self.samples.items():
   index=bisect.bisect_right(times,now)-1;result[d]=values[max(0,index)]
  return result
 def window(self,now,seconds,full=True):
  if not self.complete or (full and now-self.started<seconds):return None
  beginning=max(self.started,now-seconds);elapsed=now-beginning
  if elapsed<=0 or set(self.devices)!=self.observed:return None
  old=self.counters(beginning);new=self.counters(now)
  return {d:(new[d]-old[d])/elapsed/1e12 for d in self.devices}
 def averages(self,now):
  return {seconds:self.window(now,seconds) for seconds in WINDOWS}
class Telemetry:
 def __init__(self,base):
  self.base=pathlib.Path(base);pin=json.loads((self.base/'native-handle.json').read_text());spec=json.loads((self.base/'spec.json').read_text())
  self.started=pin['began_ns']/1e9;self.deadline=None if pin['deadline_ns'] is None else pin['deadline_ns']/1e9;self.devices=tuple(int(x) for x in spec['expected']['devices'].split(','));self.history=History(self.devices,self.started);self.offset=0;self.ends={}
 def consume(self):
  with (self.base/'host-stdout.log').open(encoding='utf-8') as f:
   f.seek(self.offset)
   while True:
    before=f.tell();line=f.readline()
    if not line:break
    if not line.endswith('\n'):f.seek(before);break
    if not line.startswith('{'):continue
    try:r=json.loads(line)
    except ValueError:continue
    d=r.get('device')
    if r.get('type')=='host-phase' and r.get('stage')=='gpu-finish-wait-decode':self.ends[d]=r['ended_monotonic_ns']/1e9
    elif r.get('type')=='native-device-work':
     stamp=self.ends.get(d)
     if stamp is None:self.history.complete=False
     else:self.history.add(d,stamp,r.get('raw_completed_macs_total'))
   self.offset=f.tell()
