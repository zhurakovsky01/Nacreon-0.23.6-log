"""PRL price and income estimate for the console (alex_kodiaq edit).

Sources (public, no keys), refreshed every 5 minutes in a background thread:
  - WhatToMine coin 469 (Pearl): network hashrate, block reward/time, its own
    reward estimate, PRL/BTC rate;
  - CoinGecko: PRL ("pearl-2") and BTC in USD.
Estimate = this rig's hashrate as reported by the miner. Pool fee and power
are not subtracted. Never touches the miner; failures just show "no data".
"""
import json, threading, time, urllib.request

WTM = 'https://whattomine.com/coins/469.json?hr=100&p=0&fee=0&cost=0'
CG = 'https://api.coingecko.com/api/v3/simple/price?ids=pearl-2,bitcoin&vs_currencies=usd'
EVERY = 300
_lock = threading.Lock()
_state = {'at': None, 'price': None, 'per_th': None, 'nethash': None, 'block_time': None,
          'reward': None, 'btc_rate': None, 'change24': None, 'error': None}
_started = [False]


def _get(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Nacreon-console/alex_kodiaq', 'Accept': 'application/json'})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read(1 << 20).decode('utf-8'))


def _num(v):
    try:
        v = float(v)
        return v if v == v and v not in (float('inf'), float('-inf')) else None
    except (TypeError, ValueError):
        return None


def refresh():
    new = {}
    error = None
    try:
        w = _get(WTM)
        block_time = _num(w.get('block_time'))
        reward = _num(w.get('block_reward24')) or _num(w.get('block_reward'))
        nethash = _num(w.get('nethash'))
        formula = None
        if block_time and reward and nethash:
            formula = 86400.0 / block_time * reward / nethash * 1e12   # PRL per day per TH/s
        wtm = _num(w.get('estimated_rewards'))
        wtm = wtm / 100.0 if wtm else None
        # Prefer WhatToMine's own figure when it agrees with the network numbers.
        per_th = wtm if wtm and formula and 0.7 < wtm / formula < 1.3 else formula or wtm
        rate = _num(w.get('exchange_rate'))
        rate24 = _num(w.get('exchange_rate24'))
        new.update(per_th=per_th, nethash=nethash, block_time=block_time, reward=reward, btc_rate=rate,
                   change24=(rate / rate24 - 1) * 100 if rate and rate24 else None)
    except Exception as e:
        error = 'whattomine: ' + type(e).__name__
    try:
        c = _get(CG)
        price = _num((c.get('pearl-2') or {}).get('usd'))
        btc = _num((c.get('bitcoin') or {}).get('usd'))
        if price is None and btc and new.get('btc_rate'):
            price = new['btc_rate'] * btc
        new['price'] = price
    except Exception as e:
        error = (error + ', ' if error else '') + 'coingecko: ' + type(e).__name__
        if new.get('btc_rate') is None:
            pass
    with _lock:
        for k, v in new.items():
            if v is not None:
                _state[k] = v
        if new:
            _state['at'] = time.time()
        _state['error'] = error


def _loop():
    while True:
        try:
            refresh()
        except Exception:
            pass
        time.sleep(EVERY)


def start():
    if _started[0]:
        return
    _started[0] = True
    threading.Thread(target=_loop, name='kodiaq-income', daemon=True).start()


def snapshot():
    with _lock:
        return dict(_state)
