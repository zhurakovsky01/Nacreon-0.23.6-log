# Third-party scope and notices — release packaging draft

This document maps notices to components. It does not grant rights in third-party
code or replace the original license texts. Third-party rights remain applicable
even when Nacreon's own contributions are distributed without their source.

| Component | Origin and scope | Notices to retain |
|---|---|---|
| cp-proof-ffi upstream FFI | CPPminer first-party Rust crate; the repository root MIT covers its upstream code. Local Nacreon additions are separately attributed and do not revoke upstream permissions. | Original-project-MIT.txt; Nacreon's own contribution terms |
| pearl-blake3 | Pearl-origin code vendored through CPPminer. Original Pearl code is reviewed under the Pearl root ISC; CPPminer changes retain the CPPminer MIT notice. Do not describe the entire component solely as Nacreon-owned code. | Pearl-root-ISC.txt and Original-project-MIT.txt |
| zk-pow | Pearl-origin code vendored through CPPminer; the original ISC scope and the fork's MIT contributions are kept separate. Its plonky2 dependencies retain their own MIT/Apache notices. | Pearl-root-ISC.txt, Original-project-MIT.txt and the relevant cargo/plonky2* notices |
| layout-macro | Pearl zk-pow procedural macro used during compilation. Missing Cargo license metadata is not itself a new license. Retain the Pearl original notice for this source/its generated contribution; no separate macro binary is shipped. | Pearl-root-ISC.txt; relevant third-party macro dependency notices |
| Registry crates | Exact compiled-package inventory and retained crate-specific notices. Build/test/proc-macro inventory is broader than a claim that every crate is linked into the released library. | Original files under cargo/, including the applicable alternatives and Unicode notice |
| Rust Standard Library1.90.0 | Statically incorporated std/core/alloc runtime from the exact toolchain identified by the byte-identical libproof build. Original generated Standard Library copyright material includes its own component notices; it does not claim that every supported platform's code is linked here. | rust-1.90.0/LICENSE-MIT, LICENSE-APACHE, COPYRIGHT and COPYRIGHT-library.html |
| NVIDIA CUDA Runtime | Statically incorporated runtime; CUDA12.8.1-family redistribution terms apply. The CUDA Toolkit, compiler, profilers and driver are not packaged as development tools with Nacreon. | cuda/CUDA-12.8.1-RUNTIME-LICENSE.txt; applicable NVIDIA agreement |

The inherited MIT texts in the local cargo directories came from a historical
parent-directory notice collector. They preserve the CPPminer notice; they are
not a claim that CPPminer's author exclusively owns the original Pearl code.
The separately supplied Pearl ISC notice must remain present and mapped above.

Primary pinned sources reviewed:

- CPPminer revision6785ad349a33f7bebb3ffe1dc1ad876b56d66ef8, root MIT:
  https://github.com/1640675651/CPPminer/blob/6785ad349a33f7bebb3ffe1dc1ad876b56d66ef8/LICENSE
- Pearl revision837c69c52a831fff5fa733a358da8b3ae7d8c35c, root ISC and the
  separately licensed subprojects identified there:
  https://github.com/pearl-research-labs/pearl/blob/837c69c52a831fff5fa733a358da8b3ae7d8c35c/LICENSE
- CUDA12.8.1 distribution requirements and Attachment A:
  https://docs.nvidia.com/cuda/archive/12.8.1/eula/index.html
- Rust1.90.0 release manifest and SHA-verified standard-library/compiler packages;
  only license files are retained, no compiler or runtime binaries are included:
  https://static.rust-lang.org/dist/channel-rust-1.90.0.toml

Publication remains held until the final package incorporates the reviewed
mapping/notices and the release checks are complete. This draft changes no
runtime bytes and asserts no rights over other authors' contributions.
