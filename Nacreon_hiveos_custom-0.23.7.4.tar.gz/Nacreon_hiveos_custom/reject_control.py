"""Owner-only hot control and sanitized one-file export. No miner signals."""
import argparse,json,os,pathlib,re,stat,sys,time
from reject_runtime import Store,H,ticks
from reject_journal import Journal,unique

def stores():
 count=0
 for root in ('/dev/shm','/run'):
  try:entries=os.scandir(root)
  except OSError:continue
  with entries:
   for item in entries:
    if not item.name.startswith('nacreon-reject-%d-'%os.geteuid()):continue
    count+=1
    if count>32:return
    store=None
    try:
     store=Store(item.path);owner=json.loads(store.read('owner.json',1024),object_pairs_hook=unique)
     if set(owner)!={'pid','start','slot','sha','version'}:raise ValueError('owner')
     if any(type(owner[k])is not int or owner[k]<=0 for k in ('pid','start','slot')):raise ValueError('owner')
     if not isinstance(owner['sha'],str) or not re.fullmatch('[0-9a-f]{64}',owner['sha']):raise ValueError('owner')
     if not isinstance(owner['version'],str) or not re.fullmatch(r'\d{1,3}\.\d{1,3}\.\d{1,3}',owner['version']):raise ValueError('owner')
     if ticks(owner['pid'])!=owner['start'] or H((pathlib.Path('/proc')/str(owner['pid'])/'exe').read_bytes())!=owner['sha']:raise ValueError('generation')
     yield store,owner
    except (OSError,ValueError,KeyError,TypeError):pass
    finally:
     if store is not None:store.close()

def validate_export(store):
 # Writer replaces segments then state atomically. A concurrent rotation may
 # invalidate the old state; bounded retries reject a torn export.
 for _ in range(3):
  try:
   original=store.read('state.json',4096);state=json.loads(original,object_pairs_hook=unique)
   if set(state)!={'generation','segments','enabled','failed','dropped','evicted','control_generation'}:raise ValueError('state')
   if any(type(state[k])is not int or not 0<=state[k]<2**64 for k in ('generation','dropped','evicted','control_generation')):raise ValueError('state')
   if type(state['enabled'])is not bool or type(state['failed'])is not bool:raise ValueError('state')
   if not isinstance(state['segments'],list) or not 1<=len(state['segments'])<=4:raise ValueError('segments')
   content=[];total=0;names=set()
   for row in state['segments']:
    if set(row)!={'name','sha256','bytes'} or not isinstance(row['name'],str) or not re.fullmatch('segment[0-3]\.jsonl',row['name']) or row['name'] in names:raise ValueError('segment')
    names.add(row['name']);b=store.read(row['name'],262144);total+=len(b)
    if total>1048576 or row['bytes']!=len(b) or row['sha256']!=H(b):raise ValueError('rotation')
    content.append(b)
   if store.read('state.json',4096)!=original:continue
   data=b''.join(content);lines=data.splitlines();header=json.loads(lines[0],object_pairs_hook=unique)
   if set(header)!={'schema','dropped','evicted','enabled','RAM_only'} or header['schema']!='NACREON_REJECT_JOURNAL_DRAFT_V1' or header['RAM_only']is not True:raise ValueError('header')
   if any(type(header[k])is not int or not 0<=header[k]<2**64 for k in ('dropped','evicted')) or type(header['enabled'])is not bool:raise ValueError('header')
   validator=Journal();validator.control('on')
   for line in lines[1:]:
    record=json.loads(line,object_pairs_hook=unique)
    if not validator.offer(record):raise ValueError('unsafe export record')
   return data,state
  except (OSError,ValueError,KeyError,TypeError,IndexError):continue
 raise ValueError('journal busy or invalid')

def main(args=None):
 parser=argparse.ArgumentParser(description='Nacreon reject diagnostics; same OS user as miner')
 parser.add_argument('command',choices=('on','off','status','export'));parser.add_argument('--output');options=parser.parse_args(args)
 outputs=[];count=0;pending=[];request=time.time_ns()
 for store,owner in stores():
  if options.command in ('on','off'):
   store.write('control.json',json.dumps({'enabled':options.command=='on','generation':request}).encode());pending.append((store.path,dict(owner)));count+=1
  elif options.command=='status':
   control=json.loads(store.read('control.json',256),object_pairs_hook=unique)
   outputs.append({'pid':owner['pid'],'requested_enabled':control.get('enabled')is True,'version':owner['version']});count+=1
  else:
   data,state=validate_export(store)
   source={'type':'journal_source','native_pid':owner['pid'],'native_start_ticks':owner['start'],'native_sha256':owner['sha'],'version':owner['version'],'rotation_generation':state['generation']}
   outputs.append(json.dumps(source,sort_keys=True).encode()+b'\n'+data);count+=1
 if not count:raise ValueError('no live journal-capable miner for this user')
 if pending:
  # One bounded shared deadline, not a timeout multiplied by worker count.
  end=time.monotonic()+3.
  while pending and time.monotonic()<end:
   remaining=[]
   for path,owner in pending:
    check=None
    try:
     check=Store(path);current=json.loads(check.read('owner.json',1024),object_pairs_hook=unique)
     if current!=owner or ticks(owner['pid'])!=owner['start']:raise ValueError('journal owner changed')
     applied=json.loads(check.read('state.json',4096),object_pairs_hook=unique)
     if applied.get('control_generation')!=request or applied.get('enabled')is not (options.command=='on') or applied.get('failed')is not False:remaining.append((path,owner))
    except OSError:remaining.append((path,owner))
    finally:
     if check is not None:check.close()
   pending=remaining
   if pending:time.sleep(.05)
  if pending:raise ValueError('diagnostic control not acknowledged')
 if options.command=='export':
  path=pathlib.Path(options.output or ('nacreon-rejects-'+time.strftime('%Y%m%d-%H%M%S',time.gmtime())+'-'+os.urandom(3).hex()+'.jsonl')).absolute()
  if path.parent.resolve()!=path.parent:raise ValueError('export parent symlink')
  st=path.parent.stat()
  if st.st_uid!=os.geteuid() or st.st_mode&0o022:raise ValueError('export parent ownership')
  fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
  try:
   with os.fdopen(fd,'wb') as f:
    for data in outputs:f.write(data)
  except Exception:
   try:path.unlink()
   except OSError:pass
   raise
  print(str(path));return 0
 print(json.dumps({'journals':count,'command':options.command,'status':outputs}));return 0

if __name__=='__main__':
 try:sys.exit(main())
 except (OSError,ValueError,KeyError,TypeError):print('Nacreon: diagnostic command unavailable or unsafe path',file=sys.stderr);sys.exit(2)
