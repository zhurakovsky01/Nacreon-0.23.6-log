"""Isolated CPU prototype; NOT integrated, installed or supported by 0.23.6.

No filesystem, socket, config, environment or mining operations. Caller supplies
already validated native ledger facts and an explicit per-native stream owner.
"""
import collections,json,math,re,threading,time

SAFE_WORDS=frozenset('a above accepted already bad block busy by check connection difficulty digest duplicate duplicated error expired failed found hash high invalid job low malformed mismatch missing not nonce of old pool proof rejected server share stale submitted target the timeout too unknown unsupported valid version work'.split())
PREFIXES=(b'[pool] submit response: ',b'[pool] jsonrpc: ',b'[native-pool-response] ')
RECORD_FIELDS=frozenset('type native_pid native_start_ticks stream_slot serial rpc_id device observed_monotonic reply_latency_ms connection_epoch job_age_seconds version native_sha256 pool_error_code pool_message reason_correlation raw_rpc_retained snapshot_totals snapshot_monotonic recorded_unix_ns'.split())

def integer(v,low=0,high=2**63-1):return type(v)is int and low<=v<=high
def number(v):return (type(v)is int and 0<=v<=10**18) or (type(v)is float and math.isfinite(v) and 0<=v<=10**18)
def unique(pairs):
 out={}
 for k,v in pairs:
  if k in out:raise ValueError('duplicate key')
  out[k]=v
 return out

def safe_message(message,credentials):
 if not isinstance(message,str) or len(message)>4096:return None
 # Decoded JSON text only. Never persist arbitrary words, numbers, binary,
 # wallet fragments, hashes, URLs, proofs, headers or ANSI/control text.
 # Known account/worker/password components are removed BEFORE token selection.
 if len(credentials)>32:return None
 for secret in sorted((s for s in credentials if isinstance(s,str) and s),key=len,reverse=True):
  if len(secret)>1024:return None
  message=re.sub(re.escape(secret),' [redacted] ',message,flags=re.I)
 words=re.findall(r'[A-Za-z]+|[^A-Za-z\s]+',message)
 out=[]
 for word in words[:80]:
  word=word.lower()
  token=word if word in SAFE_WORDS else '[redacted]'
  if token!='[redacted]' or not out or out[-1]!=token:out.append(token)
 result=' '.join(out)[:256]
 return result or None

def reply_summary(raw,credentials):
 """Returns ONLY sanitized response fields, never retains the raw RPC."""
 if not isinstance(raw,bytes) or len(raw)>8192:return None
 prefix=next((p for p in PREFIXES if raw.startswith(p)),None)
 if prefix is None:return None
 try:v=json.loads(raw[len(prefix):],object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
 except (ValueError,UnicodeError,RecursionError):return None
 if not isinstance(v,dict) or not integer(v.get('id'),2,2**31-1):return None
 error=v.get('error');clean=error is None
 # Same outcome rules as PoolLedger. Auth/unmatched/unknown must never emit.
 outcome='accepted' if v.get('result')is True and clean else 'rejected' if not clean or v.get('result')is False else 'unknown'
 code=message=None
 if isinstance(error,dict):
  code=error.get('code')
  if 'message'in error:
   message=error['message']
   if 'msg'in error and (type(error['msg'])is not type(message)or error['msg']!=message):message=None
  else:message=error.get('msg')
 elif isinstance(error,list) and 1<=len(error)<=3:
  code=error[0];message=error[1] if len(error)>1 else None
 elif integer(error,-2**31,2**31-1):code=error
 elif isinstance(error,str):message=error
 return {'rpc_id':v['id'],'outcome':outcome,'pool_error_code':code if integer(code,-2**31,2**31-1) else None,'pool_message':safe_message(message,credentials),'pool_message_policy':'decoded_known_credentials_redacted_then_fixed_vocabulary','raw_rpc_retained':False}

class Journal:
 """Bounded RAM-only design prototype. Nonwaiting offer; loss is explicit.

 Integration MUST call offer outside miner/pool locks, from stream-reader side.
 try-lock/drop cannot introduce waits into the native producer. This prototype
 does not claim to remove the existing stdout pipe's backpressure.
 """
 def __init__(self,max_bytes=1<<20,max_rows=2048):
  if not integer(max_bytes,512,1<<20) or not integer(max_rows,1,2048):raise ValueError('capacity')
  self.max_bytes=max_bytes;self.max_rows=max_rows;self.rows=collections.deque();self.bytes=0;self.enabled=False
  self.lock=threading.Lock();self.dropped=0;self.evicted=0
 def control(self,command):
  if command not in ('on','off'):raise ValueError('command')
  with self.lock:self.enabled=command=='on'
 def offer(self,record):
  if not self.enabled:return False
  # Closed export schema: callers cannot sneak raw payloads into the RAM ring.
  if not isinstance(record,dict) or set(record)!=RECORD_FIELDS:return False
  if record['type']!='rejected_share' or record['raw_rpc_retained']is not False:return False
  if any(not integer(record[k],1) for k in ('native_pid','native_start_ticks','stream_slot','serial','rpc_id')):return False
  if record['device']is not None and not integer(record['device'],0,31):return False
  if any(not number(record[k]) for k in ('observed_monotonic','reply_latency_ms')):return False
  if record['connection_epoch']is not None or record['job_age_seconds']is not None:return False
  if record['version']is not None and (not isinstance(record['version'],str) or not re.fullmatch(r'\d{1,3}\.\d{1,3}\.\d{1,3}',record['version'])):return False
  if record['native_sha256']is not None and (not isinstance(record['native_sha256'],str) or not re.fullmatch(r'[0-9a-f]{64}',record['native_sha256'])):return False
  if record['pool_error_code']is not None and not integer(record['pool_error_code'],-2**31,2**31-1):return False
  if record['snapshot_monotonic']is not None and not number(record['snapshot_monotonic']):return False
  if not integer(record['recorded_unix_ns'],1):return False
  totals=record['snapshot_totals']
  if totals is not None and (not isinstance(totals,dict) or set(totals)!={'accepted','rejected','unknown','pending'} or any(not integer(v,0,2**64-1) for v in totals.values())):return False
  text=record['pool_message']
  if text is not None and (not isinstance(text,str) or len(text)>256 or any(w not in SAFE_WORDS and w!='[redacted]' for w in text.split())):return False
  if record['reason_correlation'] not in ('same_owned_stream_id_time_unambiguous','unknown'):return False
  try:line=json.dumps(record,sort_keys=True,separators=(',',':'),allow_nan=False).encode()+b'\n'
  except (TypeError,ValueError):return False
  if len(line)>2048:self.dropped+=1;return False
  if not self.lock.acquire(False):self.dropped+=1;return False
  try:
   if not self.enabled:return False
   while self.rows and (len(self.rows)>=self.max_rows or self.bytes+len(line)>self.max_bytes):
    self.bytes-=len(self.rows.popleft());self.evicted+=1
   if len(line)>self.max_bytes:self.dropped+=1;return False
   self.rows.append(line);self.bytes+=len(line);return True
  finally:self.lock.release()
 def export(self):
  with self.lock:
   meta={'schema':'NACREON_REJECT_JOURNAL_DRAFT_V1','dropped':self.dropped,'evicted':self.evicted,'enabled':self.enabled,'RAM_only':True}
   return json.dumps(meta,sort_keys=True).encode()+b'\n'+b''.join(self.rows)

class Projector:
 def __init__(self,journal,credentials=()):
  self.journal=journal;self.credentials=tuple(credentials);self.replies=collections.OrderedDict();self.seen=collections.OrderedDict()
 def observe_line(self,owner,raw,received_at):
  # owner=(native PID,start_ticks,stream slot): supplied by launcher, NOT parsed
  # from user-controlled stdout. Unattributed mixed output is rejected.
  if not self.valid_owner(owner) or not number(received_at):return
  summary=reply_summary(raw,self.credentials)
  if summary is None or summary['outcome']!='rejected':return
  key=(owner,summary['rpc_id']);self.replies.setdefault(key,[]).append((received_at,summary))
  self.replies[key]=self.replies[key][-4:]
  while len(self.replies)>128:self.replies.popitem(last=False)
 @staticmethod
 def valid_owner(owner):return type(owner)is tuple and len(owner)==3 and all(integer(x,1) for x in owner)
 def ledger_event(self,owner,event,build='0.23.7',native_sha256=None,totals=None,snapshot_monotonic=None):
  """Actual validated PoolLedger rejected event is the ONLY emit authority.

  No raw stdout can create a share, GPU attribution or accepted/rejected count.
  Caller must pin the native process generation and validate snapshot schema.
  """
  if not self.valid_owner(owner) or not isinstance(event,dict):return False
  if event.get('result')!='rejected' or not integer(event.get('id'),2,2**31-1) or not integer(event.get('serial'),1):return False
  sent=event.get('sent_at');seen=event.get('observed_at')
  if not number(sent) or not number(seen) or seen<sent:return False
  dedup=(owner,event['serial'])
  if dedup in self.seen:return False
  self.seen[dedup]=True
  while len(self.seen)>2048:self.seen.popitem(last=False)
  candidates=[s for at,s in self.replies.pop((owner,event['id']),[]) if sent<=at<=seen+2]
  # Duplicate identical output from reader/host is one reason. Conflicting
  # reasons => UNKNOWN, never guess or borrow another worker's response.
  canonical={json.dumps(s,sort_keys=True) for s in candidates};summary=json.loads(next(iter(canonical))) if len(canonical)==1 else {}
  d=event.get('device');d=d if integer(d,0,31) else None
  # Version/hash are only admitted literals, not arbitrary loggable labels.
  version=build if isinstance(build,str) and re.fullmatch(r'\d{1,3}\.\d{1,3}\.\d{1,3}',build) else None
  sha=native_sha256 if isinstance(native_sha256,str) and re.fullmatch(r'[0-9a-f]{64}',native_sha256) else None
  record={'type':'rejected_share','native_pid':owner[0],'native_start_ticks':owner[1],'stream_slot':owner[2],'serial':event['serial'],'rpc_id':event['id'],'device':d,'observed_monotonic':seen,'reply_latency_ms':(seen-sent)*1000,'connection_epoch':None,'job_age_seconds':None,'version':version,'native_sha256':sha,'pool_error_code':summary.get('pool_error_code'),'pool_message':summary.get('pool_message'),'reason_correlation':'same_owned_stream_id_time_unambiguous' if summary else 'unknown','raw_rpc_retained':False,'snapshot_totals':totals,'snapshot_monotonic':snapshot_monotonic,'recorded_unix_ns':time.time_ns()}
  return self.journal.offer(record)
