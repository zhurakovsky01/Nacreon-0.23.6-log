"""Read-only public console: native stdout filter + approved full-screen view.

Never signals, controls or writes to the native miner or its files. Reads only
the owned stats snapshot (existing h-stats.py checks), one bounded nvidia-smi
CSV query, NVML offset readback, /proc host gauges and, for «Сбои», typed
native fault rows plus a bounded read-only kernel journal (public_faults.py).
Unsupported data stays unknown. Raw native lines are shown only in raw mode
(NACREON_RAW_CONSOLE=1); the normal view keeps typed, timestamped events.
Nothing is persisted.
"""
import bisect,collections,csv,datetime,hashlib,importlib.util,io,json,math,os,pathlib,re,shutil,signal,stat,subprocess,sys,threading,time
from urllib.parse import urlsplit
# Imported after the fixed local console directory has been added to sys.path.

HERE=pathlib.Path(__file__).resolve().parent
if str(HERE) not in sys.path:sys.path.insert(0,str(HERE))
from snapshot_contract import validate_snapshot
try:
    # Approved renderer and its dependencies are used unchanged, never copied.
    import rich_design,design,core_offsets
    from stable_renderer import StableRenderer,TerminalInputGuard
    from session_totals import SessionTotals
    from period_metrics import PeriodMetrics
    from host_gauges import HostSampler
    from branding import label
    from local_clock import clock as local_clock
    import reject_reasons
    import kodiaq_view
    IMPORT_ERROR=None
except Exception as exc:  # Missing/damaged package file: raw passthrough instead.
    IMPORT_ERROR=type(exc).__name__
try:import public_faults  # Optional: absent -> «Сбои» stay '—'.
except Exception:public_faults=None

UUID=re.compile(r'gpu-[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}')
DECIMAL=re.compile(r'[0-9]{1,39}')
FRAME=5.0;SAMPLE_FRAME=1.0;SENSOR_FRAME=3.0;GAP=10.0;FRESH=5.0;SENSOR_AGE=6.0;OFFSET_EVERY=15.0;OFFSET_AGE=30.0
MAX_LINE=65536;DIAG_CHARS=160;UNKNOWN_WORKER='нет данных'
ROUTINE_TYPES={'native-device-work','native-job'}
FAULT_TYPES=('native-device-idle','native-device-fault')
IDLE_KEYS=('schema','device','generation','uuid','sequence','coverage_since','through','idle_seconds','valid')
FIELDS='uuid,name,temperature.gpu,fan.speed,clocks.current.graphics,clocks.current.memory,power.draw'
LIMITS=(('temp',150),('fan',100),('core',10000),('memory',30000),('power',2000))
# Native USER pool telemetry (shares.user.telemetry). Fixed reason texts only.
TELEMETRY='NACREON_POOL_TELEMETRY_V1';EVENT_LIMIT=32;CLOCK_SLACK=1e-3
JOB_ID=re.compile(r'[A-Za-z0-9_.:-]{1,64}')
REASONS={'invalid':'invalid share reported by pool','stale':'stale job reported by pool',
         'duplicate':'duplicate share reported by pool','other':'rejected by pool (reason not classified)'}
EVENT_CATEGORY={'accepted':'accepted','invalid':'invalid','stale':'stale','duplicate':'duplicate','other':'отклонено'}
NATIVE_SOURCE='native_user_pool_ledger'
HISTORY=16;RAW_HINT='NACREON_RAW_CONSOLE=1'
TZ=datetime.timezone(datetime.timedelta(hours=3))  # same clock zone as the approved renderer
# Native rate methods. 'legacy': hs = raw MAC counter delta / ~30 s full wall.
# 'batch': hs = latest backend-confirmed batch MACs / host submit-to-finish seconds;
# period/session rates are then arithmetic means of fresh per-snapshot batch rates.
LEGACY_RATE='completed_raw_MAC_per_elapsed_second_including_idle_prep_drain'
BATCH_RATE='confirmed_backend_batch_MAC_per_host_submit_to_finish_second'
BATCH_SCOPE='latest_completed_backend_batch_per_device'
BATCH_SESSION_METHOD='Arithmetic mean of fresh native latest-batch rates per observed snapshot since first confirmed batch; not pool credited work'

class Unavailable(Exception):
    """Fixed public reason; arbitrary exception text is never displayed."""

def finite(value):return type(value) in (int,float) and math.isfinite(value)

def load_helper(path,name):
    spec=importlib.util.spec_from_file_location(name,str(path))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def load_helpers(directory=HERE.parent):
    """Existing secure snapshot reader and output filter from the package root."""
    found=[]
    for file,name in (('h-stats.py','nacreon_hstats'),('console-filter.py','nacreon_console_filter')):
        try:found.append(load_helper(pathlib.Path(directory)/file,name))
        except Exception:found.append(None)
    return tuple(found)

def public_labels(environ=None):
    """Read only labels from the same private generated config; never retain credentials."""
    env=os.environ if environ is None else environ
    worker=env.get('NACREON_CONSOLE_WORKER') or env.get('WORKER_NAME')
    pools=[];path=env.get('NACREON_CONSOLE_CONFIG')
    if path:
        try:
            fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
            with os.fdopen(fd,'rb') as f:
                st=os.fstat(f.fileno())
                if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.geteuid() or st.st_nlink!=1 or st.st_mode&0o077 or st.st_size>65536:raise ValueError('private config')
                payload=f.read(65537)
            if len(payload)>65536 or not payload.startswith(b'NACREON_ARGS_V1\0') or not payload.endswith(b'\0'):raise ValueError('config')
            args=[v.decode('utf-8') for v in payload.split(b'\0')[1:-1]]
            for i,key in enumerate(args[:-1]):
                if key in ('--worker','-r'):worker=args[i+1]
                elif key in ('--wallet','-w') and worker is None and '.' in args[i+1]:worker=args[i+1].rsplit('.',1)[1]
                elif key in ('--pool','-o'):pools.append(args[i+1])
        except (OSError,ValueError,UnicodeError):pass
    supplied=env.get('NACREON_CONSOLE_POOL')
    if supplied:pools=[supplied]
    worker=worker if isinstance(worker,str) and re.fullmatch(r'[A-Za-z0-9_.-]{1,63}',worker) else UNKNOWN_WORKER
    pool=None
    if len(pools)==1:
        try:
            u=urlsplit(pools[0] if '://' in pools[0] else '//'+pools[0])
            if u.username is None and u.password is None and not u.query and not u.fragment and u.path in ('','/') and u.hostname and u.port:
                host=u.hostname
                if re.fullmatch(r'[A-Za-z0-9.:-]{1,253}',host):pool=('['+host+']' if ':' in host else host)+':'+str(u.port)
        except ValueError:pass
    return worker,pool

# ---------------------------------------------------------------- snapshot

def counter(value):
    """One decimal 128-bit USER raw MAC counter -> lifetime work, else None."""
    if not isinstance(value,list) or len(value)!=1 or not all(isinstance(v,str) and DECIMAL.fullmatch(v) for v in value):return None
    parts=[int(v) for v in value]
    return sum(parts) if all(v<1<<128 for v in parts) else None

def batch_rate(device,mono,running):
    """Validated native latest-batch rate (TH/s) and its sequence; (None, seq|None) if unmeasured.

    hs must equal canonical_macs/elapsed_seconds of a 'measured' batch whose
    completion is not after the snapshot and whose age is within its native limit.
    """
    b=device.get('batch');hs=device.get('hs')
    if not isinstance(b,dict):return None,None
    seq=b.get('sequence')
    if type(seq) is not int or not 0<=seq<2**64:return None,None
    if running is not True or device.get('valid') is not True or b.get('scope')!='measured' or b.get('valid') is not True:return None,seq
    macs=b.get('canonical_macs');sent=b.get('submitted_at');done=b.get('completed_at')
    elapsed=b.get('elapsed_seconds');age=b.get('age_seconds');limit=b.get('max_age_seconds')
    if seq<1 or type(macs) is not int or not 0<macs<2**64:return None,seq
    if not all(finite(x) for x in (hs,sent,done,elapsed,age,limit)):return None,seq
    if not (0<=sent<done<=mono+CLOCK_SLACK and elapsed>0 and abs(done-sent-elapsed)<=CLOCK_SLACK):return None,seq
    if not (elapsed<=600 and abs(limit-min(120.,max(10.,4*elapsed)))<=CLOCK_SLACK):return None,seq
    if not (0<=age<=limit and abs(max(0.,mono-done)-age)<=CLOCK_SLACK):return None,seq
    if not hs>0 or abs(hs-macs/elapsed)>1e-9*hs:return None,seq
    return hs/1e12,seq

def shares(value):
    if not isinstance(value,dict):return None
    row=tuple(value.get(k) for k in ('accepted','rejected','unknown','pending'))
    return row if all(type(n) is int and n>=0 for n in row) else None

def telemetry(value,mono,total,order):
    """Validated native user pool telemetry. Raises on any type/bound/identity violation."""
    def need(ok):
        if not ok:raise ValueError('telemetry')
    def num(v,optional=True):
        if v is None:
            need(optional);return None
        need(finite(v) and v>=0);return float(v)
    def cnt(v):
        need(type(v) is int and 0<=v<2**64);return v
    def at(v):  # same epoch as monotonic_seconds; never after the snapshot itself
        x=num(v);need(x is None or x<=mono+CLOCK_SLACK);return x
    def age(stamp,v):
        x=num(v);need((stamp is None)==(x is None))
        if x is not None:need(abs(mono-stamp-x)<=CLOCK_SLACK)
        return x
    need(isinstance(value,dict) and value['schema']==TELEMETRY and value['clock']=='monotonic_seconds')
    need(value.get('coverage')=='session_ledger_process_lifetime' and value.get('ack_timing')=='local_submit_call_to_reply_parse')
    c=value['connection'];need(isinstance(c,dict))
    connected=c['connected'];need(type(connected) is bool)
    connections=cnt(c['connections']);reconnections=cnt(c['reconnections'])
    need(reconnections<=max(0,connections-1) and (connections>0 or not connected))
    connected_at=at(c['connected_at']);lost_at=at(c['lost_at'])
    need((connected_at is not None)==connected and (lost_at is None or not connected))
    connection_age=age(connected_at,c['connection_age_seconds']);offline=age(lost_at,c['current_offline_seconds'])
    last_offline=num(c['last_offline_seconds']);need(last_offline is None or reconnections>0)
    observed_offline=num(c.get('observed_offline_seconds',None if not connections else (offline if not connected else last_offline or 0.0)))
    j=value['job'];need(isinstance(j,dict))
    job_id=j['id'];need(job_id is None or (isinstance(job_id,str) and JOB_ID.fullmatch(job_id) is not None))
    received=at(j['received_at']);job_age=age(received,j['age_seconds'])
    need((received is not None or job_id is None) and (connected or received is None))
    r=value['rejected'];need(isinstance(r,dict) and set(r)==set(REASONS))
    rejected={k:cnt(r[k]) for k in REASONS}
    need(total is None or sum(rejected.values())==total[1])
    last_serial=cnt(value['last_serial']);rows=value['events']
    need(isinstance(rows,list) and len(rows)<=min(EVENT_LIMIT,last_serial))
    events=[];previous=0
    for e in rows:
        need(isinstance(e,dict));serial=cnt(e['serial']);need(previous<serial<=last_serial);previous=serial
        rid=e['id'];need(type(rid) is int and 0<rid<2**31)
        device=e['device'];need(device is None or (type(device) is int and device in order))
        result,category,reason=e['result'],e['category'],e['reason']
        if result=='accepted':need(category=='accepted' and reason is None)
        else:need(result=='rejected' and isinstance(category,str) and category in REASONS and reason==REASONS[category])
        sent=num(e['sent_at'],False);seen=at(e['observed_at']);need(seen is not None and sent<=seen)
        latency=num(e['latency_ms']);need(latency is None or abs(latency-(seen-sent)*1000)<=0.01)
        events.append(dict(serial=serial,id=rid,device=device,category=category,reason=reason,observed_at=seen,latency_ms=latency))
    last_ack=num(value['last_ack_latency_ms']);need(last_ack==(events[-1]['latency_ms'] if events else None))
    mean=num(value['mean_recent_ack_latency_ms']);timed=[e['latency_ms'] for e in events if e['latency_ms'] is not None]
    need((mean is None)==(not timed) and (not timed or abs(mean-sum(timed)/len(timed))<=0.01))
    return dict(connected=connected,connections=connections,reconnections=reconnections,connection_age=connection_age,
                offline=offline,last_offline=last_offline,observed_offline=observed_offline,job_id=job_id,job_age=job_age,rejected=rejected,
                last_serial=last_serial,events=events,last_ack=last_ack,mean_ack=mean)

def map_snapshot(snapshot,now=None,wall_ns=None):
    """Validated USER-only V2 snapshot -> unchanged public view."""
    now=time.monotonic() if now is None else now;wall_ns=time.time_ns() if wall_ns is None else wall_ns
    snapshot=validate_snapshot(snapshot,now)
    order=[];uuids={};rates={};totals={};full_wall={};sequences={}
    mono=float(snapshot['monotonic_seconds']);method=snapshot.get('rate_method')
    # A claimed batch method without its exact scope/clock is unknown, never legacy.
    kind=('batch' if snapshot.get('rate_scope')==BATCH_SCOPE and snapshot.get('rate_clock')=='monotonic_seconds' else 'unknown') if method==BATCH_RATE else 'legacy' if method in (LEGACY_RATE,None) else 'unknown'
    for device in snapshot['devices']:
        d=device['index'];uuid=device['uuid']
        if type(d) is not int or d in uuids or not isinstance(uuid,str) or not UUID.fullmatch(uuid.lower()):raise ValueError('device identity')
        order.append(d);uuids[d]=uuid;hs=device.get('hs')
        wall=device.get('full_wall_hs') if kind=='batch' else hs
        full_wall[d]=wall/1e12 if device.get('valid') is True and finite(wall) and wall>=0 else None
        if kind=='batch':rates[d],sequences[d]=batch_rate(device,mono,snapshot.get('running'))
        else:rates[d]=full_wall[d] if kind=='legacy' else None
        totals[d]=counter(device.get('raw_macs'))
    user=snapshot['shares']['user'];total=shares(user.get('total'));counts=per=None
    window=snapshot.get('full_wall_rate_window_seconds') if kind=='batch' else snapshot.get('rate_window_seconds')
    native=None;native_invalid=False
    if 'telemetry' in user:
        try:native=telemetry(user['telemetry'],mono,total,order)
        except (ValueError,KeyError,TypeError):native_invalid=True
    if total:
        # Native exact user totals; reason breakdown only from validated native telemetry.
        counts=dict(accepted=total[0],rejected=total[1],unknown=total[2],invalid=None,stale=None,duplicate=None)
        if native is not None:counts.update({k:native['rejected'][k] for k in ('invalid','stale','duplicate')})
        rows=user.get('devices')
        if isinstance(rows,dict) and set(rows)<={str(d) for d in order}:
            per={k:dict(accepted=t[0],rejected=t[1]) for k,v in rows.items() if (t:=shares(v))}
    journal=None
    rows=user.get('devices')
    if counts is not None and isinstance(rows,dict) and set(rows)<={str(d) for d in order}:
        valid={k:shares(value) for k,value in rows.items()}
        if (all(v is not None and v[2]==0 for v in valid.values())
                and sum(v[0] for v in valid.values())==total[0]
                and sum(v[1] for v in valid.values())==total[1]):
            journal={d:valid.get(str(d),(0,0,0,0))[:2] for d in order}
    return dict(generation=(snapshot['pid'],snapshot['start_ticks'],snapshot['boot_id']),monotonic=mono,
                uptime=snapshot['uptime'],version=snapshot.get('version'),devices=order,uuids=uuids,rates=rates,
                totals=totals,counts=counts,shares=total,per_gpu_shares=per,pending=total[3] if total else None,
                rate_window=window if finite(window) and window>0 else None,
                wall_ns=wall_ns-int(max(0,now-mono)*1e9),user_ready=snapshot.get('user_ready'),journal_shares=journal,
                telemetry=native,telemetry_invalid=native_invalid,
                rate_method=kind,full_wall_rates=full_wall,batch_sequences=sequences)

class CounterWindows:
    """Exact native counter deltas between sampled snapshots; gaps restart coverage.

    Attaching mid-run never seeds a zero: a period is shown only once a real
    snapshot exists at or before its start. Bounded to 24h of samples.
    """
    def __init__(self,devices,limit=100000):
        self.devices=tuple(devices);self.samples=collections.deque(maxlen=limit)
    def add(self,t,totals,share_row):
        last=self.samples[-1] if self.samples else None
        if last and t<=last[0]:return
        work=tuple(totals.get(d) for d in self.devices)
        if any(n is None for n in work) or (last and (t-last[0]>GAP or any(a>b for a,b in zip(last[1],work)))):self.samples.clear()
        if any(n is None for n in work):return
        self.samples.append((t,work,share_row))
        while len(self.samples)>2 and self.samples[1][0]<=t-86400:self.samples.popleft()
    def window(self,now,seconds):
        s=self.samples
        if not s or not 0<=now-s[-1][0]<=GAP or s[0][0]>now-seconds:return None,None
        a=s[bisect.bisect_right(s,now-seconds,key=lambda x:x[0])-1];b=s[-1];elapsed=b[0]-a[0]
        if elapsed<=0:return None,None
        rates={d:(y-x)/elapsed/1e12 for d,x,y in zip(self.devices,a[1],b[1])}
        pair=None
        # Confirmed ACK deltas remain exact even if an unrelated submission is unresolved.
        if a[2] and b[2] and b[2][0]>=a[2][0] and b[2][1]>=a[2][1]:pair=(b[2][0]-a[2][0],b[2][1]-a[2][1])
        return rates,pair

class BatchRateWindows:
    """Arithmetic means of fresh native latest-batch rates, one sample per observed snapshot.

    Any unknown device rate, a gap >GAP or a time reversal restarts coverage; a
    period is shown only when one unbroken run reaches its start. Never zero-filled.
    Samples hold cumulative sums, so each window is O(log n). Bounded to 24h.
    """
    def __init__(self,devices,limit=100000):
        self.devices=tuple(devices);self.samples=collections.deque(maxlen=limit)
    def add(self,t,rates):
        last=self.samples[-1] if self.samples else None
        if last and t<=last[0]:return
        row=tuple(rates.get(d) for d in self.devices)
        bad=any(not finite(r) or r<0 for r in row)
        if bad or (last and t-last[0]>GAP):self.samples.clear()
        if bad:return
        prior=self.samples[-1] if self.samples else (t,(0.,)*len(row),0)
        self.samples.append((t,tuple(a+b for a,b in zip(prior[1],row)),prior[2]+1))
        while len(self.samples)>2 and self.samples[1][0]<=t-86400:self.samples.popleft()
    def window(self,now,seconds):
        s=self.samples;start=now-seconds
        if not s or not 0<=now-s[-1][0]<=GAP or s[0][0]>start:return None
        a=s[bisect.bisect_right(s,start,key=lambda x:x[0])-1];b=s[-1];n=b[2]-a[2]
        if n<=0:return None
        return {d:(y-x)/n for d,x,y in zip(self.devices,a[1],b[1])}

class ConsoleState:
    """All derived history for ONE native generation; replaced on any reset."""
    def __init__(self,view,power_seed=None):
        self.generation=view['generation'];self.devices=tuple(view['devices']);self.uuids=dict(view['uuids'])
        t=view['monotonic'];u=view['uptime']
        self.started_display=t-u
        self.windows=CounterWindows(self.devices);self.periods=PeriodMetrics(self.devices)
        key=hashlib.sha256(json.dumps(list(self.generation)).encode()).hexdigest()
        # Integer uptime: true start lies in (t-u-1,t-u]. Use the earliest bound so
        # session elapsed is never understated (mean rate never overstated).
        # Native counters are process-lifetime, so session counts are exact.
        # Before 29s, the formatter still retains its startup zero sample.
        # Its exact rate-window then supplies session start without integer-uptime rounding.
        window=view['rate_window']
        self.exact_start=(t-window if u<29 and window is not None and u<=window<u+1.001 else None)
        started=self.exact_start if self.exact_start is not None else t-u-1
        seed=power_seed(started) if callable(power_seed) else power_seed
        self.session=SessionTotals(key,self.devices,started,capture_from_start=True,power_seed=seed)
        self.summary={};self.last=None
        # Batch method only: period means from batch samples; session mean only if
        # this state saw every device before its first batch and never lost a sample.
        self.rate_method=view.get('rate_method','legacy');self.batch=BatchRateWindows(self.devices)
        seen=view.get('batch_sequences') or {}
        self.batch_session=dict(sums=(0.,)*len(self.devices),n=0,last=None,
                                ok=self.exact_start is not None and all(seen.get(d)==0 for d in self.devices))
        # Footer history: ACCEPTED user shares only; rejects update last_rejected/counts.
        self.recent_events=collections.deque(maxlen=3)
        self.recent_rejects=collections.deque(maxlen=3)
        self.journal_baseline=None;self.journal_at=None;self.last_rejected=None
        # Once native events (or a native telemetry block) were seen, counter deltas never add events.
        self.native_serial=0;self.authoritative=False

    def observe_native(self,native):
        """Native user ledger events, each exactly once by serial; wire id and local send-to-reply time."""
        for e in native['events']:
            if e['serial']<=self.native_serial:continue
            self.native_serial=e['serial']
            event=dict(device=e['device'],category=EVENT_CATEGORY[e['category']],id=e['id'],observed_at=e['observed_at'],
                       latency_ms=e['latency_ms'],error=e['reason'],source=NATIVE_SOURCE)
            if e['category']=='accepted':self.recent_events.append(event)
            else:self.last_rejected=dict(event);self.recent_rejects.append(dict(event))
            try:kodiaq_view.share_event(event)
            except Exception:pass
    def observe_journal(self,view):
        """Confirmed user counter changes; timestamps are observations, never wire ACK times."""
        current=view['journal_shares'];stamp=view['monotonic']
        if view.get('telemetry') is not None or view.get('telemetry_invalid'):self.authoritative=True
        if view.get('telemetry') is not None:self.observe_native(view['telemetry'])
        if self.authoritative:
            self.journal_baseline=current;self.journal_at=stamp;return
        previous=self.journal_baseline
        if (current is not None and previous is not None and self.journal_at is not None
                and 0<stamp-self.journal_at<=GAP
                and all(current[d][i]>=previous[d][i] for d in self.devices for i in (0,1))):
            for device in self.devices:
                for index,category in ((0,'accepted'),(1,'отклонено')):
                    difference=current[device][index]-previous[device][index]
                    for _ in range(min(difference,3)):
                        event=dict(device=device,category=category,id='—',observed_at=stamp,
                                   latency_ms=None,error=None,source='confirmed_user_counter_delta')
                        try:kodiaq_view.share_event(event if index==0 else dict(event,error='причина не передана статистикой'))
                        except Exception:pass
                        if index==0:self.recent_events.append(event)
                        else:self.last_rejected=dict(event,error='причина не передана статистикой');self.recent_rejects.append(dict(self.last_rejected))
        self.journal_baseline=current;self.journal_at=stamp
    def observe_batch_session(self,t,rates):
        """Session mean of batch samples; any loss after the first batch voids it (never bridged)."""
        s=self.batch_session;row=tuple(rates.get(d) for d in self.devices)
        if s['last'] is not None and t-s['last']>GAP:s['ok']=False
        s['last']=t
        if all(finite(r) and r>=0 for r in row):s['sums']=tuple(a+b for a,b in zip(s['sums'],row));s['n']+=1
        elif s['n']:s['ok']=False
    def batch_session_rate(self):
        s=self.batch_session
        return sum(s['sums'])/s['n'] if s['ok'] and s['n'] else None
    def needs_reset(self,view):
        if view['generation']!=self.generation or tuple(view['devices'])!=self.devices or view['uuids']!=self.uuids:return True
        if view.get('rate_method','legacy')!=self.rate_method:return True
        if self.last is None:return False
        old,new=self.last['totals'],view['totals']
        if any(old.get(d) is not None and new.get(d) is not None and new[d]<old[d] for d in self.devices):return True
        x,y=self.last.get('batch_sequences') or {},view.get('batch_sequences') or {}
        if any(x.get(d) is not None and y.get(d) is not None and y[d]<x[d] for d in self.devices):return True
        x,y=self.last.get('telemetry'),view.get('telemetry')
        if x and y and (y['last_serial']<x['last_serial'] or y['connections']<x['connections']):return True
        a,b=self.last['shares'],view['shares']
        return bool(a and b and (b[0]<a[0] or b[1]<a[1] or b[2]<a[2]))
    def observe(self,view,cards,power_stamp,idle):
        t=view['monotonic']
        if self.last is not None and t<=self.last['monotonic']:return
        counts=view['counts']
        snap=dict(updated_monotonic=t,counts=dict(accepted=counts['accepted'],rejected=counts['rejected']) if counts else None,
                  counts_complete=counts is not None,cards=cards,detail=dict(per_gpu_idle_samples=idle))
        self.windows.add(t,view['totals'],view['shares'])
        # Period share counts come from exact native deltas, not PeriodMetrics events.
        self.periods.observe(dict(snap,counts=None,counts_complete=False))
        self.summary=self.session.observe(snap,{d:n for d,n in view['totals'].items() if n is not None},cards,power_stamp)
        # Current rates stay fresh native batch rates. Historical means instead use
        # confirmed lifetime work over elapsed time, including measured quiet time.
        # Missing instantaneous rates do not erase valid native counter history.
        if self.rate_method!='batch' and (self.exact_start is None or self.rate_method!='legacy'):
            self.summary.update(mean_rate=None,efficiency=None)
        # Native counters span the entire process lifetime, including viewer gaps.
        # Keep confirmed outcomes separate from submissions with no known outcome.
        if counts is not None:
            a,r=counts['accepted'],counts['rejected'];n=a+r
            self.summary.update(accepted=a,rejected=r,unknown=counts['unknown'],rejected_percent=100*r/n if n else None)
        self.observe_journal(view)
        self.last=view
    def metrics(self,now):
        averages={};metrics={};last=self.last['monotonic'] if self.last else None
        for seconds,_ in rich_design.PERIODS:
            # Rate and sampled watts share the same last native endpoint, even
            # when rendering happens later than the stats writer's update.
            rates,pair=self.windows.window(last,seconds) if last is not None and 0<=now-last<=GAP else (None,None)
            # Period average is confirmed completed work / observed period elapsed.
            # Unknown current batch speed is not a missing counter or an invented zero.
            if self.rate_method not in ('legacy','batch'):rates=None
            m=dict(self.periods.window(last,seconds)) if last is not None and 0<=now-last<=GAP else {}
            m.update(accepted=None,rejected=None,rejected_percent=None)
            if pair:
                n=sum(pair);m.update(accepted=pair[0],rejected=pair[1],rejected_percent=100*pair[1]/n if n else None)
            averages[seconds]=rates;metrics[seconds]=m
        return averages,metrics

# ---------------------------------------------------------------- sensors

def parse_sensors(text):
    out={}
    for row in csv.reader(io.StringIO(text),skipinitialspace=True):
        if len(row)!=7:continue
        uuid=row[0].strip().lower()
        if not UUID.fullmatch(uuid):continue
        if uuid in out:return {}  # Ambiguous UUID: no sensor may be attributed.
        values=dict(name=label(row[1].strip(),64) or None)
        for (key,maximum),field in zip(LIMITS,row[2:]):
            try:value=float(field)
            except ValueError:value=math.nan
            values[key]=value if math.isfinite(value) and 0<=value<=maximum else None
        out[uuid]=values
    return out

def query_sensors(run=subprocess.run):
    """One read-only query, hard 2s timeout (run() kills the child on expiry)."""
    try:
        p=run(['nvidia-smi','--query-gpu='+FIELDS,'--format=csv,noheader,nounits'],stdin=subprocess.DEVNULL,
              capture_output=True,text=True,timeout=2)
        if p.returncode or len(p.stdout)>65536:return {}
        return parse_sensors(p.stdout)
    except (OSError,subprocess.SubprocessError,UnicodeError,ValueError):return {}

def mean_power(points,start,end):
    """Trapezoid over sampled power covering [start, last sample<=end]; else None."""
    if not points or end<=start or end-points[-1][0]>SENSOR_AGE:return None
    i=bisect.bisect_right(points,start,key=lambda p:p[0])-1
    if i<0:return None
    energy=covered=0.
    for (t0,p0),(t1,p1) in zip(points[i:],points[i+1:]):
        if p0 is None or p1 is None or t1-t0>GAP:return None
        lo,hi=max(start,t0),min(end,t1)
        if hi<=lo:continue
        a=p0+(p1-p0)*(lo-t0)/(t1-t0);b=p0+(p1-p0)*(hi-t0)/(t1-t0)
        energy+=(a+b)/2*(hi-lo);covered+=hi-lo
    return energy/covered if covered>0 else None

class Sensors:
    """Sensor cache keyed by physical UUID; stale or unmatched values are unknown."""
    def __init__(self,query=query_sensors,offsets=None,clock=time.monotonic):
        self.query=query;self.offsets_reader=offsets or core_offsets.attach;self.clock=clock
        self.lock=threading.Lock();self.uuids={};self.latest={};self.at=None;self.names={}
        self.history=collections.deque(maxlen=64);self.offsets={};self.offsets_at=None
    def sample(self):
        values=self.query();at=self.clock()
        with self.lock:
            # A failed query must not erase the previous still-fresh reading.
            # cards() still expires it after SENSOR_AGE; no gap is filled forever.
            if values:
                self.latest=values;self.at=at
            if len(self.names)>64:self.names.clear()
            self.names.update({u:v['name'] for u,v in values.items() if v.get('name')})
            if values:self.history.append((at,{u:v.get('power') for u,v in values.items()}))
        uuids=dict(self.uuids)
        if uuids and (self.offsets_at is None or at-self.offsets_at>=OFFSET_EVERY):
            found={}
            for card in self.offsets_reader({d:{'uuid':u} for d,u in uuids.items()}).values():  # NVML readback only.
                row=card.get('core_offset')
                if isinstance(row,dict) and row.get('uuid')==card.get('uuid'):found[card['uuid']]=row
            with self.lock:self.offsets=found;self.offsets_at=self.clock()
    def power_seed(self,uuids,started):
        # Only an actually observed prefix can cover the native session start.
        # A late viewer never reconstructs an unobserved historical interval.
        with self.lock:
            for stamp,values in reversed(self.history):
                if stamp>started:continue
                if started-stamp>SENSOR_AGE:return None
                powers={str(d):{'power':values.get(u.lower())} for d,u in uuids.items()}
                if all(finite(c['power']) and c['power']>=0 for c in powers.values()):return stamp,powers
                return None
        return None
    def stamp(self):
        with self.lock:return self.at
    def cards(self,uuids,now):
        with self.lock:
            fresh=self.at is not None and 0<=now-self.at<=SENSOR_AGE
            offsets=self.offsets if self.offsets_at is not None and 0<=now-self.offsets_at<=OFFSET_AGE else {}
            out={}
            for d,uuid in uuids.items():
                v=self.latest.get(uuid.lower()) if fresh else None
                card={'name':self.names.get(uuid.lower()) or 'UNKNOWN'}
                card.update({k:(v.get(k) if v else None) for k,_ in LIMITS})
                if uuid in offsets:card.update(uuid=uuid,core_offset=dict(offsets[uuid]))
                out[str(d)]=card
            return out
    def mean_power(self,uuid,start,end):
        with self.lock:points=[(t,m.get(uuid.lower())) for t,m in self.history]
        return mean_power(points,start,end)

# ---------------------------------------------------------------- native output

def parse_json(raw):
    if len(raw)>=MAX_LINE or not raw.lstrip().startswith(b'{'):return None
    try:value=json.loads(raw)
    except (ValueError,UnicodeError,RecursionError):return None
    return value if isinstance(value,dict) else None

class EventHistory:
    """Typed source events (fault / connection), each once by key. Bounded RAM only."""
    def __init__(self,limit=HISTORY):
        self.lock=threading.Lock();self.rows=collections.deque(maxlen=limit);self.keys=collections.deque(maxlen=4*limit);self.fault_keys=set()
    def add(self,key,monotonic,role,source,text):
        with self.lock:
            if key[0] in ('cuda','xid'):
                if key in self.fault_keys or len(self.fault_keys)>=9216:return
                self.fault_keys.add(key)  # <=32 native generations*256 CUDA +1024 Xid details
            else:
                if key in self.keys:return
                self.keys.append(key)
            self.rows.append(dict(monotonic=monotonic,role=label(role,24),source=label(source,40),text=label(text,80)))
    def recent(self):
        with self.lock:return [dict(r) for r in self.rows]

class Intake:
    """Routes native lines. Bounded RAM only: 8 console notes, 16 idle rows per GPU, 16 typed events.

    Typed fault rows reach the fault scope with all fields BEFORE the display
    filter. Untyped raw lines are counted, not displayed (raw mode keeps them).
    """
    def __init__(self,display,expected_pid,faults=None,history=None,clock=time.monotonic):
        self.display=display;self.pid=expected_pid;self.lock=threading.Lock();self.faults=faults
        self.history=history if history is not None else EventHistory();self.clock=clock
        self.notes=collections.deque(maxlen=8);self.idle={};self.hidden=0
    def note(self,text):
        """Console-generated fixed texts only; never raw native output."""
        text=label(text,DIAG_CHARS).strip()
        if not text:return
        with self.lock:
            if self.notes and self.notes[-1][0]==text:self.notes[-1][1]+=1
            else:self.notes.append([text,1])
    def recent(self):
        with self.lock:return [t+(' ×'+str(n) if n>1 else '') for t,n in self.notes]
    def hidden_lines(self):
        with self.lock:return self.hidden
    def keep_idle(self,record):
        d=record.get('device');generation=record.get('generation')
        if type(d) is not int or not 0<=d<32 or not isinstance(generation,str) or generation.split('-',1)[0]!=str(self.pid):return
        with self.lock:self.idle.setdefault(d,collections.deque(maxlen=16)).append({k:record.get(k) for k in IDLE_KEYS})
    def idle_rows(self,uuids):
        with self.lock:return {str(d):[dict(r) for r in self.idle.get(d,()) if r['uuid']==u] for d,u in uuids.items()}
    def line(self,raw):
        record=parse_json(raw);kind=record.get('type') if record is not None else None
        if kind in FAULT_TYPES:
            if self.faults is not None:self.faults.consume(record)
            if kind=='native-device-idle':self.keep_idle(record)
            return  # typed: shown via «Сбои» cells and the validated event history
        if kind=='pool-lifecycle' and record.get('stage')=='reader-connection-lost':
            # Keep unqualified typed events unqualified; never invent attribution.
            role={'user':'USER'}.get(record.get('role'),'роль не указана')
            at=self.clock();self.history.add(('pool-lost',at),at,role,'пул (native pool-lifecycle)','соединение потеряно')
            return
        visible=self.display(raw)
        if not visible:return
        if record is not None and visible==raw and kind in ROUTINE_TYPES and record.get('error') is None and record.get('last_execution_error') is None:return
        if visible.startswith((b'Nacreon stopped:',b'CUDA error:')):
            at=self.clock();self.history.add(('native-error',at),at,'NATIVE','вывод майнера','сообщена ошибка; подробности: '+RAW_HINT)
        with self.lock:self.hidden+=1  # raw text stays only in NACREON_RAW_CONSOLE=1 mode

# ---------------------------------------------------------------- view

def waiting_data(now):
    s=dict(running=True,worker=UNKNOWN_WORKER,updated_unix_ns=time.time_ns(),updated_monotonic=now,detail={},cards={})
    return dict(snapshot=s,rates={},counts=None,now=now,stale=True,devices=[],mean_power={},averages={},metrics={},
                session_metrics={},started=now,link_metrics={})

def native_link(native,lag):
    """Observed transport metrics from the native user ledger; unknowns stay None."""
    ahead=lambda value:None if value is None else value+lag
    offline=native['observed_offline']
    if offline is not None and not native['connected'] and native['offline'] is not None:offline+=lag
    return dict(reconnect_count=native['reconnections'],connection_count=native['connections'],offline_seconds=offline,
                transport_connected_seconds=ahead(native['connection_age']),source=NATIVE_SOURCE)

class Console:
    def __init__(self,stats,path,expected_pid,intake,sensors,host=None,faults=None):
        self.stats=stats;self.path=path;self.pid=expected_pid;self.intake=intake;self.sensors=sensors;self.host=host
        self.faults=faults;self.history=intake.history
        self.pinned=None;self.state=None;self.view=None;self.problem=None
        self.worker,self.pool=public_labels()
    def read(self,now):
        if self.stats is None:raise Unavailable('модуль h-stats.py недоступен')
        if not self.path:raise Unavailable('путь NACREON_STATS_FILE не задан')
        try:snapshot=getattr(self.stats,'read_console_snapshot',self.stats.read_snapshot)(self.path)  # existing NOFOLLOW/owner/mode/nlink/PID/boot/<=5s checks
        except FileNotFoundError:raise Unavailable('файл статистики ещё не создан') from None
        except OSError:raise Unavailable('файл статистики недоступен') from None
        except (ValueError,KeyError,TypeError,IndexError,AttributeError,RecursionError):raise Unavailable('статистика устарела или не прошла проверку') from None
        if snapshot.get('pid')!=self.pid:raise Unavailable('статистика другого процесса (PID не совпадает)')
        try:view=map_snapshot(snapshot,now)
        except (ValueError,KeyError,TypeError,AttributeError):raise Unavailable('формат статистики не распознан') from None
        if self.view is not None and view['generation']==self.view['generation'] and view['monotonic']<self.view['monotonic']:raise Unavailable('время статистики пошло назад')
        if self.pinned is None:self.pinned=view['generation']
        elif view['generation']!=self.pinned:raise Unavailable('процесс майнера сменился; статистика отклонена')
        return view
    def refresh(self,now=None):
        now=time.monotonic() if now is None else now
        try:view=self.read(now)
        except Unavailable as exc:self.problem=str(exc);return
        self.problem=None
        if self.state is None or self.state.needs_reset(view):
            if self.state is not None:self.intake.note('счётчики майнера сброшены; статистика периодов начата заново')
            self.state=ConsoleState(view,power_seed=lambda started:self.sensors.power_seed(view['uuids'],started))
        self.view=view;self.sensors.uuids=dict(view['uuids'])
        cards=self.sensors.cards(view['uuids'],now)
        self.state.observe(view,cards,self.sensors.stamp(),self.intake.idle_rows(view['uuids']))
        self.link_events(view)
        if self.faults is not None:
            self.faults.bind(view);self.fault_events(view,self.faults.public(now,view['generation']))
    def link_events(self,view):
        """USER transitions from validated native user telemetry only (no stdout reason parsing)."""
        native=view.get('telemetry')
        if native is None:return
        n=native['connections']
        unknown=view['shares'][2] if view.get('shares') else 0
        if unknown:
            self.history.add(('user-unconfirmed',view['generation'],unknown),view['monotonic'],'USER','подтверждение пула','Без подтверждения результата: '+str(unknown)+'; принято/отклонено учитываются отдельно')
        if not native['connected'] and native['offline'] is not None:
            self.history.add(('user-lost',view['generation'],n),view['monotonic']-native['offline'],'USER','телеметрия пула','соединение потеряно')
        if native['connected'] and native['reconnections']>0 and native['connection_age'] is not None:
            self.history.add(('user-up',view['generation'],n),view['monotonic']-native['connection_age'],'USER','телеметрия пула','соединение восстановлено')
    def fault_events(self,view,faults):
        """Validated, generation/UUID-pinned reports only; fixed texts, no raw kernel messages."""
        device={u:d for d,u in view['uuids'].items()}
        for e in (faults.get('gpu_execution_faults') or {}).get('events',[]):
            if e.get('uuid') in device:
                self.history.add(('cuda',e['event_reference']),e['monotonic_us']/1e6,'GPU #'+str(device[e['uuid']]),'проверка CUDA (native)',e['code'])
        for e in (faults.get('gpu_faults') or {}).get('events',[]):
            if e.get('uuid') in device:
                self.history.add(('xid',e['uuid'],e['monotonic_us'],e['xid']),e['monotonic_us']/1e6,'GPU #'+str(device[e['uuid']]),'журнал ядра','NVIDIA Xid '+str(e['xid']))
    def clock(self,monotonic):
        v=self.view
        wall=v['wall_ns']/1e9+monotonic-v['monotonic'] if v else time.time()-time.monotonic()+monotonic
        return local_clock(wall)
    def events(self):
        return [self.clock(e['monotonic'])+'  '+e['role']+' · '+e['source']+' · '+e['text'] for e in self.history.recent()]
    def diagnostics(self):
        notes=self.intake.recent()+self.events()
        return ['Статистика: '+self.problem]+notes[-2:] if self.problem else notes[-3:]
    def closing(self):
        """EOF summary: console notes and typed events; raw text is only counted."""
        lines=self.intake.recent()+self.events()
        hidden=self.intake.hidden_lines()
        if hidden:lines.append('скрыто строк исходного вывода: '+str(hidden)+'; полный вывод: '+RAW_HINT)
        return lines
    def data(self,now):
        data=waiting_data(now) if self.state is None else self._data(now)
        if self.host is not None:data.update(host_metrics=self.host.snapshot(),host_scope=dict(self.host.scope))
        return data
    def _data(self,now):
        v=self.view;st=self.state
        stale=self.problem is not None or not 0<=now-v['monotonic']<=FRESH
        averages,metrics=st.metrics(now);w=v['rate_window']
        mean={d:(self.sensors.mean_power(u,v['monotonic']-w,v['monotonic']) if w else None) for d,u in v['uuids'].items()}
        detail={} if v['per_gpu_shares'] is None else {'per_gpu_shares':v['per_gpu_shares']}
        detail['recent_events']=[] if stale else list(st.recent_events)
        if self.pool is not None:detail['pool']=self.pool
        native=None if stale else v.get('telemetry');link={};lag=max(0.,now-v['monotonic'])
        if native is not None:
            detail.update(last_ACK_latency_ms=native['last_ack'],mean_recent_ACK_latency_ms=native['mean_ack'],
                          job_age_seconds=None if native['job_age'] is None else native['job_age']+lag)
            link=native_link(native,lag)
        status='ESTABLISHED' if v['user_ready'] is True and not stale else 'UNKNOWN'
        if native is not None and not native['connected']:status='DISCONNECTED'
        snap=dict(running=True,worker=self.worker,version=v['version'],updated_unix_ns=v['wall_ns'],updated_monotonic=v['monotonic'],
                  cards=self.sensors.cards(v['uuids'],now),detail=detail,inflight_observed=v['pending'],connection_status=status)
        if native is not None:
            snap.update(job=native['job_id'],connection_count=native['connections'],counts_complete=True)
        data=dict(snapshot=snap,devices=list(v['devices']),rates={d:(None if stale else r) for d,r in v['rates'].items()},
                  counts=None if stale else v['counts'],now=now,stale=stale,mean_power=mean,
                  averages={} if stale else averages,metrics={} if stale else metrics,
                  session_metrics={} if stale else st.summary,started=st.started_display,link_metrics=link,
                  last_rejected=None if stale else st.last_rejected,
                  recent_rejects=[] if stale else list(st.recent_rejects),uuids=dict(v['uuids']))
        # «Сбои» inputs for the packaged gpu_faults cells; stale/unscoped -> absent -> '—'.
        if self.faults is not None and not stale:data.update(self.faults.public(now,v['generation']))
        return data

def frame_rows(data,notes,height,gauge_mode=None,columns=124):
    # alex_kodiaq: compact view with event feed; the original layout stays as fallback.
    # The renderer clips each row to columns-1; build exactly that wide so frames keep their right edge.
    try:return design.ansi(kodiaq_view.build(data,height,max(1,columns-1),notes),gauge_mode)
    except Exception:pass
    """Approved rows unchanged. Event lines use spare rows only; they never displace
    the accepted-share tail. Undersized screens drop middle rows, not the tail."""
    rows=design.ansi(rich_design.build(data),gauge_mode)
    extra=design.ansi([design.L(design.S('Событие: ','yellow'),design.S(label(t,110),'dim')) for t in notes],gauge_mode)
    limit=max(1,height-1)
    if len(rows)+len(extra)<=limit:return rows+extra
    if len(rows)<=limit:return rows+extra[len(extra)-(limit-len(rows)):] if limit>len(rows) else rows
    tail=min(3,len(data.get('snapshot',{}).get('detail',{}).get('recent_events',[])),limit)
    note=extra[-1:] if limit-tail>=2 else []
    return rows[:limit-tail-len(note)]+note+(rows[len(rows)-tail:] if tail else [])

class Output:
    """Serialized terminal writes. A vanished terminal never stops input draining."""
    def __init__(self,write):self.raw=write;self.lock=threading.Lock();self.closed=False;self.dead=False
    def write(self,text):
        with self.lock:
            if self.closed or self.dead:return
            try:self.raw(text)
            except (OSError,ValueError):self.dead=True
    def final(self,text):
        with self.lock:
            if text and not self.closed and not self.dead:
                try:self.raw(text)
                except (OSError,ValueError):self.dead=True
            self.closed=True

def make_faults(expected_pid):
    if public_faults is None:return None
    try:return public_faults.FaultMonitor(expected_pid)
    except Exception:return None

def run_screen(stdin,write,stats,display,path,expected_pid,size=shutil.get_terminal_size,sensors=None,host=None,frame=FRAME,faults=None):
    out=Output(write);intake=Intake(display,expected_pid,faults);sensors=sensors or Sensors()
    console=Console(stats,path,expected_pid,intake,sensors,host,faults);renderer=StableRenderer(out.write);stop=threading.Event()
    def paint(draw=True):
        try:
            console.refresh()
            if draw:
                columns,lines=size()
                renderer.render(frame_rows(console.data(time.monotonic()),console.diagnostics(),lines,columns=columns),columns,lines)
        except Exception:intake.note('консоль: ошибка построения кадра')
    def painter():
        # Collect current native snapshots at1s independently of the5s screen.
        # Both state observation and drawing stay on this one thread.
        next_draw=time.monotonic()+frame
        while not stop.wait(min(frame,SAMPLE_FRAME)):
            now=time.monotonic();draw=now>=next_draw
            paint(draw)
            if draw:next_draw=now+frame
    def sampler():
        while not stop.is_set():
            began=time.monotonic()
            for job in (sensors.sample,host.sample if host is not None else None):
                if job is None:continue
                try:job()
                except Exception:pass
            stop.wait(max(.1,SENSOR_FRAME-(time.monotonic()-began)))
    paint()
    threads=[threading.Thread(target=painter,name='nacreon-console-render',daemon=True),
             threading.Thread(target=sampler,name='nacreon-console-sensors',daemon=True)]
    for thread in threads:thread.start()
    try:
        while True:
            raw=stdin.readline(MAX_LINE)
            if not raw:break
            try:reject_reasons.observe(raw);kodiaq_view.observe(raw)
            except Exception:pass
            try:intake.line(raw)
            except Exception:intake.note('консоль: строка вывода не разобрана')
    except (OSError,ValueError):pass  # Unreadable input ends the reader like EOF.
    finally:
        stop.set();threads[0].join(5)
        if faults is not None:
            try:faults.close()
            except Exception:pass
        closing=[];renderer.write=closing.append;renderer.close()
        # Leave the alternate screen first, then a bounded readable summary (no raw diagnostics).
        out.final(''.join(closing)+''.join('[Nacreon] '+label(t,DIAG_CHARS)+'\n' for t in console.closing()))
        threads[1].join(3)
    return 0

def passthrough(stdin,stdout,display=None):
    """Raw or line-filtered copy; keeps draining if the terminal disappears."""
    alive=True
    try:
        for raw in iter(lambda:stdin.readline(MAX_LINE),b''):
            try:data=display(raw) if display else raw
            except Exception:data=raw
            if data and alive:
                try:stdout.write(data);stdout.flush()
                except (OSError,ValueError):alive=False
    except (OSError,ValueError):pass
    return 0

def parse_pid(value):
    return int(value) if isinstance(value,str) and value.isdigit() and 0<int(value)<2**31 else os.getppid()

def make_host():
    try:return HostSampler('console-'+str(os.getpid()),pathlib.Path('/proc/sys/kernel/random/boot_id').read_text()[:128])
    except (OSError,ValueError):return None

def main():
    # The native owns INT/TERM/HUP/QUIT; the reader must drain until native EOF.
    for name in ('SIGINT','SIGTERM','SIGHUP','SIGQUIT'):
        if hasattr(signal,name):
            try:signal.signal(getattr(signal,name),signal.SIG_IGN)
            except (OSError,ValueError):pass
    stdin,stdout=sys.stdin.buffer,sys.stdout.buffer
    stats,filt=load_helpers() if IMPORT_ERROR is None else (None,None)
    if filt is None:
        try:sys.stderr.write('[Nacreon] консоль недоступна; показан исходный вывод майнера\n');sys.stderr.flush()
        except (OSError,ValueError):pass
        return passthrough(stdin,stdout)
    if not stdout.isatty():return passthrough(stdin,stdout,filt.display)
    def write(text):stdout.write(text.encode('utf-8','replace'));stdout.flush()
    pid=parse_pid(os.environ.get('NACREON_EXPECTED_PID'))
    try:
        with TerminalInputGuard(stdout.fileno()):
            return run_screen(stdin,write,stats,filt.display,os.environ.get('NACREON_STATS_FILE') or None,
                              pid,host=make_host(),faults=make_faults(pid))
    except Exception:
        return passthrough(stdin,stdout,filt.display)

if __name__=='__main__':sys.exit(main())
