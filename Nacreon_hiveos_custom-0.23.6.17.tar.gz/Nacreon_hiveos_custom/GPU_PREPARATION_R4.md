> Historical note for an earlier ELF; it does not qualify this rebuilt candidate.

# GPU preparation r4 candidate, 23 October 2026

Private USER-only experimental Nacreon, native3014. CPU build/26checks and actual prepool fullK65536/16words/8digest/zero/4096coordinates passed on both RTX5070. A500-second measurement of this corrected native has NOT completed. First physical startup ended after2.965s because the external research observer mishandled unmeasured None rates; that observer is separate from these standalone launchers. No performance, pool-credit/payout, total-fee-zero or extended-stability qualification is claimed.

GPU preparation uses own normalize/repack kernels instead of copying full basis GPU→CPU→GPU. Seeds/rowroots/proof still use CPU. Foreign search/proof bytes and own USER routing are unchanged. Only own Nacreon commission is absent by scoped user instruction; third-party fee absence is not established by this package.

Prior private2 notes and archived private1 evidence are historical. This file supersedes any inference that earlier native hashes/results apply to native3014. Final current approved-changes coverage and exact-package CPU gate are still pending. Not authorized for publication.
