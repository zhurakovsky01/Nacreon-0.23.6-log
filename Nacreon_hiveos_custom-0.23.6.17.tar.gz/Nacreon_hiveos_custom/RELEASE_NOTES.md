# Nacreon 0.23.6

Уменьшены задержки при смене заданий на видеокартах RTX 50. Исправлены расчёт средних ватт, эффективности и история простоя в статистике.

[Команды настройки GPU](https://github.com/liked-lab/Nacreon-Miner/blob/v0.23.6/README.md#gpu-settings): частоты ядра и памяти, offset, лимит мощности и вентиляторы.

Reduced job-transition delays on RTX 50 GPUs. Corrected average power, efficiency and idle-history statistics.

[GPU tuning commands](https://github.com/liked-lab/Nacreon-Miner/blob/v0.23.6/README.md#gpu-settings).
