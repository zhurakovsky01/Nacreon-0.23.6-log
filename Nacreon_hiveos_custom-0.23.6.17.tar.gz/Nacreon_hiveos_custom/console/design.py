"""Selected option3. Same structure/colors; adds 12h and24h averages."""
from local_clock import clock as local_clock
import datetime
COLS=114
def S(t,c='text',bold=False):return (str(t),c,bold)
def L(*parts):return [S(p) if isinstance(p,str) else p for p in parts]
def length(line):return sum(len(t) for t,_,_ in line)
def plain(line):return ''.join(t for t,_,_ in line)
def rule(width):return L(S('─'*width,'dim'))
def number(x,d=2):return '--' if x is None else f'{x:.{d}f}'
def duration(x):
 if x is None:return '--'
 x=max(0,int(x));return f'{x//3600:02d}:{x//60%60:02d}:{x%60:02d}'
def total(values):return sum(values.values()) if values and all(v is not None for v in values.values()) else None
def row(items,widths,colors,bold=()):
 out=[S('│ ','dim')]
 for i,(item,width) in enumerate(zip(items,widths)):
  text=str(item);text=text[:width];out.append(S(text.ljust(width) if i==1 else text.rjust(width),colors[i],i in bold));out.append(S(' │ ' if i<len(items)-1 else ' │','dim'))
 return out
def average_rows(averages):
 lines=[]
 for group in (((60,'1 мин'),(900,'15 мин'),(3600,'1 ч')),((21600,'6 ч'),(43200,'12 ч'),(86400,'1 день'))):
  line=L(S('Средние TH/s: ' if not lines else '              ','dim'))
  for index,(seconds,label) in enumerate(group):
   if index:line.append(S('   │   ','dim'))
   value=total(averages.get(seconds));line.append(S(label+' '+(number(value) if value is not None else 'сбор данных'),'blue' if value is not None else 'dim',value is not None))
  lines.append(line)
 return lines
def build(data,width=114):
 s=data['snapshot'];detail=s.get('detail',{});cards=s.get('cards',{});rates=data['rates'];counts=data['counts'];shares=detail.get('per_gpu_shares') if counts is not None else None;now=data['now'];uptime=max(0,now-data['started']);worker=s['worker'];live=s['running'] and not data['stale'];status='РАБОТАЕТ' if live else 'ОСТАНОВЛЕН' if not s['running'] else 'ДАННЫЕ УСТАРЕЛИ'
 wall=s['updated_unix_ns']/1e9;stamp=local_clock(wall)
 lines=[L(S('NACREON','cyan',True),S('  /  PearlHash'),S(' '*16),S('WORKER '+worker,'cyan',True),S(' '*13),S(status,'green' if live else 'yellow',True)),L(S(stamp+'   ·   Скорость за30с, шары по каждой GPU','dim')),rule(width)]
 widths=[3,15,7,6,8,8,6,6,4,5];headers=['GPU','Модель','Принято','Откл.','TH/s','Вт','TH/Вт','°C','Вент','HW']
 if width<100:widths=[3,9,7,6,7,6,5,3];headers=['GPU','Модель','Принято','Откл.','TH/s','Вт','°C','Вент']
 lines += [row(headers,widths,['cyan','cyan','green','red']+['cyan']*(len(widths)-5)+['dim'],range(len(widths))),L(S('├'+'┼'.join('─'*(w+2) for w in widths)+'┤','dim'))]
 for d in data['devices']:
  card=cards.get(str(d),{});per=shares.get(str(d)) if shares else None;rate=rates.get(d);power=card.get('power');name=card.get('name','UNKNOWN').removeprefix('NVIDIA ').removeprefix('GeForce ')
  mean=data['mean_power'].get(d);eff=rate/mean if rate is not None and mean not in (None,0) else None
  items=[d,name,per['accepted'] if per else '--',per['rejected'] if per else '--',number(rate),number(power,1),number(eff,3),number(card.get('temp'),0),number(card.get('fan'),0),'--'];colors=['cyan','text','green','red','green','yellow','green','magenta','cyan','dim']
  if width<100:items=items[:6]+[items[7],items[8]];colors=colors[:6]+[colors[7],colors[8]]
  lines.append(row(items,widths,colors,(2,3,4)))
 lines.append(L(S('├'+'┼'.join('─'*(w+2) for w in widths)+'┤','dim')))
 power_values=[c.get('power') for c in cards.values()];watts=sum(power_values) if power_values and all(p is not None for p in power_values) else None
 accepted=counts.get('accepted') if counts else None;rejected=counts.get('rejected') if counts else None;denominator=accepted+rejected if accepted is not None and rejected is not None else 0;percentage=100*accepted/denominator if denominator else None
 lines += [L(S(number(total(rates))+' TH/s','green',True),S('   │   '+number(watts,1)+' Вт','yellow'),S('   │   '+str(accepted if accepted is not None else '--')+' / '+str(rejected if rejected is not None else '--'),'green',True),S(' принято / отклонено'),S('   │   Успешно '+number(percentage)+'%','green')),L(S('Invalid '+str(counts.get('invalid','--') if counts else '--')+'   Stale '+str(counts.get('stale','--') if counts else '--')+'   Duplicate '+str(counts.get('duplicate','--') if counts else '--')),S('   │   В ожидании '+str(s.get('inflight_observed','--')),'dim'),S('   │   HW — нет данных','dim')),L()]
 lines += average_rows(data['averages'])
 clocks=[(c.get('core'),c.get('memory')) for c in cards.values()];clocks_text='Ядро / память: '+'; '.join(f'GPU{d} {number(cards.get(str(d),{}).get("core"),0)}/{number(cards.get(str(d),{}).get("memory"),0)} MHz' for d in data['devices'])
 lines += [L(S('Сеанс '+number(data['session_rate'])+' TH/s','green'),S('   │   '+clocks_text)),rule(width),L(S('СОЕДИНЕНИЕ','cyan',True),S('   '+detail.get('pool','prl.kryptex.network:7048')),S('   '+s.get('connection_status','UNKNOWN'),'green')),L(S('ACK сейчас '+number(detail.get('last_ACK_latency_ms'),0)+' мс','cyan'),S('   │   Среднее '+number(detail.get('mean_recent_ACK_latency_ms'),0)+' мс / '+str(detail.get('ACK_latency_samples',0))+' ответов'),S('   │   Сеанс связи '+duration(detail.get('authorized_session_seconds')),'dim')),L(S('Задание '+str(s.get('job') or '--'),'cyan'),S('   │   Получено '+number(detail.get('job_age_seconds'),0)+' с назад'),S('   │   Последний ACK '+number(s.get('last_share_age_seconds'),0)+' с назад','dim')),L(S('Время работы ','dim'),S(duration(uptime),bold=True),S('   │   '+('До конца ' if s['running'] else 'Тест завершён '),'dim'),S(duration(data['deadline']-now) if s['running'] else '—','cyan',True)),rule(width),L(S('ВРЕМЯ      GPU  РЕЗУЛЬТАТ       SHARE    ACK','cyan',True))]
 events=detail.get('recent_events',[])[-4:]
 if not events:lines.append(L(S('Ожидание ответов пула','dim')))
 for e in reversed(events):
  when=wall+(e['observed_at']-s['updated_monotonic']);clock=local_clock(when);device='--' if e.get('device') is None else str(e['device']);label={'accepted':'ПРИНЯТО','invalid':'INVALID','stale':'STALE','duplicate':'DUPLICATE','other_rejected':'ОТКЛОНЕНО','unknown':'НЕИЗВЕСТНО'}.get(e['category'],e['category'])
  lines.append(L(S(clock+'    '+device.rjust(1)+'   ','dim'),S(label.ljust(14),'green' if e['category']=='accepted' else 'red',True),S(str('#'+str(e['id'])).rjust(5)+'    '+number(e.get('latency_ms'),0)+' мс')))
 return lines
def ansi(lines,gauge_mode=None):
 from terminal_colors import gauge_codes, gauge_background_codes, text_codes
 codes={'text':'37','dim':'90','cyan':'36','green':'32','yellow':'33','red':'31','magenta':'35','blue':'94','gauge_base':'38;2;69;168;117','gauge_amber':'38;2;192;147;68','gauge_red':'38;2;189;91;91'}
 codes.update(gauge_codes(gauge_mode))
 codes.update(gauge_background_codes(gauge_mode))
 codes.update(text_codes(gauge_mode))
 return [''.join('\x1b['+('1;' if bold else '')+codes[color]+'m'+text+'\x1b[0m' for text,color,bold in line) for line in lines]
