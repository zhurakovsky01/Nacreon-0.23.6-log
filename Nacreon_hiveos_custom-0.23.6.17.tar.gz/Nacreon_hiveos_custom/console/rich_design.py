"""Approved separated SRB-like layout. Never invent missing measurements."""
from core_offsets import cell as core_offset_cell
import datetime
import math
from host_gauges import host_gauge_lines, observed_reconnect_count
from branding import label, title, DEVELOPER, REPOSITORY, EDITOR, EDITION
import reject_reasons
from local_clock import clock as local_clock
from design import S,L,number,duration,total,ansi,plain,length
from gpu_faults import gpu_fault_cell, total_fault_cell

COLS=124
PERIODS=[(60,'1 мин'),(900,'15 мин'),(3600,'1 час'),(21600,'6 часов'),(43200,'12 часов'),(86400,'24 часа')]
def count(value):return '—' if value is None else str(value)

def elapsed_age(value):
    """Bounded two-unit age; preserve the event instead of accumulating seconds."""
    if type(value) not in (int,float) or not math.isfinite(value) or value<0:return '—'
    seconds=int(value)
    if seconds<60:return str(seconds)+' с'
    if seconds<3600:return str(seconds//60)+' мин '+str(seconds%60)+' с'
    if seconds<86400:return str(seconds//3600)+' ч '+str(seconds%3600//60)+' мин'
    days=seconds//86400
    return str(days)+' дн '+str(seconds%86400//3600)+' ч' if days<1000 else '999+ дн'
def idle_number(metric,key,digits=2):
    value=metric.get(key)
    if value is None:return number(None,digits)
    if value>0 and metric.get('idle_measurement')=='NACREON_SCHEDULER_CONFIRMED_IDLE_LOWER_BOUND':
        # Never round a lower bound upward or present it as an exact duration.
        scale=10**digits
        return '≥'+number(math.floor(value*scale)/scale,digits)
    return number(value,digits)
def rule(width):return L(S('─'*width,'dim'))
def section(text,width):
    text='  '+text+'  '
    return L(S('═══','dim'),S(text,'cyan',True),S('═'*max(0,width-3-len(text)),'dim'))
def row(items,widths,colors,bold=(),center=False):
    out=[S('│' if center else '│ ','dim')]
    for i,(item,width,color) in enumerate(zip(items,widths,colors)):
        text=label(item,128)
        if len(text)>width:text=text[:max(0,width-1)]+'…'
        # Borders enclose width+2 chars in the first cell and width+1 in
        # every following cell. Center within that actual interior; centering
        # only the text slot previously left a one-sided trailing margin.
        if center:out += [S(text.center(width+(2 if i==0 else 1)),color,i in bold),S('│','dim')]
        else:out += [S(text.ljust(width) if i in (0,1) else text.rjust(width),color,i in bold),S(' │','dim')]
    return out

def border(widths,left='├',middle='┼',right='┤'):
    return L(S(left+middle.join('─'*(w+(2 if i==0 else 1)) for i,w in enumerate(widths))+right,'dim'))

def average_rows(averages,metrics=None,session=None):
    metrics=metrics or {};widths=[14,14,11,9,9,9,9]
    lines=[border(widths,'┌','┬','┐'),row(['Период','Средний TH/s','Средн. Вт','TH/Вт','Принято','Откл.','Откл. %'],widths,['cyan']*7,range(7),center=True),border(widths)]
    for seconds,name in PERIODS:
        speed=total(averages.get(seconds));m=metrics.get(seconds,{})
        watts=m.get('mean_power');eff=speed/watts if speed is not None and watts else None
        values=[name,number(speed) if speed is not None else 'сбор данных',number(watts,1),number(eff,3),count(m.get('accepted')),count(m.get('rejected')),number(m.get('rejected_percent'))]
        colors=['blue' if speed is not None else 'dim']*7
        colors[4:7]=['green' if m.get('accepted') is not None else 'dim','red' if m.get('rejected') is not None else 'dim','red' if m.get('rejected_percent') is not None else 'dim']
        lines.append(row(values,widths,colors,(0,1,4,5)))
    m=session or {};speed=m.get('mean_rate');watts=m.get('mean_power')
    values=['За сеанс',number(speed),number(watts,1),number(m.get('efficiency'),3),count(m.get('accepted')),count(m.get('rejected')),number(m.get('rejected_percent'))]
    colors=['blue' if speed is not None else 'dim']*7
    colors[4:7]=['green' if m.get('accepted') is not None else 'dim','red' if m.get('rejected') is not None else 'dim','red' if m.get('rejected_percent') is not None else 'dim']
    lines.append(row(values,widths,colors,(0,1,4,5)))
    lines.append(border(widths,'└','┴','┘'))
    return lines

def build(data,width=124):
    s=data['snapshot'];detail=s.get('detail',{});cards=s.get('cards',{});rates=data['rates'];counts=data['counts'];now=data['now']
    shares=detail.get('per_gpu_shares') if counts is not None else None
    live=s['running'] and not data['stale'];status='РАБОТАЕТ' if live else 'ОСТАНОВЛЕН' if not s['running'] else 'ДАННЫЕ УСТАРЕЛИ'
    wall=s['updated_unix_ns']/1e9
    clock=local_clock
    lines=[L(S(title(s),'cyan',True)),L(S('Разработчик: '+DEVELOPER+' + доработка '+EDITOR+' ('+EDITION+')  |  '+REPOSITORY,'dim')),L(S('PearlHash  |  Worker '+label(s['worker'],63)),S('  |  '+clock(wall),'dim'),S('  |  '+status,'green' if live else 'yellow')),section('GPU · ТЕКУЩИЕ ПОКАЗАТЕЛИ',width)]
    widths=[3,15,13,9,7,6,6,6,7,7,7,6,4]
    lines += [border(widths,'┌','┬','┐'),row(['GPU','Модель','Хешрейт','Мощность','TH/Вт','Вент','Темп','Смещ.','Ядро','Память','Принято','Откл.','Сбои'],widths,['cyan']*13,range(13),center=True),border(widths)]
    for d in data['devices']:
        card=cards.get(str(d),{});per=shares.get(str(d)) if shares else None;speed=rates.get(d);power=data['mean_power'].get(d);eff=speed/power if speed is not None and power else None
        name=card.get('name','UNKNOWN').removeprefix('NVIDIA ').removeprefix('GeForce ')
        lines.append(row(['#'+str(d),name,number(speed)+' TH/s',number(card.get('power'),1)+' W',number(eff,3),number(card.get('fan'),0)+'%',number(card.get('temp'),0)+' C',core_offset_cell(card),number(card.get('core'),0),number(card.get('memory'),0),per['accepted'] if per else '—',per['rejected'] if per else '—',gpu_fault_cell(data,d)],widths,['cyan','text','text','text','text','text','text','text','text','text','green','red','dim'],(10,11)))
    watts=total({d:cards.get(str(d),{}).get('power') for d in data['devices']});speed=total(rates);mean=total(data['mean_power']);eff=speed/mean if speed is not None and mean else None
    a=counts.get('accepted') if counts else None;r=counts.get('rejected') if counts else None
    lines += [border(widths),row(['','ИТОГО',number(speed)+' TH/s',number(watts,1)+' W',number(eff,3),'','','','','',count(a),count(r),total_fault_cell(data)],widths,['yellow']*13,(1,2,3,4,10,11)),border(widths,'└','┴','┘')]
    lines += host_gauge_lines(data,width)
    lines += [section('СТАТИСТИКА ПО ПЕРИОДАМ',width)]
    lines += average_rows(data['averages'],data.get('metrics'),data.get('session_metrics'))
    idle=data.get('short_metrics',{}).get('idle_per_gpu')
    lines += [section('СЕАНС · ПУЛ · СОБЫТИЯ',width)]
    n=a+r if a is not None and r is not None else 0
    lines += [L(S('Шары  ','cyan'),S(count(a)+' принято','green',True),S(' / '),S(count(r)+' отклонено','red',True),S('  |  Отклонено '+number(100*r/n if n else None)+'%','red'),S('  |  Ожидают '+count(s.get('inflight_observed')),'dim')),
              L(S('Invalid '+count(counts.get('invalid') if counts else None)+'   Stale '+count(counts.get('stale') if counts else None)+'   Duplicate '+count(counts.get('duplicate') if counts else None)+'   |   Сбои: GPU/драйвер; не диагноз железа','dim')),rule(width)]
    observed=data.get('link_metrics',{})
    lines += [L(S('Время работы  ','cyan'),S(duration(now-data['started']))),
              L(S('Пул           ','cyan'),S(label(detail.get('pool','нет данных'))),S('   '+label(s.get('connection_status','UNKNOWN')),'green' if live and s.get('connection_status')=='ESTABLISHED' else 'yellow')),
              L(S('Связь         ','cyan'),S('Повторных соединений '+count(observed_reconnect_count(data))),S('   |   Без связи (набл.) '+number(observed.get('offline_seconds'),1)+' с','dim')),
              L(S('ACK           ','cyan'),S(number(detail.get('last_ACK_latency_ms'),0)+' мс'),S('   |   Среднее '+number(detail.get('mean_recent_ACK_latency_ms'),0)+' мс   |   Сеанс связи '+duration(observed.get('transport_connected_seconds',detail.get('authorized_session_seconds'))))),
              L(S('Задание       ','cyan'),S(label(s.get('job') or '—')),S('   |   Получено '+number(detail.get('job_age_seconds'),0)+' с назад','dim'))]
    rejects=data.get('recent_rejects') or []
    if rejects:
        lines.append(L(S('Последние отказы (новые сверху):','red',True)))
        for e in reversed(rejects[-3:]):
            when=wall+e['observed_at']-s['updated_monotonic']
            pool_text=reject_reasons.lookup(e.get('id')) if type(e.get('id')) is int else None
            reason=label(pool_text or e.get('error') or e['category'],70)
            lines.append(L(S(clock(when)+'  ','dim'),S('GPU '+count(e.get('device'))+'   '+label(e['category']).upper(),'red',True),S('   #'+str(e.get('id'))+'   '+reason),S('   · '+elapsed_age(now-e['observed_at'])+' назад','dim')))
    else:lines.append(L(S('Отказов за сеанс нет','dim')))
    lines.append(rule(width))
    for e in reversed(detail.get('recent_events',[])[-3:]):
        when=wall+e['observed_at']-s['updated_monotonic']
        lines.append(L(S(clock(when)+'  ','dim'),S('GPU '+count(e.get('device'))+'   '+('ШАРА ПРИНЯТА' if e['category']=='accepted' else label(e['category']).upper()),'green' if e['category']=='accepted' else 'red',True),S('   #'+str(e['id'])+'   '+number(e.get('latency_ms'),0)+' мс')))
    return lines
