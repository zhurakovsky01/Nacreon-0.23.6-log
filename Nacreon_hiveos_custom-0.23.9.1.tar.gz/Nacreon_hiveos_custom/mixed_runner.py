"""Own USER-only mixed-family launcher. No CUDA work; original native workers do it."""
import collections,copy,ctypes,json,math,os,pathlib,re,signal,stat,subprocess,sys,tempfile,time
import select as select_io
try:import fcntl
except ImportError:fcntl=None  # Pure argument/merge fixtures also run on Windows.

VERSION='0.23.9'
ARCHES={(7,5):'sm75',(8,6):'sm86',(8,9):'sm89',(12,0):'sm120'}
ALIASES={'-a':'--algorithm','--algo':'--algorithm','--algorithm-gpu':'--algorithm','-o':'--pool','--url':'--pool','-w':'--wallet','--user':'--wallet','-r':'--worker','-p':'--password','--pass':'--password','-d':'--devices','--cclock-offset':'--coff','--cclock':'--cclk','--mclock':'--mclk','--mclock-offset':'--moff','--power-limit':'--pl'}
TUNING={'--coff','--cclk','--moff','--mclk','--pl','--fan'}
OPTIONS=TUNING|{'--algorithm','--pool','--wallet','--worker','--password','--devices'}
MAGIC=b'NACREON_ARGS_V1\0'
class MixedError(ValueError):pass
def need(ok,message='Invalid mixed GPU contract'):
    if not ok:raise MixedError(message)
def encode(args):
    b=MAGIC+b''.join(x.encode()+b'\0' for x in args)
    need(len(b)<=65536 and len(args)<=256,'Configuration exceeds bounds');return b
def arguments(args,stdin=None):
    if len(args)==2 and args[0]=='--config':
        if args[1]=='-':b=(stdin or sys.stdin.buffer).read(65537)
        else:
            with open(args[1],'rb') as f:b=f.read(65537)
        need(len(b)<=65536 and b.startswith(MAGIC) and b.endswith(b'\0'),'Invalid generated configuration')
        try:args=[x.decode('utf-8') for x in b[len(MAGIC):-1].split(b'\0')]
        except UnicodeError:raise MixedError('Invalid configuration encoding') from None
    need(len(args)<=256,'Too many configuration options');result=[];values={};i=0
    while i<len(args):
        option=args[i];i+=1
        if '=' in option:option,value=option.split('=',1)
        else:
            need(i<len(args),'Missing option value');value=args[i];i+=1
        option=ALIASES.get(option,option);need(option in OPTIONS,'Unsupported configuration option')
        need(value and len(value.encode())<=(1024 if option=='--password' else 512),'Invalid option length')
        need(all(ord(c)>=32 and ord(c)!=127 and (option=='--password' or not c.isspace()) for c in value),'Invalid option characters')
        if option!='--pool':need(option not in values or values[option]==value,'Conflicting duplicate option')
        if option=='--pool' or option not in values:result.extend((option,value))
        values[option]=value
    need('--pool' in values and '--wallet' in values,'Pool and user account required')
    encode(result);return result,values
def select(inventory,values,override=None):
    need(not override or override in ARCHES.values(),'Invalid architecture override')
    by_id={str(d['index']):d for d in inventory};by_uuid={d['uuid']:d for d in inventory}
    need(len(by_id)==len(by_uuid)==len(inventory),'Ambiguous GPU inventory')
    value=values.get('--devices','auto')
    if value=='auto':selected=[d for d in inventory if d['arch'] and (not override or d['arch']==override)]
    else:
        selected=[]
        for token in value.split(','):
            need(bool(re.fullmatch(r'[0-9]+|GPU-[0-9a-fA-F-]+',token)),'Invalid selected GPU')
            d=by_uuid.get(token) if token.startswith('GPU-') else by_id.get(str(int(token)))
            need(d is not None and d['arch'] and (not override or d['arch']==override),'Selected GPU unavailable or unsupported')
            selected.append(d)
    need(1<=len(selected)<=32 and len({d['uuid'] for d in selected})==len(selected),'Select unique supported GPUs')
    groups=collections.OrderedDict()
    for position,d in enumerate(selected):groups.setdefault(d['arch'],[]).append((position,d))
    return selected,groups
def partition(args,values,selected,groups):
    tuning={}
    for option in TUNING&values.keys():
        items=values[option].split(',');need(len(items) in (1,len(selected)),'GPU parameter count must match selected devices')
        for item in items:
            if item=='*' or (option=='--fan' and item=='auto'):continue
            need(re.fullmatch(r'-?[0-9]+',item) is not None,'Invalid GPU parameter')
            n=int(item);need(-(1<<31)<=n<(1<<31),'GPU parameter out of range')
            if option in ('--pl','--cclk','--mclk'):need(n>0,'Positive watts/MHz required')
            if option=='--fan':need(0<=n<=100,'Fan must be 0..100 or auto')
        tuning[option]=items
    out={}
    for arch,devices in groups.items():
        child=[]
        for i in range(0,len(args),2):
            key,value=args[i:i+2]
            if key=='--devices':continue
            if key in tuning:
                items=tuning[key];value=items[0] if len(items)==1 else ','.join(items[pos] for pos,_ in devices)
            child.extend((key,value))
        child.extend(('--devices',','.join(str(d['index']) for _,d in devices)));out[arch]=encode(child)
    return out
def inventory():
    try:lib=ctypes.CDLL('libcuda.so.1')
    except OSError:raise MixedError('NVIDIA CUDA driver library is unavailable') from None
    class UUID(ctypes.Structure):_fields_=[('bytes',ctypes.c_ubyte*16)]
    funcs={'cuInit':[ctypes.c_uint],'cuDeviceGetCount':[ctypes.POINTER(ctypes.c_int)],'cuDeviceGet':[ctypes.POINTER(ctypes.c_int),ctypes.c_int],'cuDeviceComputeCapability':[ctypes.POINTER(ctypes.c_int),ctypes.POINTER(ctypes.c_int),ctypes.c_int],'cuDeviceGetUuid':[ctypes.POINTER(UUID),ctypes.c_int]}
    for name,types in funcs.items():
        fn=getattr(lib,name);fn.argtypes=types;fn.restype=ctypes.c_int
    def check(rc):need(rc==0,'NVIDIA inventory query failed')
    check(lib.cuInit(0));count=ctypes.c_int();check(lib.cuDeviceGetCount(ctypes.byref(count)));need(0<=count.value<=32,'Invalid GPU count');out=[]
    for index in range(count.value):
        device=ctypes.c_int();a=ctypes.c_int();b=ctypes.c_int();u=UUID();check(lib.cuDeviceGet(ctypes.byref(device),index));check(lib.cuDeviceComputeCapability(ctypes.byref(a),ctypes.byref(b),device));check(lib.cuDeviceGetUuid(ctypes.byref(u),device))
        h=bytes(u.bytes).hex();uuid='GPU-'+h[:8]+'-'+h[8:12]+'-'+h[12:16]+'-'+h[16:20]+'-'+h[20:]
        out.append(dict(index=index,uuid=uuid,arch=ARCHES.get((a.value,b.value))))
    return out
def tmpfs(path):
    libc=ctypes.CDLL(None,use_errno=True);buf=(ctypes.c_long*64)();fn=libc.statfs;fn.argtypes=[ctypes.c_char_p,ctypes.c_void_p];fn.restype=ctypes.c_int
    return fn(os.fsencode(path),ctypes.byref(buf))==0 and buf[0]==0x01021994
def process_identity(pid):
    p=pathlib.Path('/proc')/str(pid);text=(p/'stat').read_text();return int(text.rsplit(')',1)[1].split()[19])
def unique(pairs):
    d={}
    for k,v in pairs:need(k not in d,'Duplicate snapshot member');d[k]=v
    return d
def read_child(path,pid,ticks,boot,devices,now):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    with os.fdopen(fd,'rb') as f:
        info=os.fstat(f.fileno());need(stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.geteuid() and info.st_mode&0o077==0 and info.st_size<=1024*1024,'Unowned child snapshot');data=f.read(1024*1024+1)
    need(len(data)<=1024*1024,'Child snapshot too large')
    s=json.loads(data,object_pairs_hook=unique,parse_constant=lambda _:need(False))
    from snapshot_contract import validate_snapshot
    s=validate_snapshot(s,now);need(s['pid']==pid and s['start_ticks']==ticks and s['boot_id']==boot and process_identity(pid)==ticks,'Child process identity changed')
    from public_console import telemetry,shares
    telemetry(s['shares']['user']['telemetry'],s['monotonic_seconds'],shares(s['shares']['user']['total']),[d['index'] for d in s['devices']])
    need(s['version']==VERSION and s['running'],'Child is not running this version')
    need({(d['index'],d['uuid']) for d in s['devices']}=={(d['index'],d['uuid']) for d in devices},'Child device ownership mismatch')
    return s
class SnapshotFile:
    def __init__(self,path):
        self.path=pathlib.Path(path);self.directory=None;self.lock=None
        need(self.path.is_absolute() and re.fullmatch(r'[A-Za-z0-9._-]+',self.path.name) and self.path.name not in ('.','..'),'Invalid statistics path')
        self.directory=os.open(self.path.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
        info=os.fstat(self.directory);need(info.st_uid==os.geteuid() and info.st_mode&0o022==0 and tmpfs(self.path.parent),'Statistics requires owned tmpfs directory')
        self.lock=os.open(self.path.name+'.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.directory)
        info=os.fstat(self.lock);need(stat.S_ISREG(info.st_mode) and info.st_uid==os.geteuid() and info.st_mode&0o077==0 and info.st_nlink==1,'Invalid statistics lock')
        fcntl.flock(self.lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    def publish(self,s):
        name='.'+self.path.name+'.'+os.urandom(12).hex();fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.directory)
        try:
            with os.fdopen(fd,'w') as f:json.dump(s,f,separators=(',',':'),allow_nan=False)
            os.rename(name,self.path.name,src_dir_fd=self.directory,dst_dir_fd=self.directory)
        finally:
            try:os.unlink(name,dir_fd=self.directory)
            except FileNotFoundError:pass
    def close(self):
        if self.lock is not None:os.close(self.lock);self.lock=None
        if self.directory is not None:os.close(self.directory);self.directory=None
class Merger:
    def __init__(self,pid,ticks,boot,started,order):
        self.identity=dict(pid=pid,start_ticks=ticks,boot_id=boot);self.started=started;self.order=order;self.cache={};self.seen={};self.events=collections.deque(maxlen=32);self.serial=0;self.history=collections.deque(maxlen=128)
    def update(self,arch,s):
        old=self.cache.get(arch)
        if old:
            need(s['monotonic_seconds']>=old['monotonic_seconds'],'Child time moved backwards')
            before={d['index']:d for d in old['devices']}
            for d in s['devices']:
                for key in ('raw_macs','current_macs'):need(int(d[key][0])>=int(before[d['index']][key][0]),'Child work counter reset')
            for k in ('accepted','rejected','unknown'):need(s['shares']['user']['total'][k]>=old['shares']['user']['total'][k],'Child share counter reset')
            need(s['shares']['user']['telemetry']['last_serial']>=old['shares']['user']['telemetry']['last_serial'],'Child event counter reset')
        self.cache[arch]=s
    def render(self,now,fresh,running=True):
        need(self.cache and now>=self.started,'Missing child statistics');out=copy.deepcopy(next(iter(self.cache.values())));out.update(self.identity);out.update(version=VERSION,monotonic_seconds=now,uptime=int(now-self.started),running=running,user_ready=running and all(fresh.values()) and all(s['user_ready'] for s in self.cache.values()))
        devices={};total={k:0 for k in ('accepted','rejected','unknown','pending')};per={};rejected={k:0 for k in ('invalid','stale','duplicate','other')};connections=[];new=[];skipped=0
        for arch,s in self.cache.items():
            user=s['shares']['user'];t=user['telemetry'];connections.append((fresh[arch],t['connection']))
            for k in total:total[k]+=user['total'][k]
            per.update(copy.deepcopy(user['devices']))
            for k in rejected:rejected[k]+=t['rejected'][k]
            previous=self.seen.get(arch,0)
            incoming=[e for e in t['events'] if e['serial']>previous]
            skipped+=max(0,t['last_serial']-previous-len(incoming))
            for e in t['events']:
                if e['serial']>previous:new.append((e['observed_at'],arch,e))
            self.seen[arch]=t['last_serial']
            for source in s['devices']:
                d=copy.deepcopy(source);b=d['batch'];done=b.get('completed_at')
                if done is not None:b['age_seconds']=max(0.,now-done)
                if not running or not fresh[arch] or (b.get('max_age_seconds') is not None and b.get('age_seconds') is not None and b['age_seconds']>b['max_age_seconds']):d['hs']=None;b['valid']=False;b['scope']='stopped' if not running else 'expired'
                devices[d['index']]=d
        self.serial+=skipped
        for _,arch,e in sorted(new,key=lambda x:(x[0],x[1],x[2]['serial'])):
            self.serial+=1;need(self.serial<2**64,'Merged event serial exhausted');event=copy.deepcopy(e);event['serial']=self.serial;self.events.append(event)
        need(set(devices)==set(self.order),'Missing selected devices');out['devices']=[devices[i] for i in self.order]
        # Windowed confirmed cumulative counters retain stale-child totals; unknown speed is never zero-filled.
        current={i:(int(d['raw_macs'][0]),int(d['current_macs'][0])) for i,d in devices.items()}
        if not self.history:self.history.append((self.started,{i:(0,0) for i in self.order}))
        self.history.append((now,current))
        while len(self.history)>2 and self.history[1][0]<=now-30:self.history.popleft()
        at,prior=self.history[0];elapsed=now-at;out['full_wall_rate_window_seconds']=elapsed
        for d in out['devices']:
            raw,cur=current[d['index']];a,b=prior[d['index']]
            d['full_wall_hs']=(raw-a)/elapsed if elapsed>0 and d['valid'] else None;d['completed_current_hs']=(cur-b)/elapsed if elapsed>0 and d['valid'] else None
        connected=running and all(f and c['connected'] for f,c in connections)
        connected_at=max(c['connected_at'] for _,c in connections) if connected else None
        losses=[c['lost_at'] for f,c in connections if f and not c['connected'] and c['lost_at'] is not None]
        lost_at=min(losses) if losses and all(f for f,c in connections) else None
        conn=dict(connected=connected,connections=sum(c['connections'] for f,c in connections),reconnections=sum(c['reconnections'] for f,c in connections),connected_at=connected_at,connection_age_seconds=now-connected_at if connected else None,lost_at=lost_at,current_offline_seconds=now-lost_at if lost_at is not None else None,last_offline_seconds=None,observed_offline_seconds=None)
        jobs=[s['shares']['user']['telemetry']['job'] for s in self.cache.values()];same=connected and len({j['id'] for j in jobs})==1 and all(j['received_at'] is not None for j in jobs)
        received=max(j['received_at'] for j in jobs) if same else None
        timed=[e['latency_ms'] for e in self.events if e['latency_ms'] is not None]
        telemetry=dict(schema='NACREON_POOL_TELEMETRY_V1',clock='monotonic_seconds',coverage='session_ledger_process_lifetime',ack_timing='local_submit_call_to_reply_parse',connection=conn,job=dict(id=jobs[0]['id'] if same else None,received_at=received,age_seconds=now-received if received is not None else None),rejected=rejected,last_serial=self.serial,events=list(self.events),last_ack_latency_ms=self.events[-1]['latency_ms'] if self.events else None,mean_recent_ack_latency_ms=sum(timed)/len(timed) if timed else None)
        out['shares']={'user':dict(total=total,devices=per,telemetry=telemetry)}
        from snapshot_contract import validate_snapshot
        validate_snapshot(out,now);return out
def child_setup(parent):
    libc=ctypes.CDLL(None);need(libc.prctl(1,signal.SIGKILL,0,0,0)==0,'Cannot bind worker lifetime');need(os.getppid()==parent,'Parent already stopped')
def send_config(child,payload,stopped):
    fd=child.stdin.fileno();os.set_blocking(fd,False);end=time.monotonic()+10;offset=0
    try:
        while offset<len(payload):
            need(not stopped[0] and child.poll() is None and time.monotonic()<end,'Worker configuration handoff failed')
            if select_io.select([],[fd],[],.1)[1]:
                try:offset+=os.write(fd,payload[offset:])
                except BlockingIOError:pass
    finally:child.stdin.close()
def stop_children(children):
    for child in children:
        try:os.killpg(child.pid,signal.SIGTERM)
        except ProcessLookupError:pass
    end=time.monotonic()+5
    while any(c.poll() is None for c in children) and time.monotonic()<end:time.sleep(.05)
    for child in children:
        try:os.killpg(child.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        child.wait(timeout=5)
def run(root,args,details,override=None,journal=None):
    sys.path.insert(0,str(root/'console'))
    parsed,values=arguments(args);selected,groups=select(details,values,override);payloads=partition(parsed,values,selected,groups)
    if len(groups)==1:
        arch=next(iter(groups));path=root/'bin'/('nacreon-'+arch);need(path.is_file() and not path.is_symlink(),'Selected native is missing')
        if journal is not None:
            from reject_runtime import attach_single
            attach_single(root,path,*journal)
        fd=os.memfd_create('nacreon-config',os.MFD_CLOEXEC);os.write(fd,payloads[arch]);os.lseek(fd,0,0);os.dup2(fd,0);os.close(fd);os.execv(str(path),[str(path),'--config','-'])
    for arch in groups:need((root/'bin'/('nacreon-'+arch)).is_file() and not (root/'bin'/('nacreon-'+arch)).is_symlink(),'Selected native is missing')
    ram=next((p for p in ('/run','/dev/shm') if os.access(p,os.W_OK) and tmpfs(p)),None);need(ram,'Writable tmpfs required')
    runtime=pathlib.Path(tempfile.mkdtemp(prefix='nacreon-mixed-',dir=ram));os.chmod(runtime,0o700)
    writer=None;children=[];workers={};merger=None;stopped=[False];old={};code=0;started=time.monotonic();pid=os.getpid();boot=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    try:
        writer=SnapshotFile(os.environ.get('NACREON_STATS_FILE',str(runtime/'stats.json')))
        for sig in (signal.SIGTERM,signal.SIGINT):old[sig]=signal.signal(sig,lambda *_:stopped.__setitem__(0,True))
        for arch,devices in groups.items():
            env=os.environ.copy();env['NACREON_STATS_FILE']=str(runtime/(arch+'.json'))
            reader=None
            if journal is not None:
                try:
                    from reject_runtime import mixed_reader
                    reader=mixed_reader(root,root/'bin'/('nacreon-'+arch),env['NACREON_STATS_FILE'],*journal,slot=len(children)+1)
                except Exception:pass
            child=subprocess.Popen([sys.executable,'-I','-B',str(root/'reject_child.py'),str(pid),str(root/'bin'/('nacreon-'+arch))],stdin=subprocess.PIPE,stdout=subprocess.PIPE if reader is not None else None,env=env,start_new_session=True,restore_signals=reader is None);children.append(child)
            if reader is not None:reader(child)
            ticks=process_identity(child.pid);send_config(child,payloads[arch],stopped);workers[arch]=(child,ticks,[d for _,d in devices])
        merger=Merger(pid,process_identity(pid),boot,started,[d['index'] for d in selected])
        while not stopped[0]:
            failed=next((c for c in children if c.poll() is not None),None)
            if failed is not None:code=failed.returncode if failed.returncode and failed.returncode>0 else 1;break
            now=time.monotonic();fresh={}
            for arch,(child,ticks,devices) in workers.items():
                try:s=read_child(runtime/(arch+'.json'),child.pid,ticks,boot,devices,now)
                except (OSError,ValueError,KeyError,TypeError):fresh[arch]=False
                else:merger.update(arch,s);fresh[arch]=True
            if len(merger.cache)==len(workers):writer.publish(merger.render(now,fresh))
            elif now-started>180:raise MixedError('Mixed native startup statistics unavailable')
            time.sleep(.25)
        if merger and len(merger.cache)==len(workers):writer.publish(merger.render(time.monotonic(),{a:False for a in workers},running=False))
        return code
    finally:
        stop_children(children)
        for sig,handler in old.items():signal.signal(sig,handler)
        if writer:writer.close()
        # Only exact owned worker snapshot/lock names; native diagnostic runtimes are untouched.
        for arch in groups:
            for suffix in ('.json','.json.lock'):
                try:(runtime/(arch+suffix)).unlink()
                except FileNotFoundError:pass
        try:runtime.rmdir()
        except OSError:pass
