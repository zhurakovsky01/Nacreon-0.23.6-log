"""Public branding; version always comes from the running build snapshot."""
NAME = 'Nacreon Miner'
DEVELOPER = 'liked'
EDITOR = 'alex_kodiaq'
EDITION = '0.23.9.1'
REPOSITORY = 'https://github.com/liked-lab/Nacreon-Miner'

def label(value, limit=96):
    return ''.join(c for c in str(value) if c.isprintable() and c != '\x1b')[:limit]

def title(snapshot):
    return NAME + ' | ' + label(snapshot.get('version') or 'версия неизвестна', 64)

def startup(snapshot):
    return [title(snapshot), 'Автор: '+DEVELOPER+' · редакция '+EDITOR+' · '+EDITION,
            'GitHub: '+REPOSITORY,
            'Build ELF: '+label(snapshot.get('native_sha256') or 'нет данных', 64)]
