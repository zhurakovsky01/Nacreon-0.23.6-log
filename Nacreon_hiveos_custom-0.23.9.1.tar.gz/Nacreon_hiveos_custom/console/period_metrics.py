"""Viewer-only rolling metrics. Gaps/late starts never create historical zeros.

Power and link outage are estimates from snapshot samples, not PSU readings or
continuous packet tracing. Device idle requires explicit device timing counters;
neither low power nor a quiet share stream proves an idle GPU.
"""
import bisect
import math
from collections import deque
from history24 import WINDOWS
from idle_metrics import IdleMetrics

NEGATIVE = {'invalid', 'stale', 'duplicate', 'other_rejected'}

def finite(value):
    return type(value) in (int, float) and math.isfinite(value)

class PeriodMetrics:
    def __init__(self, devices):
        self.devices = tuple(devices)
        self.samples = deque()
        self.events = {}
        self.share_since = None
        self.last_counts = None
        self.last_rejected = None
        self.idle_metrics = IdleMetrics(self.devices)
        # Indexed integrals of completed sample segments. Unknown/gap segments
        # have separate counters, so subtraction cannot bridge missing data.
        self._times = []
        self._rows = []
        self._prefix = []
        self._head = 0

    def _append_sample(self, sample):
        stamp, powers, link, _, connection = sample
        good = all(finite(powers[d]) and powers[d] >= 0 for d in self.devices)
        row = (stamp, sum(powers[d] for d in self.devices) if good else 0., good, link, connection)
        energy = offline = bad_power = bad_link = 0
        if self._rows:
            earlier = self._rows[-1]
            dt = stamp-earlier[0]
            bad_power = int(dt > 10 or not (earlier[2] and good))
            bad_link = int(dt > 10 or earlier[3] is None or link is None)
            if not bad_power: energy = (earlier[1]+row[1])/2*dt
            if not bad_link: offline = earlier[3]*dt
        prior = self._prefix[-1] if self._prefix else (0., 0., 0, 0)
        self._times.append(stamp)
        self._rows.append(row)
        self._prefix.append(tuple(a+b for a,b in zip(prior, (energy, offline, bad_power, bad_link))))
        self.samples.append(sample)

    def _prune(self, cutoff):
        while len(self.samples) > 2 and self.samples[1][0] <= cutoff:
            self.samples.popleft()
            self._head += 1
        if self._head >= 4096:
            head = self._head
            base = self._prefix[head]
            del self._times[:head]
            del self._rows[:head]
            self._prefix = [tuple(a-b for a,b in zip(row,base)) for row in self._prefix[head:]]
            self._head = 0

    def _partial(self, end, lo, hi):
        """Integral inside one admitted segment; used only for boundary clips."""
        earlier, later = self._rows[end-1], self._rows[end]
        dt = later[0]-earlier[0]
        if hi <= lo or dt > 10: return 0., 0.
        energy = offline = 0.
        if earlier[2] and later[2]:
            p = earlier[1]+(later[1]-earlier[1])*(lo-earlier[0])/dt
            q = earlier[1]+(later[1]-earlier[1])*(hi-earlier[0])/dt
            energy = (p+q)/2*(hi-lo)
        if earlier[3] is not None and later[3] is not None:
            offline = earlier[3]*(hi-lo)
        return energy, offline

    def observe(self, snapshot):
        stamp = snapshot['updated_monotonic']
        if self.samples and stamp <= self.samples[-1][0]:
            return
        detail = snapshot.get('detail', {})
        self.idle_metrics.observe(detail, stamp)
        counts = snapshot.get('counts') if snapshot.get('counts_complete') else None
        pair = (counts['accepted'], counts['rejected']) if counts else None
        fresh = []
        for event in detail.get('recent_events', []):
            key = (event['connection'], event['id'])
            if key in self.events or not finite(event.get('observed_at')):
                continue
            if event['observed_at'] > stamp:
                continue
            fresh.append(event)
            self.events[key] = dict(event)
            if event['category'] in NEGATIVE and (self.last_rejected is None or event['observed_at'] > self.last_rejected['observed_at']):
                self.last_rejected = dict(event)
        previous = self.samples[-1][0] if self.samples else None
        new_a = sum(e['category'] == 'accepted' and e['observed_at'] > (previous if previous is not None else -math.inf) for e in fresh)
        new_r = sum(e['category'] in NEGATIVE and e['observed_at'] > (previous if previous is not None else -math.inf) for e in fresh)
        if pair is None:
            self.share_since = None
        elif previous is None or self.last_counts is None:
            self.share_since = stamp
        elif stamp-previous > 10 or pair != (self.last_counts[0]+new_a, self.last_counts[1]+new_r):
            # More replies than retained events, a capture failure, or reset.
            self.share_since = stamp
        self.last_counts = pair
        power = {d: snapshot.get('cards', {}).get(str(d), {}).get('power') for d in self.devices}
        # Idle uses its own closed native timestamps/coverage (IdleMetrics).
        # Preserve the existing sample tuple shape used by power-only views.
        idle = dict.fromkeys(self.devices)
        link = snapshot.get('connection_status')
        connection_count = snapshot.get('connection_count')
        link_valid = snapshot.get('counts_complete') is True and not snapshot.get('errors') and type(connection_count) is int and connection_count >= 1
        link_valid = link_valid and (not self.samples or type(self.samples[-1][4]) is not int or connection_count >= self.samples[-1][4])
        link = (0 if link == 'ESTABLISHED' else 1 if link == 'DISCONNECTED' else None) if link_valid else None
        self._append_sample((stamp, power, link, idle, connection_count if link_valid else None))
        cutoff = stamp-86400
        self._prune(cutoff)
        self.events = {k:e for k,e in self.events.items() if e['observed_at'] >= cutoff}

    def window(self, now, seconds):
        result = dict(accepted=None, rejected=None, rejected_percent=None,
                      mean_power=None, idle_seconds=None, idle_percent=None,
                      idle_per_gpu=None, offline_seconds=None, reconnects=None)
        result.update(self.idle_metrics.window(now, seconds))
        start = now-seconds
        if self.share_since is not None and self.share_since <= start and self.samples and now-self.samples[-1][0] <= 10:
            events = [e for e in self.events.values() if start < e['observed_at'] <= now]
            result['accepted'] = sum(e['category'] == 'accepted' for e in events)
            result['rejected'] = sum(e['category'] in NEGATIVE for e in events)
            n = result['accepted']+result['rejected']
            result['rejected_percent'] = 100*result['rejected']/n if n else None
        if not self.samples or self.samples[0][0] > start or self.samples[-1][0] < now:
            return result
        first = max(self._head, bisect.bisect_right(self._times, start, lo=self._head)-1)
        last = bisect.bisect_left(self._times, now, lo=self._head)
        a, b = self._prefix[first], self._prefix[last]
        power_energy, offline = b[0]-a[0], b[1]-a[1]
        power_ok, link_ok = b[2] == a[2], b[3] == a[3]
        for end, lo, hi in ((first+1, self._times[first], start), (last, now, self._times[last])):
            if hi > lo:
                energy, lost = self._partial(end, lo, hi)
                power_energy -= energy
                offline -= lost
        result['mean_power'] = power_energy/seconds if power_ok else None
        result['offline_seconds'] = offline if link_ok else None
        begin, end = self._rows[first][4], self._rows[-1][4]
        # Connection creation count is exact only at sampled boundaries.
        if self._times[first] == start and self._times[-1] == now and type(begin) is int and type(end) is int and end >= begin:
            result['reconnects'] = end-begin
        return result

    def windows(self, now):
        return {seconds:self.window(now, seconds) for seconds in WINDOWS}
