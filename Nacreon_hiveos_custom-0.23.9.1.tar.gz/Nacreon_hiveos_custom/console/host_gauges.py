"""Lightweight read-only host metrics; no volumes enumeration or GPU queries."""
import math
import os
from pathlib import Path
import re
import time

SCHEMA='NACREON_HOST_GAUGES_V1'
PALETTE={'gauge_base':'38;2;69;168;117','gauge_amber':'38;2;192;147;68','gauge_red':'38;2;189;91;91'}
LOCAL_FS={'ext2','ext3','ext4','xfs','btrfs','f2fs','zfs','reiserfs','ntfs3','vfat'}

def boot_normalized(value):
    value=str(value).strip().replace('-','').lower()
    if not re.fullmatch('[a-f0-9]{32}',value):raise ValueError('boot_id')
    return value

def read_bounded(path,limit):
    with open(path,'r',encoding='utf-8') as stream:
        value=stream.readline(limit+1) if path=='/proc/stat' else stream.read(limit+1)
    if len(value)>limit:raise ValueError('source_limit')
    return value

def cpu_values(text):
    row=text.splitlines()[0].split()
    if len(row)<9 or row[0]!='cpu':raise ValueError('cpu_format')
    result=tuple(int(v) for v in row[1:9])  # guest/guest_nice already included; do not double count.
    if any(v<0 for v in result):raise ValueError('cpu_counter')
    return result

def cpu_percent(previous,current):
    if previous is None or any(b<a for a,b in zip(previous,current)):return None
    delta=[b-a for a,b in zip(previous,current)];total=sum(delta)
    if total<=0:return None
    return 100*(total-delta[3]-delta[4])/total  # idle + iowait excluded from busy.

def memory_values(text):
    values={}
    for line in text.splitlines():
        key,_,tail=line.partition(':')
        if key in ('MemTotal','MemAvailable'):
            fields=tail.split()
            if len(fields)!=2 or fields[1]!='kB' or key in values:raise ValueError('mem_format')
            values[key]=int(fields[0])*1024
    total,available=values['MemTotal'],values['MemAvailable']
    if not 0<=available<=total or total<=0:raise ValueError('mem_range')
    return dict(total_bytes=total,available_bytes=available,used_effective_bytes=total-available,
                percent=100*(total-available)/total)

def root_filesystem(mountinfo):
    roots=[]
    for line in mountinfo.splitlines():
        before,separator,after=line.partition(' - ')
        if not separator:raise ValueError('mount_format')
        fields=before.split();tail=after.split()
        if len(fields)<6 or len(tail)<3:raise ValueError('mount_format')
        if fields[4]=='/':roots.append(tail[0])
    if len(roots)!=1 or roots[0] not in LOCAL_FS:raise ValueError('root_fs_not_proven_local')
    return roots[0]

def disk_values(vfs):
    size=vfs.f_frsize;blocks=vfs.f_blocks;available=vfs.f_bavail
    if not all(type(v) is int for v in (size,blocks,available)) or size<=0 or blocks<=0 or not 0<=available<=blocks:
        raise ValueError('disk_range')
    total=blocks*size;free=available*size
    return dict(total_bytes=total,available_bytes=free,used_effective_bytes=total-free,percent=100*(total-free)/total)

class HostSampler:
    def __init__(self,run_id,boot_id,reader=read_bounded,statvfs=None,clock=None):
        self.scope=dict(run_id=run_id,boot_id=boot_normalized(boot_id))
        self.reader=reader;self.statvfs=statvfs or os.statvfs;self.clock=clock or time.monotonic
        self.previous=None;self.previous_at=None;self.latest=None

    def sample(self):
        at=self.clock();cpu=memory=disk=None;errors={}
        try:boot=boot_normalized(self.reader('/proc/sys/kernel/random/boot_id',128))
        except (OSError,ValueError):boot=None
        if boot!=self.scope['boot_id']:
            self.previous=None;self.previous_at=None
            self.latest=dict(schema=SCHEMA,**self.scope,updated_monotonic=at,cpu=None,memory=None,disk=None,errors={'scope':'boot_mismatch'})
            return self.latest
        try:
            current=cpu_values(self.reader('/proc/stat',4096))
            interval=at-self.previous_at if self.previous_at is not None else None
            value=cpu_percent(self.previous,current) if interval is not None and 0<interval<=6 else None
            cpu=dict(percent=value,interval_seconds=interval);self.previous,self.previous_at=current,at
            if value is None:errors['cpu']='baseline_or_reset'
        except (OSError,ValueError,IndexError):
            self.previous=None;self.previous_at=None;errors['cpu']='unavailable'
        try:memory=memory_values(self.reader('/proc/meminfo',65536))
        except (OSError,ValueError,KeyError):errors['memory']='unavailable'
        try:
            fs=root_filesystem(self.reader('/proc/self/mountinfo',1024*1024))
            disk=dict(disk_values(self.statvfs('/')),fs_type=fs)  # Only after local root FS admission.
        except (OSError,ValueError,AttributeError):errors['disk']='unavailable_or_excluded_fs'
        end=self.clock()
        if end<at:cpu=memory=disk=None;errors={'clock':'regressed'};self.previous=None;self.previous_at=None
        self.latest=dict(schema=SCHEMA,**self.scope,updated_monotonic=end,cpu=cpu,memory=memory,disk=disk,errors=errors)
        return self.latest

    def snapshot(self,now=None):
        # Called by viewer publication: pure cached read, never proc/statvfs I/O.
        return dict(self.latest) if self.latest is not None else dict(schema=SCHEMA,**self.scope,updated_monotonic=None,cpu=None,memory=None,disk=None,errors={'source':'not_sampled'})

def span(text,color='text',bold=False):return (str(text),color,bold)

def bar(percent):
    if not valid_percent(percent):return [span('[','dim'),span('—'+' '*11,'dim'),span(']','dim')]
    filled=round(percent*12/100);out=[span('[','dim')]
    for index in range(12):
        end=(index+1)*100/12
        color='gauge_red' if percent>=90 and end>=90 else 'gauge_amber' if percent>=80 and end>=80 else 'gauge_base'
        # Background-painted ASCII spaces stay inside the terminal cell.
        # Full-block/shade font fallback can bleed into the adjacent text row.
        out.append(span(' ','gauge_fill_'+color.removeprefix('gauge_')) if index<filled else span(':','dim'))
    return out+[span(']','dim')]

def valid_percent(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and 0<=value<=100

def host_gauge_lines(data,width=124):
    value=data.get('host_metrics');scope=data.get('host_scope') or {}
    valid=isinstance(value,dict) and value.get('schema')==SCHEMA and value.get('run_id')==scope.get('run_id') and value.get('boot_id')==scope.get('boot_id')
    at=value.get('updated_monotonic') if valid else None;now=data.get('host_now',data.get('now'))
    valid=valid and isinstance(at,(int,float)) and isinstance(now,(int,float)) and 0<=now-at<=6
    metrics=[value.get(k) if valid else None for k in ('cpu','memory','disk')]
    metrics=[m if isinstance(m,dict) and valid_percent(m.get('percent')) else None for m in metrics]
    for index in (1,2):
        m=metrics[index]
        if m is not None and (any(type(m.get(k)) is not int for k in ('total_bytes','available_bytes','used_effective_bytes')) or not 0<=m['available_bytes']<=m['total_bytes'] or m['used_effective_bytes']!=m['total_bytes']-m['available_bytes']):metrics[index]=None
    cpu,ram,disk=metrics
    def gib(v):return f'{v/1073741824:.1f}'
    def percent_label(v):return str(int(v)) if v==int(v) else f'{math.floor(v*10)/10:.1f}'
    headers=['CPU: '+(percent_label(cpu['percent'])+'%' if cpu else '—'),
        'RAM: '+(gib(ram['used_effective_bytes'])+' / '+gib(ram['total_bytes'])+' ГиБ' if ram else '—'),
        'Системный диск: '+(gib(disk['used_effective_bytes'])+' / '+gib(disk['total_bytes'])+' ГиБ' if disk else '—')]
    subtitles=['Загрузка процессора','Доступно: '+(gib(ram['available_bytes'])+' ГиБ' if ram else '—'),
        'Доступно: '+(gib(disk['available_bytes'])+' ГиБ' if disk else '—')]
    width=max(1,int(width))
    groups=[[[span(header,'cyan')],bar(metric['percent'] if metric else None),[span(subtitle,'dim')]]
            for header,subtitle,metric in zip(headers,subtitles,metrics)]
    def centered(cell,columns):
        clipped=[];remaining=columns
        for text,color,bold in cell:
            part=text[:remaining]
            if part:clipped.append((part,color,bold));remaining-=len(part)
            if remaining==0:break
        left=remaining//2
        return [span(' '*left)]+clipped+[span(' '*(remaining-left))]
    # Keep the original three-row panel at ordinary console widths. Narrow
    # TTYs stack groups rather than letting RAM/disk wrap into another row.
    if width<114:
        return [centered(cell,width) for group in groups for cell in group]
    widths=[width//3,width//3,width-2*(width//3)]
    return [sum((centered(group[row],columns) for group,columns in zip(groups,widths)),[])
            for row in range(3)]

def observed_reconnect_count(data):
    s=data.get('snapshot',{});count=s.get('connection_count')
    return count-1 if type(count) is int and count>=1 and not data.get('stale') and s.get('counts_complete') is True and not s.get('errors') else None
