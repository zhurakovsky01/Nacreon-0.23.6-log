# Nacreon 0.23.9

## Русский

- Общая Linux/HiveOS сборка с отдельной host-обвязкой для RTX20/30/40/50. Используются соответствующие оригинальные CUDA-модули RGminer 1.1.4; их математика и ABI сохранены.
- В RTX20 сокращены повторные вычисления подготовки: одинаковая база используется совместно при точном совпадении header/config; target, nonce и epoch задания сохраняются отдельно. Подготовка полной B-матрицы сохранена. RTX30 выбирает доступную карту подготовки; в RTX30/40/50 добавлены блокирующие host-ожидания с сохранением обязательных CUDA-барьеров.
- Ограничена очередь диагностических ответов пула без изменения reader-side ACK/reject и авторизации.
- Исправлено освобождение собственных объектов очереди при ошибках добавления задания и создания потока. Семантика остановки при необработанной ошибке рабочего потока сохранена.
- Исправлены устаревание показаний CPU/RAM/системного диска при задержках GPU-опроса и гонка временных отметок. Расчёт истории периодов использует индекс. Внешний вид консоли сохранён.
- Собственная комиссия Nacreon в этой USER-only сборке отключена. Отсутствие комиссии сторонних модулей не заявляется.

Точные физические результаты и оставшиеся ограничения публикуются отдельно по SHA. CPU/source проверки не доказывают скорость GPU, паритет RTX2060, снижение нагрузки установленного майнера или отсутствие будущих rejects. Аппаратный тест с 12 GPU не выполнен. В RTX30/RTX40 поддержан ресурсный допуск 9–32 GPU вместо ограничения по числу карт: требуется достаточная доступная RAM, а 1–8 GPU сохраняют прежний запуск. Это не аппаратная квалификация 12 GPU; условия RAM указаны в README.

## English

- Common Linux/HiveOS package with architecture-specific host wrappers for RTX20/30/40/50. Corresponding original RGminer 1.1.4 CUDA modules retain their mathematics and ABI.
- RTX20 avoids duplicate base preparation for exactly matching header/config while retaining per-job target, nonce and epoch. Full B-matrix preparation is retained. RTX30 selects an available preparation device; RTX30/40/50 use blocking host waits while preserving required CUDA barriers.
- Bounded diagnostic pool-response buffering preserves reader-side ACK/reject and authorization.
- Queue-owned objects are released on enqueue and thread-creation failures. Existing fail-fast behavior on an uncaught worker exception is preserved.
- Fixed CPU/RAM/system-disk reading expiry during delayed GPU polling and a timestamp race. Period-history calculations use an index. Console appearance is preserved.
- The Nacreon fee is disabled in this USER-only build. No claim is made that third-party modules have no fee.

Exact physical results and remaining limits are reported separately by SHA. Source/CPU checks do not establish GPU speed, RTX2060 parity, installed miner CPU reduction or zero future rejects. A hardware test with 12 GPUs has not run. RTX30/RTX40 use resource admission for 9–32 GPUs with sufficient available RAM, preserving the existing 1–8 path. This is not physical 12-GPU qualification; see README for RAM policy.

[Запуск и настройки / Setup and tuning](README.md) · [Журнал отклонений / Rejected-share journal](REJECT_LOGGING.md)
