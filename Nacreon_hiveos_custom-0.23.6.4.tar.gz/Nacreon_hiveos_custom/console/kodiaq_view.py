"""Compact console view: header, one row per GPU, event feed (alex_kodiaq edit).

Original miner and console: Nacreon by liked. This view, the event feed,
the pool reject reasons and logging are alex_kodiaq's changes. All values come
from the existing console data; nothing here touches the miner or the GPUs.
"""
import collections, json, re, subprocess, threading, time

from branding import label, DEVELOPER, EDITOR, EDITION
from design import S, L, number, duration
from local_clock import clock, day
import reject_reasons

FEED_LIMIT = 400
_lock = threading.Lock()
_feed = collections.deque(maxlen=FEED_LIMIT)   # (wall, order, parts)
_order = [0]
_pending = {}                                    # submit id -> wall time sent
_last_share_wall = [None]


def _add(wall, parts):
    with _lock:
        _order[0] += 1
        _feed.append((wall, _order[0], parts))


def _stamp(wall):
    return S('[' + day(wall) + ' ' + clock(wall) + '] ', 'dim')


# ---------------------------------------------------------------- raw native lines

NOTIFY = b'[pool-raw] {'
SIMPLE = (
    (b'[net] connection lost', 'пул: связь потеряна', 'red'),
    (b'[pool] Connection lost', 'пул: связь потеряна', 'red'),
    (b'[net] TLS certificate/name verification or handshake failed', 'пул: ошибка TLS / подключения', 'red'),
    (b'[net] pool authorize', 'пул: подключение и авторизация', 'cyan'),
    (b'[net] user session connector stopped', 'пул: сессия остановлена', 'yellow'),
)
PATTERNS = (
    (re.compile(rb'\[plain\] stale share nonce=\d+ dropped'), 'шара устарела до отправки (сменилось задание)', 'yellow'),
    (re.compile(rb'\[plain\] verify failed'), 'ошибка: доказательство не прошло проверку', 'red'),
    (re.compile(rb'\[plain\] proof build failed'), 'ошибка: не удалось собрать доказательство', 'red'),
    (re.compile(rb'\[plain\] submit failed'), 'ошибка: шара не отправлена', 'red'),
    (re.compile(rb'\[net\] proof gzip failed'), 'ошибка: сжатие доказательства', 'red'),
    (re.compile(rb'\[plain\] OOM'), 'ошибка: не хватило памяти', 'red'),
)
SUBMIT = re.compile(rb'\[net\] plain_proof submit id=(\d+) ')
DIFF = re.compile(rb'\[pool\] mining\.set_difficulty ([0-9.]+)')


def observe(raw):
    """Feed every native output line; never raises."""
    try:
        now = time.time()
        m = SUBMIT.match(raw)
        if m:
            with _lock:
                _pending[int(m.group(1))] = now
                while len(_pending) > 64:
                    _pending.pop(next(iter(_pending)))
            return
        if raw.startswith(NOTIFY) and b'mining.notify' in raw:
            body = json.loads(raw[len(b'[pool-raw] '):].decode('utf-8', 'replace'))
            p = body.get('params') or {}
            job = label(p.get('job_id') or '?', 24)
            height = p.get('height')
            text = 'новое задание ' + job + ('' if height is None else '  · высота ' + str(height))
            _add(now, [S(text, 'blue')])
            return
        m = DIFF.match(raw)
        if m:
            _add(now, [S('пул: сложность ' + m.group(1).decode(), 'cyan')])
            return
        for prefix, text, color in SIMPLE:
            if raw.startswith(prefix):
                _add(now, [S(text, color, color == 'red')])
                return
        for pattern, text, color in PATTERNS:
            if pattern.match(raw):
                _add(now, [S(text, color, color == 'red')])
                return
    except Exception:
        return


def share_event(event):
    """Native ledger share result (accepted or rejected) -> feed line."""
    try:
        observed = event.get('observed_at')
        wall = time.time() - max(0.0, time.monotonic() - observed) if isinstance(observed, (int, float)) else time.time()
        rid = event.get('id')
        latency = event.get('latency_ms')
        device = event.get('device')
        gpu = 'GPU' + (str(device) if device is not None else '?') + '  '
        lat = S('[' + (number(latency, 0) if latency is not None else '—').rjust(4) + ' мс]  ', 'dim')
        if event.get('category') == 'accepted':
            _last_share_wall[0] = wall
            _add(wall, [S(gpu, 'text'), S('шара принята    ', 'green', True), lat, S('#' + str(rid), 'dim')])
        else:
            pool_text = reject_reasons.lookup(rid) if type(rid) is int else None
            reason = label(pool_text or event.get('error') or '', 70)
            kind = label(event.get('category') or 'отказ', 12).upper()
            _add(wall, [S(gpu, 'text'), S(('ОТКАЗ ' + kind).ljust(16), 'red', True), lat,
                        S('#' + str(rid) + '  ', 'dim'), S(reason, 'red')])
    except Exception:
        return


# ---------------------------------------------------------------- slow samplers

_ping = {'ms': None, 'at': None}
_gpu_info = {}          # uuid(lower) -> (pci, memory_gb)
_samplers_started = [False]
RTT = re.compile(r'\brtt:([0-9.]+)/')


def _sample_ping():
    try:
        out = subprocess.run(['ss', '-tinp', 'state', 'established'], stdin=subprocess.DEVNULL,
                             capture_output=True, text=True, timeout=2).stdout
        lines = out.splitlines()
        values = []
        for i, line in enumerate(lines):
            if 'nacreon' in line:
                for nxt in lines[i + 1:i + 3]:
                    m = RTT.search(nxt)
                    if m:
                        values.append(float(m.group(1)))
                        break
        _ping['ms'] = min(values) if values else None
        _ping['at'] = time.monotonic()
    except Exception:
        _ping['ms'] = None


def _sample_gpu_info():
    try:
        out = subprocess.run(['nvidia-smi', '--query-gpu=uuid,pci.bus_id,memory.total', '--format=csv,noheader,nounits'],
                             stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=3).stdout
        found = {}
        for row in out.splitlines():
            parts = [p.strip() for p in row.split(',')]
            if len(parts) != 3:
                continue
            uuid, bus, mem = parts
            m = re.search(r'([0-9A-Fa-f]{2}):([0-9A-Fa-f]{2})\.([0-7])$', bus)
            pci = (m.group(1) + ':' + m.group(2)).lower() if m else '—'
            try:
                gb = round(float(mem) / 1024)
            except ValueError:
                gb = None
            found[uuid.lower()] = (pci, gb)
        if found:
            _gpu_info.clear()
            _gpu_info.update(found)
    except Exception:
        return


def _sampler():
    n = 0
    while True:
        _sample_ping()
        if n % 12 == 0:
            _sample_gpu_info()
        n += 1
        time.sleep(5)


def start_samplers():
    if _samplers_started[0]:
        return
    _samplers_started[0] = True
    threading.Thread(target=_sampler, name='kodiaq-samplers', daemon=True).start()


# ---------------------------------------------------------------- rendering

def _cell(text, width, color='text', bold=False, right=True):
    text = label(text, 64)
    if len(text) > width:
        text = text[:max(0, width - 1)] + '…'
    return S(text.rjust(width) if right else text.ljust(width), color, bold)


def _row(*cells):
    out = []
    for i, c in enumerate(cells):
        if i:
            out.append(S('  '))
        out.append(c)
    return L(*out)


def _short_name(name):
    name = (name or 'UNKNOWN').removeprefix('NVIDIA ').removeprefix('GeForce ')
    return name.replace('RTX ', '')


def _total(values):
    vals = [v for v in values if v is not None]
    return sum(vals) if vals else None


def build(data, height=40, width=124, notes=()):
    start_samplers()
    s = data['snapshot']
    detail = s.get('detail', {})
    cards = s.get('cards', {})
    rates = data.get('rates') or {}
    counts = data.get('counts') or {}
    now = data['now']
    wall_now = time.time()
    live = s.get('running') and not data.get('stale')
    width = max(90, min(width, 160))

    a = counts.get('accepted') if counts else None
    r = counts.get('rejected') if counts else None
    n = (a or 0) + (r or 0)
    share_pct = 100.0 * a / n if a is not None and n else None
    averages = data.get('averages') or {}
    h1 = _total((averages.get(3600) or {}).values())
    h24 = _total((averages.get(86400) or {}).values())
    session = (data.get('session_metrics') or {}).get('mean_rate')
    ping = _ping['ms'] if _ping['at'] is not None and time.monotonic() - _ping['at'] < 30 else None
    job_age = detail.get('job_age_seconds')
    share_age = wall_now - _last_share_wall[0] if _last_share_wall[0] else None
    reconnects = None
    count = s.get('connection_count')
    if type(count) is int and count >= 1 and not data.get('stale'):
        reconnects = count - 1
    status = s.get('connection_status', 'UNKNOWN')
    status_color = 'green' if live and status == 'ESTABLISHED' else 'yellow'

    rows = []
    c1, c3, c4, c5 = 34, 14, 20, 18
    c2 = max(24, width - (c1 + c3 + c4 + c5) - 8)
    gap = S('  ')
    title = 'Nacreon ' + label(s.get('version') or '?', 16) + ' · автор ' + DEVELOPER
    rows.append(L(_cell(title, c1, 'cyan', True, False), gap,
                  _cell(label(detail.get('pool') or '—', 40) + ' · TCP', c2, 'text', False, False), gap,
                  _cell('ping ' + (number(ping, 0) + ' мс' if ping is not None else '—'), c3, 'green' if ping is not None else 'dim', False, False), gap,
                  _cell('1ч  ' + (number(h1) + ' TH/s' if h1 is not None else 'сбор данных'), c4, 'green' if h1 is not None else 'dim', False, False), gap,
                  _cell('принято ' + (number(share_pct, 1) + '%' if share_pct is not None else '—'), c5,
                        'green' if share_pct is None or share_pct >= 99 else 'yellow' if share_pct >= 97 else 'red', True, False)))
    rows.append(L(_cell('изм. и лог: ' + EDITOR + ' ' + EDITION, c1, 'dim', False, False), gap,
                  _cell('задание ' + (number(job_age, 0) + ' с' if job_age is not None else '—') + ' · шара '
                        + (number(share_age, 0) + ' с' if share_age is not None else '—') + ' · обрывов '
                        + (str(reconnects) if reconnects is not None else '—'), c2, 'dim', False, False), gap,
                  _cell(label(status, 14), c3, status_color, False, False), gap,
                  _cell('24ч ' + (number(h24) + ' TH/s' if h24 is not None else 'сбор данных'), c4, 'green' if h24 is not None else 'dim', False, False), gap,
                  _cell('работает ' + duration(now - data['started']) if data.get('started') is not None else 'работает —', c5, 'text', False, False)))
    rows.append(L(S('─' * width, 'dim')))

    widths = (2, 5, 10, 13, 13, 13, 6, 4, 4, 17)
    heads = ('#', 'PCI', 'GPU', 'Хешрейт', 'Принято/Откл.', 'Эффект. TH/Вт', 'Мощн.', 'Темп', 'Вент', 'Ядро / Память')
    rows.append(_row(*[_cell(h, w, 'cyan', True, i not in (1, 2)) for i, (h, w) in enumerate(zip(heads, widths))]))
    uuids = data.get('uuids') or {}
    shares = detail.get('per_gpu_shares') or {}
    for d in data.get('devices', []):
        card = cards.get(str(d), {})
        info = _gpu_info.get(str(uuids.get(d, '')).lower(), ('—', None))
        name = _short_name(card.get('name')) + (' ' + str(info[1]) + 'G' if info[1] else '')
        speed = rates.get(d)
        power = card.get('power')
        mean = (data.get('mean_power') or {}).get(d)
        eff = speed / mean if speed is not None and mean else None
        per = shares.get(str(d))
        ar = (str(per['accepted']) + ' / ' + str(per['rejected'])) if per else '—'
        offset = None
        try:
            import core_offsets
            offset = core_offsets.verified(card)
        except Exception:
            offset = None
        core = number(card.get('core'), 0) + (' (' + f'{offset:+d}' + ')' if offset is not None else '')
        clocks = core + ' / ' + number(card.get('memory'), 0)
        temp = card.get('temp')
        rows.append(_row(_cell(str(d), widths[0], 'cyan', False, True),
                      _cell(info[0], widths[1], 'text', False, False),
                      _cell(name, widths[2], 'cyan', False, False),
                      _cell(number(speed) + ' TH/s', widths[3], 'green' if speed else 'yellow', True),
                      _cell(ar, widths[4], 'red' if per and per['rejected'] else 'green'),
                      _cell(number(eff, 3), widths[5]),
                      _cell(number(power, 0) + ' W', widths[6]),
                      _cell(number(temp, 0) + '°', widths[7], 'red' if temp is not None and temp >= 80 else 'text'),
                      _cell(number(card.get('fan'), 0) + '%', widths[8]),
                      _cell(clocks, widths[9])))
    if len(data.get('devices', [])) > 1:
        speed = _total(rates.values())
        power = _total(cards.get(str(d), {}).get('power') for d in data.get('devices', []))
        mean = _total((data.get('mean_power') or {}).values())
        eff = speed / mean if speed is not None and mean else None
        rows.append(_row(_cell('', widths[0]), _cell('', widths[1]), _cell(str(len(data['devices'])) + ' GPU', widths[2], 'text', True, False),
                      _cell(number(speed) + ' TH/s', widths[3], 'green', True),
                      _cell((str(a) if a is not None else '—') + ' / ' + (str(r) if r is not None else '—'), widths[4]),
                      _cell(number(eff, 3), widths[5]), _cell(number(power, 0) + ' W', widths[6])))
    rows.append(L(S('─' * width, 'dim')))
    # CPU / RAM / disk gauges and period statistics from the original console.
    try:
        import host_gauges
        rows += host_gauges.host_gauge_lines(data, width)
    except Exception:
        pass
    try:
        import rich_design
        rows += rich_design.average_rows(data.get('averages') or {}, data.get('metrics'), data.get('session_metrics'))
    except Exception:
        pass
    rows.append(L(S('─' * width, 'dim')))
    for text in list(notes)[-1:]:
        rows.append(L(S('консоль: ', 'yellow'), S(label(text, 110), 'dim')))

    space = max(0, height - 1 - len(rows))
    with _lock:
        feed = sorted(_feed, key=lambda e: (e[0], e[1]))[-space:] if space else []
    if not feed and space:
        rows.append(L(S('ожидание событий…', 'dim')))
    for wall, _, parts in feed:
        rows.append(L(_stamp(wall), *parts))
    return rows
