"""alex_kodiaq: manual start from the console behaves like the HiveOS flight sheet.

`nacreon --pool HOST:PORT --wallet ADDR --worker %WORKER_NAME% --log [--tz +2] [--reject-log]`

The command line is turned into the same private NACREON_ARGS_V1 config the flight
sheet produces, and h-run.sh is started with it: same console, same disk log
(nac-log.sh), same --tz and --reject-log handling. Only our own flags (--log, --tz)
are removed; every other argument reaches the miner unchanged.
"""
import os, pathlib, re, shlex, socket, sys, tempfile

RUN_DIR = pathlib.Path('/run/nacreon')
CLI_CONFIG = RUN_DIR / 'cli-args.conf'
CLI_STATS = RUN_DIR / 'cli-stats.json'
MAGIC = b'NACREON_ARGS_V1\0'
SAFE_WORKER = re.compile(r'[A-Za-z0-9_.-]{1,63}')


def wanted(args):
    """Use the flight-sheet path for an interactive start or when our flags are present."""
    if os.environ.get('NACREON_KODIAQ_CLI') == '1' or not args or '--config' in args:
        return False
    ours = any(a in ('--log', '--tz') or '%WORKER_NAME%' in a for a in args)
    try:
        tty = sys.stdout.isatty()
    except (OSError, ValueError):
        tty = False
    return ours or tty


def parse_tz(value):
    # Same rules as h-config.sh.
    m = re.fullmatch(r'(?:UTC|GMT)?([+-])(\d{1,2})(?::?(\d{2}))?', value)
    if m and int(m.group(2)) * 60 + int(m.group(3) or 0) <= 14 * 60:
        posix = 'UTC' + ('-' if m.group(1) == '+' else '+') + m.group(2) + (':' + m.group(3) if m.group(3) else '')
        return value, posix
    if re.fullmatch(r'[A-Za-z][A-Za-z0-9_+-]*(?:/[A-Za-z0-9_+-]+){0,2}', value) and os.path.isfile('/usr/share/zoneinfo/' + value):
        return value, value
    print('Nacreon: --tz ' + value[:40] + ' не распознан; время рига', file=sys.stderr)
    return None


def hive_worker():
    """Worker name as HiveOS knows it: WORKER_NAME env, /hive-config/rig.conf, then hostname."""
    name = os.environ.get('WORKER_NAME', '')
    if not name:
        try:
            for line in pathlib.Path('/hive-config/rig.conf').read_text(errors='ignore').splitlines():
                if line.startswith('WORKER_NAME='):
                    parts = shlex.split(line.split('=', 1)[1])
                    name = parts[0] if parts else ''
                    break
        except (OSError, ValueError):
            pass
    if not name:
        name = socket.gethostname()
    clean = re.sub(r'[^A-Za-z0-9_.-]', '_', name)[:63] or 'worker'
    if clean != name:
        print('Nacreon: имя воркера «' + name[:63] + '» заменено на ' + clean + ' (пул не принимает пробелы и спецсимволы)', file=sys.stderr)
    return clean


def running(root):
    """PIDs of Nacreon workers from this package that are already running."""
    binaries = {str((root / 'bin' / name).resolve()) for name in ('nacreon-sm86', 'nacreon-sm89', 'nacreon-sm120')}
    found = []
    for entry in os.scandir('/proc'):
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            exe = os.readlink('/proc/' + entry.name + '/exe')
        except OSError:
            continue
        if exe.replace(' (deleted)', '') in binaries:
            found.append(int(entry.name))
    return found


def prepare(args):
    log_enabled, tz, out = False, None, []
    worker = None
    i = 0
    while i < len(args):
        a = args[i]
        i += 1
        if a == '--log':
            log_enabled = True
            continue
        if a == '--tz':
            value = args[i] if i < len(args) else ''
            i += 1
            tz = parse_tz(value) or tz
            continue
        if a.startswith('--tz='):
            tz = parse_tz(a.split('=', 1)[1]) or tz
            continue
        if '%WORKER_NAME%' in a:
            worker = worker or hive_worker()
            a = a.replace('%WORKER_NAME%', worker)
        if '%WAL%' in a:
            raise ValueError('%WAL% подставляет только полётный лист; в ручном запуске укажи адрес кошелька')
        out.append(a)
    if any('\0' in v or '\n' in v or '\r' in v for v in out) or len(out) > 256:
        raise ValueError('недопустимые аргументы')
    payload = MAGIC + b''.join(v.encode('utf-8') + b'\0' for v in out)
    if len(payload) > 65536:
        raise ValueError('слишком длинная командная строка')
    return payload, log_enabled, tz


def write_config(payload):
    RUN_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    if CLI_CONFIG.is_symlink():
        raise ValueError('config symlink refused')
    fd, name = tempfile.mkstemp(prefix='.nacreon-cli-', dir=RUN_DIR)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(payload)
        os.chmod(name, 0o600)
        os.replace(name, CLI_CONFIG)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def run(root, args):
    others = running(root)
    if others:
        print('Nacreon уже работает (PID ' + ', '.join(map(str, others)) + '). Две копии на одной карте мешают друг другу.\n'
              'Сначала остановите майнер полётного листа:  miner stop', file=sys.stderr)
        return 2
    try:
        payload, log_enabled, tz = prepare(args)
        write_config(payload)
    except (ValueError, OSError) as error:
        print('Nacreon: ' + str(error), file=sys.stderr)
        return 2
    env = dict(os.environ)
    env['NACREON_KODIAQ_CLI'] = '1'
    env['NACREON_CLI_CONFIG'] = str(CLI_CONFIG)
    env['NACREON_CLI_LOG'] = '1' if log_enabled else '0'
    env.setdefault('NACREON_STATS_FILE', str(CLI_STATS))
    if tz:
        env['NACREON_TZ'], env['NACREON_LOG_TZ'] = tz
    script = str(root / 'h-run.sh')
    os.execve('/bin/bash', ['bash', script], env)
