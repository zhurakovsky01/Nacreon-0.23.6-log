# RTX20 / SM75

Nacreon 0.24.1 combines architecture-specific CUDA compute modules with its own host wrapper. The modules are authenticated, unpacked and checked before CUDA loading.

RTX20 is selected automatically, including in mixed rigs. Select cards with `--devices`; `NACREON_GPU_ARCH=sm75` selects the SM75 worker explicitly. Existing pool, wallet and worker options apply. HiveOS uses the normal custom miner flight sheet.

Historical testing covers earlier RTX 2060 SUPER and RTX 2060 artifacts. These new artifact hashes remain GPU UNRUN. Other RTX20 models require their own qualification. Architecture detection alone is not a physical test of every model. See the release qualification for exact scope and limitations.

Серия RTX20 выбирается автоматически; для выбора карт используйте `--devices`. Параметры пула, кошелька и воркера остаются обычными. В HiveOS используется стандартный полётный лист custom miner.

Исторически проверены предыдущие файлы для RTX 2060 SUPER и RTX 2060; новые SHA физически не проверены; остальные модели RTX20 отдельно не квалифицированы. Итоговые результаты и ограничения указываются в описании выпуска. Комиссия Nacreon — 0,8%. Устройство чужих модулей не изменено, отсутствие сторонней комиссии не заявляется.
