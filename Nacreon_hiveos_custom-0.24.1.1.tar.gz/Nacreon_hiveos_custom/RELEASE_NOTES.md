# Nacreon 0.24.1 — частный кандидат / private candidate

RTX20/30/40/50 и соответствующие поддерживаемые CMP; Linux/HiveOS.
Раздельные вычислительные библиотеки для каждой архитектуры. Собственная комиссия 0,8%; комиссии пула и сторонних компонентов учитываются отдельно.
Для Pearl на CMP 40HX/50HX/70HX/90HX предусмотрен автоматический профиль 405 МГц. Явные параметры памяти имеют приоритет. Для RTX сохранена защита настроек платформы.
Внешний вид сохранён. Полная GPU-квалификация окончательных SHA и сопоставимое измерение скорости/питания ещё не завершены; результаты —.

Separate compute libraries for each architecture. Nacreon fee 0.8%; pool and third-party fees remain separate.
Pearl has an automatic 405 MHz profile for CMP 40HX/50HX/70HX/90HX. Explicit memory options take priority. RTX platform memory settings retain their existing protection.
Existing display preserved. Final-hash GPU qualification and matched performance/power comparisons remain incomplete; measured results: —.

Исправлена передача подтверждённых CUDA-driver ошибок в диагностические события; неизвестные, proof и сетевые ошибки не считаются подтверждёнными сбоями драйвера.
Confirmed CUDA driver failures retain their origin in diagnostic events; unknown, proof and network exceptions remain separate.
