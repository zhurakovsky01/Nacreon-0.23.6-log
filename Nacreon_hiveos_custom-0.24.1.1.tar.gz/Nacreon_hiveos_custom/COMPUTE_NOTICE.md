# Compute components

Nacreon includes external compute images used with permission. The images retain
their original ownership; Nacreon does not claim authorship of those images.
The Nacreon host and adapters are separate. Dependency license texts and notices
are retained in LICENSE.txt and licenses/.
