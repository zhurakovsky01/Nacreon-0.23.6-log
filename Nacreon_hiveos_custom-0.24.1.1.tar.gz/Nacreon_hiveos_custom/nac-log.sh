#!/bin/bash
# Daily miner log for Extra config --log. Drops per-second GPU counter lines (and the
# per-batch native-smXX-computation records of 0.24+),
# stamps every line with local time, keeps 14 days. Never blocks the miner.
dir="$1"
[[ -n "${NACREON_LOG_TZ:-}" ]] && export TZ="$NACREON_LOG_TZ"
mkdir -p "$dir" 2>/dev/null
find "$dir" -name 'nacreon-*.log' -mtime +14 -delete 2>/dev/null
grep --line-buffered -a -v -E 'native-device-(work|idle)|compute-resource|native-sm[0-9]+(-native)?-computation' | while IFS= read -r line; do
    printf -v day '%(%F)T' -1
    printf '%(%F %T)T %s\n' -1 "$line" >> "$dir/nacreon-$day.log" 2>/dev/null
done
