"""Explicit dual-route snapshot contract; no process, network or device access."""
import math,re
SCHEMA='NACREON_STATS_DUAL_ROUTE_V1'
UUID=re.compile(r'GPU-[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}')
def need(ok):
    if not ok:raise ValueError('invalid dual snapshot')
def integer(n,high=2**64-1):
    need(type(n) is int and 0<=n<=high);return n
def number(n):
    need(type(n) in (int,float) and math.isfinite(n) and n>=0);return n
def counter(v):
    need(type(v) is list and len(v)==2)
    out=[]
    for value in v:
        need(type(value) is str and re.fullmatch(r'0|[1-9][0-9]{0,38}',value) is not None)
        n=int(value);need(n<2**128);out.append(n)
    return tuple(out)

def share_row(row):
    need(type(row) is dict and set(row)=={'accepted','rejected','unknown','pending'})
    return tuple(integer(row[k]) for k in ('accepted','rejected','unknown','pending'))

def validate_snapshot(s,now):
    need(type(s) is dict and set(s)<={'schema','product','version','coin','algo','running','pid','start_ticks','boot_id','monotonic_seconds','uptime','rate_window_seconds','full_wall_rate_window_seconds','rate_method','rate_scope','rate_clock','batch_rate_age_limit','full_wall_rate_method','hs_units','pool_credited_speed_proven','devices','health_v1','user_ready','developer_ready','route_order','passive_capture_routes_v1','child_processes_v1','shares'})
    need(type(s['version']) is str and re.fullmatch(r'[A-Za-z0-9._+-]{1,64}',s['version']) is not None)
    need(s['rate_method']=='confirmed_backend_batch_MAC_per_host_submit_to_finish_second' and s['rate_scope']=='latest_completed_backend_batch_per_device' and s['rate_clock']=='monotonic_seconds')
    if 'pool_credited_speed_proven' in s:need(s['pool_credited_speed_proven'] is False)
    need(type(s) is dict and s['schema']==SCHEMA and s['product']=='Nacreon' and s['coin']=='Pearl' and s['algo']=='pearlhash' and s['hs_units']=='hs')
    need(type(s['running']) is bool and type(s['user_ready']) is bool and type(s['developer_ready']) is bool)
    integer(s['pid'],2**31-1);need(s['pid']>0);integer(s['start_ticks']);need(s['start_ticks']>0)
    need(type(s['boot_id']) is str and 1<=len(s['boot_id'])<=128);integer(s['uptime'])
    stamp=number(s['monotonic_seconds']);number(now);need(0<=now-stamp<=5)
    need(s['route_order']==['user','developer']);need(type(s['shares']) is dict and set(s['shares'])=={'user','developer'})
    ds=s['devices'];need(type(ds) is list and 1<=len(ds)<=32);ids=set();uuids=set();buses=set()
    for d in ds:
        need(type(d) is dict);idx=integer(d['index'],2**31-1);bus=integer(d['bus_number'],255);uuid=d['uuid']
        need(type(uuid) is str and UUID.fullmatch(uuid) is not None and idx not in ids and uuid.lower() not in uuids and bus not in buses)
        ids.add(idx);uuids.add(uuid.lower());buses.add(bus);need(type(d['valid']) is bool)
        raw=counter(d['raw_macs']);current=counter(d['current_macs']);need(all(current[i]<=raw[i] for i in (0,1)))
        b=d['batch'];need(type(b) is dict);seq=integer(b['sequence']);integer(b['timing_errors']);need(type(b['valid']) is bool and type(b['complete_window']) is bool)
        need(b['route'] in ('user','developer') if seq else b['route'] is None);need(b['canonical_macs'] is None if not seq else type(b['canonical_macs']) is int)
        if seq:integer(b['canonical_macs'])
        need(b['scope'] in {'none','measured','timing_invalid','no_confirmed_work','clock_mismatch','device_invalid','stopped','expired'})
        for k in ('submitted_at','completed_at','elapsed_seconds','age_seconds','max_age_seconds'):
            if b[k] is not None:number(b[k])
        for k in ('full_wall_hs','completed_current_hs'):
            if d[k] is not None:number(d[k])
        if d['hs'] is not None:
            hs=number(d['hs']);sent=number(b['submitted_at']);done=number(b['completed_at']);elapsed=number(b['elapsed_seconds']);age=number(b['age_seconds']);limit=number(b['max_age_seconds'])
            need(s['running'] and d['valid'] and b['valid'] and b['scope']=='measured' and seq>0 and b['canonical_macs']>0)
            need(sent<done<=stamp+1e-3 and 0<elapsed<=600 and abs(done-sent-elapsed)<=1e-3)
            need(abs(limit-min(120.,max(10.,4*elapsed)))<=1e-3 and 0<=age<=limit and abs(max(0.,stamp-done)-age)<=1e-3)
            need(hs>0 and abs(hs-b['canonical_macs']/elapsed)<=1e-9*hs)
    for role in ('user','developer'):
        pool=s['shares'][role];need(type(pool) is dict and {'total','devices'}<=set(pool)<={'total','devices','telemetry'});share_row(pool['total'])
        need(type(pool['devices']) is dict and set(pool['devices'])<={str(i) for i in ids})
        for row in pool['devices'].values():share_row(row)
    if 'child_processes_v1' in s:
        from child_idle_cohort import validate
        validate(s['child_processes_v1'],s)
    if 'health_v1'in s:
        from health_snapshot import validate as validate_health
        validate_health(s['health_v1'],s)
    return s

