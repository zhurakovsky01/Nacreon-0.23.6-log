"""alex_kodiaq: readable line log when the output is not a terminal.

Used for the oxzd `gpu_idle_command` (its output goes to /var/log/miner/custom/custom.log
through tee) and for pipes. One short line per event instead of ~27 telemetry lines a second:

  [2026/10/27 12:00:01 PRL] пул: авторизация OK
  [2026/10/27 12:00:02 PRL] задание 97f834f1 · высота 134518
  [2026/10/27 12:00:15 PRL] шара №1 принята [83 мс] · 431.2 TH/s
  [2026/10/27 12:01:02 PRL] ОТКАЗ STALE шара №2 (id 3) [1397 мс]: 21 stale-work
  [2026/10/27 12:02:00 PRL] итог: 430.8 TH/s · принято 57 · отказов 1 (stale 1) · ответ пула 85 мс · работает 00:02:00

The [мс] after a share is the miner's own send-to-reply time from its stats ledger
(the same figure as «Ответ пула» in the table); the share line waits for it at most a few seconds.

From 0.24 the miner also works for the author (declared commission 0.8%) on a second, developer
route that prints its pool replies and jobs to the same output, with JSON-RPC ids that can repeat
the user's. Each reply is matched to the user's or the developer's ledger of the miner's stats file
(id, result and reply time); the author's shares are printed apart and never counted as the user's:

  [2026/11/20 12:03:10 PRL] шара автору №1 принята [92 мс] · комиссия 0,8%, не твоя шара

Errors, faults and unknown lines are always shown (rate-limited per kind, never dropped
silently). Wording avoids the patterns oxzd's h-stats.sh parses ("Total |", "GPU0 [",
"Solution was accepted", "OXZD x.y.z").
"""
import collections, datetime, json, os, re, select, signal, statistics, sys, threading, time, importlib.util, pathlib

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
try:
    import local_clock
    ZONE = local_clock.ZONE
except Exception:
    ZONE = None
try:
    import branding
    EDITION = branding.EDITION
except Exception:
    EDITION = ''
try:
    from work_counter import advance
except Exception:
    def advance(previous, raw):
        if previous is not None and raw < previous:
            raise ValueError('counter went back')
        return raw

WORK_WINDOW = 30.0  # seconds, same window as the console table

SUMMARY_EVERY = int(os.environ.get('NACREON_LINE_SUMMARY', '60') or 60)
LEDGER_WAIT = 4.0   # seconds a share line waits for its time in the miner's stats ledger
LEDGER_POLL = 0.25
UNKNOWN_WAIT = 20.0  # s: no stats file yet - lines that wait for their route are shown after this anyway
MATCH_GAP = 2.0     # s between the miner's own reply time and the reply line, beyond which ids are not matched early
LIMIT_PER_MIN = 5  # visible unknown/diagnostic lines per kind per minute

QUIET_TYPES = {
    'native-device-work', 'native-device-idle', 'native-job-owner', 'native-job',
    'native-batch-timing', 'native-row-slice', 'native-row-admission', 'native-lazy-repack',
    'native-lazy-basis', 'native-input-prep', 'native-computation-cycle',
    'native-byte-conversion-admission', 'host-phase', 'compute-v1-public-preparation-chunk',
    'compute-v1-public-math-gate',
}
# 0.24+: per-architecture computation/admission records (native-sm89-native-computation, native89-resource-admission, …)
QUIET_KIND = re.compile(r'native-sm\d+(?:-native)?-computation|native\d+-resource-admission')
QUIET_TEXT = (
    re.compile(r'\[compute-resource\] '),
    re.compile(r'\[share-map\] '),
    re.compile(r'\[native-pool-response\] '),
    re.compile(r'\[net\] raw forwarding overwrote '),
    re.compile(r'\[v383-fence-occupancy\] '),
    re.compile(r'\[plain\] verify OK '),
    re.compile(r'\[plain\] share submitted; pool ack pending'),
    re.compile(r'\[net\] plain_proof submit sent '),
    re.compile(r'\[net\] pool reader started'),
    re.compile(r'\[net\] new job \S+ while mining'),
    re.compile(r'Developed by '),
)
PROOF = re.compile(r'\[plain\] proof ready .*\(hs=(\d+)\)')
DROPPED = re.compile(r'\[plain\] stale share nonce=\d+ dropped before submit')
SUBMIT = re.compile(r'\[net\] plain_proof submit id=(\d+) job=(\S+)')
VERSION = re.compile(r'Nacreon \| (\S+)\s*$')


class State:
    def __init__(self):
        self.lock = threading.Lock()
        self.started = time.time()
        self.number = 0
        self.pending = {}          # rpc id -> (share number, sent monotonic)
        self.accepted = 0
        self.kinds = {}            # reject kind -> count
        self.acks = []             # recent reply latencies, ms
        self.work = {}             # device -> deque of (miner monotonic s, lifetime completed MACs)
        self.dropped = 0           # shares the miner discarded itself because a newer job had arrived
        self.hidden = 0
        self.budget = {}           # kind -> (window start, shown)
        self.activity = False
        self.waiting = collections.deque()  # pool replies whose line waits for the ledger time
        self.serial = 0            # last ledger serial already used
        self.seen = {}             # pool message (canonical JSON) -> monotonic time; 0.23.9 logs some twice
        # Developer route (0.24+): the author's commission shares, kept apart from the user's.
        # the stats file has a developer route: True / False, None until the stats file was read
        # (at start the miner prints jobs and logins of both routes before its stats exist)
        self.dual = None if os.environ.get('NACREON_STATS_FILE') else False
        self.links = collections.deque()  # (text, seen) pool login / lost lines while the route is unknown
        self.conn = {}             # route -> (connections, connected) from its own connection counters
        self.dev_used = collections.deque(maxlen=256)   # developer ledger serials already printed
        self.dev_floor = None      # developer serials up to this were there before we started
        self.dev_accepted = 0
        self.dev_rejected = 0
        self.dev_total = None      # (accepted, rejected) from the miner's own developer counters
        self.work_dev = None       # developer share of completed work, miner's per-route counters
        self.jobs = collections.deque()   # (job, height, seen) waiting for their route
        self.user_job = None
        self.dev_jobs = collections.deque(maxlen=16)
        self.dev_jobs_hidden = 0


S = State()
OUT = sys.stdout.buffer
ALIVE = [True]
LOST = threading.Event()
BIN_DIR = str((HERE.parent / 'bin').resolve())


def miner_pid():
    """PID of this run's miner (h-run.sh exports it), only while it is still our Nacreon."""
    try:
        pid = int(os.environ.get('NACREON_EXPECTED_PID', ''))
    except ValueError:
        return None
    try:
        exe = os.readlink('/proc/%d/exe' % pid).replace(' (deleted)', '')
        argv = pathlib.Path('/proc/%d/cmdline' % pid).read_bytes().split(b'\0')
    except OSError:
        return None
    paths = [exe] + [os.path.realpath(a.decode('utf-8', 'replace')) for a in argv[1:2] if a]
    return pid if any(p.startswith(BIN_DIR + os.sep) for p in paths) else None


def stop_miner():
    """Nobody reads our output any more (oxzd stopped or died): stop the miner like a broken pipe would."""
    pid = miner_pid()
    if pid is None:
        return
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        return
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        time.sleep(0.5)
        if miner_pid() != pid:
            return
    try:
        os.kill(pid, signal.SIGKILL)
    except OSError:
        pass


def lost():
    if not LOST.is_set():
        LOST.set()
        ALIVE[0] = False
        threading.Thread(target=stop_miner, name='kodiaq-stop', daemon=True).start()


def output_watch(stop):
    """POLLERR on our stdout means the reading side (oxzd / its tee) is gone."""
    try:
        poller = select.poll()
        poller.register(sys.stdout.fileno(), select.POLLERR | select.POLLHUP)
    except (OSError, ValueError, AttributeError):
        return
    while not stop.wait(2):
        try:
            events = poller.poll(0)
        except (OSError, ValueError):
            return
        if events and events[0][1] & (select.POLLERR | select.POLLHUP):
            lost()
            return


def stamp(now=None):
    now = time.time() if now is None else now
    when = datetime.datetime.fromtimestamp(now, ZONE) if ZONE is not None else datetime.datetime.fromtimestamp(now)
    return when.strftime('%Y/%m/%d %H:%M:%S')


def emit(text):
    line = ('[' + stamp() + ' PRL] ' + text.rstrip('\r\n') + '\n').encode('utf-8', 'replace')
    with S.lock:
        if not ALIVE[0]:
            return
        try:
            OUT.write(line)
            OUT.flush()
            return
        except (OSError, ValueError):
            pass
    lost()  # keep draining the miner so it never blocks; stop it because nobody reads the output


def limited(kind, text):
    now = time.monotonic()
    with S.lock:
        start, shown = S.budget.get(kind, (now, 0))
        if now - start >= 60:
            start, shown = now, 0
        if shown >= LIMIT_PER_MIN:
            S.budget[kind] = (start, shown)
            S.hidden += 1
            return
        S.budget[kind] = (start, shown + 1)
    emit(text)


def clean(text, limit=160):
    return ''.join(c for c in str(text) if c.isprintable() and c != '\x1b')[:limit]


def ths(value):
    return format(value / 1e12, '.1f') + ' TH/s'


def pool_labels():
    """Pool host:port and worker from the same private config the console reads; never the wallet."""
    path = os.environ.get('NACREON_CONSOLE_CONFIG')
    try:
        with open(path, 'rb') as f:
            payload = f.read(65537)
    except (OSError, TypeError):
        return None, None
    if len(payload) > 65536 or not payload.startswith(b'NACREON_ARGS_V1\0'):
        return None, None
    args = [v.decode('utf-8', 'replace') for v in payload.split(b'\0')[1:-1]]
    pools, worker = [], None
    for i, key in enumerate(args[:-1]):
        if key in ('--pool', '-o'):
            pools.append(args[i + 1])
        elif key in ('--worker', '-r'):
            worker = args[i + 1]
        elif key in ('--wallet', '-w') and worker is None and '.' in args[i + 1]:
            worker = args[i + 1].rsplit('.', 1)[1]
    pool = None
    if pools:
        scheme, rest = pools[0].split('://', 1) if '://' in pools[0] else ('', pools[0])
        rest = rest.split('/', 1)[0].rsplit('@', 1)[-1]  # never show credentials embedded in a URL
        pool = clean(rest, 80) + (' (ssl)' if 'ssl' in scheme or 'tls' in scheme else '')
        if len(pools) > 1:
            pool += ' (+' + str(len(pools) - 1) + ' резерв)'
    worker = worker if isinstance(worker, str) and re.fullmatch(r'[A-Za-z0-9_.-]{1,63}', worker) else None
    return pool, worker


POOL, WORKER = None, None


def record_work(record):
    """native-device-work: the same completed-work counter the console table uses for TH/s."""
    d, raw, t = record.get('device'), record.get('raw_completed_macs_total'), record.get('monotonic_seconds')
    if type(d) is not int or type(raw) is not int or not isinstance(t, (int, float)):
        return
    t = float(t)
    with S.lock:
        hist = S.work.setdefault(d, collections.deque())
        try:
            total = advance(hist[-1][1] if hist else None, raw)
        except ValueError:
            hist.clear()  # counter reset: start a fresh window
            total = raw
        hist.append((t, total))
        while len(hist) > 2 and hist[1][0] <= t - WORK_WINDOW:
            hist.popleft()


def work_rate():
    """Completed MACs per second over the last ~30 s, summed over GPUs (like the console table)."""
    total, seen = 0.0, False
    with S.lock:
        for hist in S.work.values():
            if len(hist) >= 2:
                (t0, n0), (t1, n1) = hist[0], hist[-1]
                if t1 - t0 >= 1.0:
                    total += (n1 - n0) / (t1 - t0)
                    seen = True
    return total if seen else None


def kind_of(code, message):
    low = (message or '').lower()
    if code == 21 or 'stale' in low or 'job not found' in low or 'expired' in low:
        return 'STALE'
    if code == 22 or 'duplicate' in low:
        return 'DUPLICATE'
    if code == 23 or 'invalid' in low or 'low difficulty' in low or 'bad' in low:
        return 'INVALID'
    return 'ОТКАЗ'


def error_parts(error):
    code = message = None
    if isinstance(error, dict):
        code = error.get('code')
        message = error.get('message') or error.get('msg')
    elif isinstance(error, list) and error:
        code = error[0]
        message = error[1] if len(error) > 1 else None
    elif isinstance(error, (int, str)):
        code, message = (error, None) if isinstance(error, int) else (None, error)
    return (code if isinstance(code, int) else None), (clean(message, 120) if message else '')


def _rows(tel):
    rows = []
    for e in tel.get('events') or []:
        serial, rid, ms = e.get('serial'), e.get('id'), e.get('latency_ms')
        if type(serial) is not int or type(rid) is not int:
            continue
        if not isinstance(ms, (int, float)) or isinstance(ms, bool) or not 0 <= ms < 600000:
            ms = None
        result = e.get('result') if e.get('result') in ('accepted', 'rejected') else None
        seen = e.get('observed_at') if isinstance(e.get('observed_at'), (int, float)) else None
        rows.append(dict(serial=serial, rid=rid, ms=ms, result=result, seen=seen,
                         category=e.get('category'), device=e.get('device')))
    return rows


def _work(snap):
    try:
        user = dev = 0
        for d in snap.get('devices') or []:
            raw = d.get('raw_macs')
            if isinstance(raw, list) and len(raw) == 2:
                user += int(raw[0])
                dev += int(raw[1])
        return dev / (user + dev) if user + dev > 0 else None
    except (TypeError, ValueError):
        return None


def routes():
    """Both ledgers of THIS run from the miner's stats file, or None.

    {'user': [...], 'dev': [...] or None, 'user_job', 'dev_job', 'dev_total', 'work'}
    """
    path = os.environ.get('NACREON_STATS_FILE')
    try:
        pid = int(os.environ.get('NACREON_EXPECTED_PID', ''))
    except ValueError:
        pid = None
    if not path:
        return None
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        with os.fdopen(fd, 'rb') as f:
            data = f.read((1 << 20) + 1)
        if len(data) > 1 << 20:
            return None
        snap = json.loads(data)
        if pid is not None and snap.get('pid') != pid:
            return None  # left over from an earlier run (oxzd restarts PRL often)
        shares = snap['shares']
        tel = shares['user']['telemetry']
        if tel.get('schema') != 'NACREON_POOL_TELEMETRY_V1':
            return None
        def conn(t):
            c = t.get('connection') if isinstance(t.get('connection'), dict) else {}
            return (c.get('connections'), c.get('connected'), c.get('connection_age_seconds'), c.get('current_offline_seconds'))
        out = dict(user=_rows(tel), dev=None, user_job=(tel.get('job') or {}).get('id'), dev_job=None, dev_total=None, work=None,
                   user_conn=conn(tel), dev_conn=None)
        dev = shares.get('developer')
        if isinstance(dev, dict):
            dtel = dev.get('telemetry') if isinstance(dev.get('telemetry'), dict) else {}
            out['dev'] = _rows(dtel)
            out['dev_conn'] = conn(dtel)
            out['dev_job'] = (dtel.get('job') or {}).get('id') if isinstance(dtel.get('job'), dict) else None
            total = dev.get('total') or {}
            out['dev_total'] = (total.get('accepted'), total.get('rejected'))
            out['work'] = _work(snap)
        return out
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return None


def share_line(item, ms):
    """Print one pool reply of the USER route; ms is None when the time is unknown."""
    with S.lock:
        if ms is not None:
            S.acks = (S.acks + [int(ms)])[-50:]
        if item.get('number') is None:
            S.number += 1
            item['number'] = S.number
        if item['ok']:
            S.accepted += 1
        else:
            S.kinds[item['kind']] = S.kinds.get(item['kind'], 0) + 1
    lat = (' [' + str(int(round(ms))) + ' мс]') if ms is not None else ''
    if item['ok']:
        rate = work_rate()
        emit('шара №' + str(item['number']) + ' принята' + lat + ((' · ' + ths(rate)) if rate else ''))
    else:
        emit('ОТКАЗ ' + item['kind'] + ' шара №' + str(item['number']) + ' (id ' + str(item['rid']) + ')' + lat + ': ' + item['reason'])


def fee_text():
    return ('комиссия ' + FEE_TEXT) if FEE_TEXT else 'комиссия автора'


def dev_line(ok, ms, reason=None):
    """One share of the developer route (the author's commission): printed apart, not the user's."""
    with S.lock:
        if ok:
            S.dev_accepted += 1
        else:
            S.dev_rejected += 1
        no = S.dev_accepted + S.dev_rejected
    lat = (' [' + str(int(round(ms))) + ' мс]') if ms is not None else ''
    if ok:
        emit('шара автору №' + str(no) + ' принята' + lat + ' · ' + fee_text() + ', не твоя шара')
    else:
        emit('отказ шары автору №' + str(no) + lat + ': ' + (reason or 'причина не указана') + ' · ' + fee_text() + ', не твоя шара')


def _declared_fee():
    try:
        text = (HERE.parent / 'nacreon').read_text(encoding='utf-8', errors='replace')
        m = re.search(r'fee ([0-9]{1,2}(?:\.[0-9]{1,3})?)%', text)
        return float(m.group(1)) if m else None
    except Exception:
        return None


FEE = _declared_fee()
FEE_TEXT = (format(FEE, 'g').replace('.', ',') + '%') if FEE is not None else ''


FLUSH = threading.Lock()  # one printer at a time keeps share lines in reply order


def flush_waiting(final=False):
    with FLUSH:
        _flush_waiting(final)


def _candidate(rows, item, floor, used=None):
    """First ledger row this reply can be: same wire id and result, not used yet."""
    want = 'accepted' if item['ok'] else 'rejected'
    for row in rows or ():
        if row['serial'] <= floor or (used is not None and row['serial'] in used):
            continue
        if row['rid'] == item['rid'] and row['result'] in (None, want):
            return row
    return None


def _flush_waiting(final):
    """Print waiting replies in order: with the ledger time once it is there, without it after LEDGER_WAIT.

    With a developer route each reply goes to the ledger that has it (user or developer); when both
    have the same wire id, the one whose reply time is closest to when the line was read wins.
    """
    info = routes()
    if info is not None:
        note_routes(info)
    flush_links(final)   # logins and jobs that came before the replies keep their place
    flush_jobs(final)
    user_rows = info['user'] if info else []
    dev_rows = info['dev'] if info else None
    while True:
        with S.lock:
            if not S.waiting:
                break
            item = S.waiting[0]
            user = _candidate(user_rows, item, S.serial)
            dev = _candidate(dev_rows, item, S.dev_floor or 0, S.dev_used) if dev_rows is not None else None
            def gap(row):
                return abs(row['seen'] - item['seen']) if row['seen'] is not None else None
            timed_out = final or time.monotonic() - item['seen'] >= LEDGER_WAIT
            if dev_rows is not None and not timed_out:
                # Same wire id on both routes: a ledger row read far from this reply is not it (yet).
                if user is not None and gap(user) is not None and gap(user) > MATCH_GAP:
                    user = None
                if dev is not None and gap(dev) is not None and gap(dev) > MATCH_GAP:
                    dev = None
            if user and dev:
                if (gap(dev) if gap(dev) is not None else 1e9) < (gap(user) if gap(user) is not None else 1e9):
                    user = None
                else:
                    dev = None
            if user is None and dev is None and not timed_out:
                break  # keep the order: later replies wait behind this one
            S.waiting.popleft()
            if user is not None:
                S.serial = user['serial']
            if dev is not None:
                S.dev_used.append(dev['serial'])
        if dev is not None:
            dev_line(item['ok'], dev['ms'], item.get('reason'))
        else:
            share_line(item, user['ms'] if user is not None else None)
    orphans(dev_rows, final)
    flush_jobs(final)
    flush_links(final)


def orphans(dev_rows, final=False):
    """Developer-ledger shares that never showed up as a reply line (still printed, still apart)."""
    if not dev_rows:
        return
    now = time.monotonic()
    late = []
    with S.lock:
        if S.dev_floor is None:
            return
        for row in dev_rows:
            if row['serial'] <= S.dev_floor or row['serial'] in S.dev_used:
                continue
            if not final and (row['seen'] is None or now - row['seen'] < LEDGER_WAIT + 2):
                continue
            if any(w['rid'] == row['rid'] for w in S.waiting):
                continue
            S.dev_used.append(row['serial'])
            late.append(row)
    for row in late:
        dev_line(row['result'] != 'rejected', row['ms'], label_reason(row.get('category')))


def label_reason(category):
    return clean(category, 40) if isinstance(category, str) and category else None


def note_routes(info):
    """Remember what the developer route looks like now (jobs, totals, work share, connections)."""
    events = []
    with S.lock:
        if info.get('dev') is None:
            S.dual = False
            return
        S.dual = True
        for role, key in (('user', 'user_conn'), ('dev', 'dev_conn')):
            c = info.get(key)
            if not c or type(c[0]) is not int:
                continue
            prev = S.conn.get(role, (0, False))
            S.conn[role] = (c[0], bool(c[1]))
            if c[0] > prev[0]:
                events.append((role, 'up', prev[0]))
            elif prev[1] and not c[1]:
                events.append((role, 'lost', prev[0]))
        if S.dev_floor is None:
            # Shares the author already had before this log started are not printed again.
            S.dev_floor = 0   # the stats file is pinned to this run's PID: every developer share is this run's
        S.user_job = info.get('user_job')
        job = info.get('dev_job')
        if isinstance(job, str) and job and job not in S.dev_jobs:
            S.dev_jobs.append(job)
        S.dev_total = info.get('dev_total')
        S.work_dev = info.get('work')
    for role, what, before in events:
        link_line(role, what, before)


def link_line(role, what, before):
    """Pool connect / lost of one route, told apart by the miner's own per-route counters (0.24+)."""
    if role == 'user':
        if what == 'up':
            if before == 0:
                emit('пул' + (' ' + POOL if POOL else '') + ((' · воркер ' + WORKER) if WORKER else '') + ': подключение и авторизация')
            else:
                emit('пул: переподключение')
        else:
            emit('пул: связь потеряна')
    else:
        if what == 'up':
            emit('пул автора (' + fee_text() + '): подключение')
        else:
            emit('пул автора (' + fee_text() + '): связь прервана — твой майнинг это не затрагивает')


def flush_links(final=False):
    """Login / lost lines printed before we knew whether there is a developer route."""
    now = time.monotonic()
    ready = []
    with S.lock:
        while S.links:
            text, seen = S.links[0]
            if S.dual:
                S.links.popleft()      # both routes print these; the counters above tell them apart
                continue
            if final or S.dual is False or now - seen >= UNKNOWN_WAIT:
                S.links.popleft()
                ready.append(text)
                continue
            break
    for text in ready:
        emit(text)


def route_line(text):
    """A pool login/lost line: as is without a developer route, otherwise wait for the counters."""
    with S.lock:
        if S.dual is not False:
            S.links.append((text, time.monotonic()))
            while len(S.links) > 32:
                S.links.popleft()
            return
    emit(text)


def flush_jobs(final=False):
    """Jobs wait (at most LEDGER_WAIT) until the ledgers say whose they are; the author's are not shown."""
    now = time.monotonic()
    ready = []
    with S.lock:
        while S.jobs:
            job, height, seen = S.jobs[0]
            if job is not None and job in S.dev_jobs and job != S.user_job:
                S.jobs.popleft()
                S.dev_jobs_hidden += 1
                continue
            if final or S.dual is False or job == S.user_job or now - seen >= (LEDGER_WAIT if S.dual else UNKNOWN_WAIT):
                S.jobs.popleft()
                ready.append((job, height))
                continue
            break
    for job, height in ready:
        job_line(job, height)


def job_line(job, height):
    short = clean(str(job).split('_')[0], 16) if job is not None else '?'
    emit('задание ' + short + ((' · высота ' + str(height)) if isinstance(height, int) else ''))


def ledger_loop(stop):
    last_routes = 0.0
    while not stop.wait(LEDGER_POLL):
        try:
            with S.lock:
                busy = bool(S.waiting or S.jobs)
            if busy or time.monotonic() - last_routes >= 2.0:
                last_routes = time.monotonic()
                flush_waiting()
        except Exception:
            pass


def on_submit_response(body):
    try:
        reply = json.loads(body)
    except ValueError:
        limited('pool', 'пул: ' + clean(body))
        return
    if not isinstance(reply, dict):
        return
    rid = reply.get('id')
    now = time.monotonic()
    error = reply.get('error')
    ok = reply.get('result') is True and error is None
    item = dict(rid=rid, ok=ok, seen=now)
    if not ok:
        code, message = error_parts(error)
        item['kind'] = kind_of(code, message)
        item['reason'] = ' '.join(x for x in (str(code) if code is not None else '', message) if x) or 'причина не указана'
    with S.lock:
        number, sent = S.pending.pop(rid, (None, None))
        item['number'] = number      # None: numbered when printed (developer replies get no user number)
        S.activity = True
        direct = sent is not None and not S.waiting and not S.dual
        if not direct:
            S.waiting.append(item)
    if direct:
        share_line(item, (now - sent) * 1000)  # older miners print the submit id: time it here
    else:
        flush_waiting()


def on_pool_raw(body):
    try:
        message = json.loads(body)
    except ValueError:
        return
    if not isinstance(message, dict):
        return
    # The same pool frame can arrive as [pool-raw] and as [pool] forwarded: (0.23.9+): show it once.
    key = json.dumps(message, sort_keys=True)
    now = time.monotonic()
    with S.lock:
        S.seen = {k: t for k, t in S.seen.items() if now - t < 30}
        if key in S.seen:
            return
        S.seen[key] = now
    method = message.get('method')
    params = message.get('params')
    if method == 'mining.notify':
        job = height = None
        if isinstance(params, dict):
            job, height = params.get('job_id'), params.get('height')
        elif isinstance(params, list) and params:
            job = params[0]
        with S.lock:
            S.activity = True
            dual = S.dual
            if dual is not False:
                S.jobs.append((job if isinstance(job, str) else None, height, time.monotonic()))
                while len(S.jobs) > 64:
                    S.jobs.popleft()
        if dual is False:
            job_line(job, height)
    elif method == 'mining.set_difficulty':
        emit('пул: сложность ' + clean(json.dumps(params), 60))
    elif method:
        limited('pool-method', 'пул: ' + clean(method, 40) + ' ' + clean(json.dumps(params), 100))


def on_jsonrpc(body):
    try:
        reply = json.loads(body)
    except ValueError:
        return
    if not isinstance(reply, dict) or reply.get('id') != 1:
        if isinstance(reply, dict) and reply.get('error') is not None:
            code, message = error_parts(reply['error'])
            limited('pool-error', 'пул: ошибка ' + ' '.join(x for x in (str(code) if code is not None else '', message) if x))
        return
    if reply.get('result') is True and reply.get('error') is None:
        route_line('пул: авторизация OK')
    else:
        code, message = error_parts(reply.get('error'))
        emit('пул: ОШИБКА авторизации ' + ' '.join(x for x in (str(code) if code is not None else '', message) if x)
             + (' (твой пул или пул автора — майнер не пишет, чей)' if S.dual is not False else ''))


def on_json(record, raw):
    if record.get('type') == 'native-device-work':
        record_work(record)
    for key in ('error', 'last_execution_error'):
        if record.get(key) is not None:
            limited('json-error', 'ОШИБКА: ' + clean(raw, 300))
            return
    kind = record.get('type')
    if kind == 'native-device-idle' and not (record.get('valid') is True and record.get('execution_valid') is True
                                             and record.get('execution_errors_total') == 0):
        limited('device-idle', 'ПРЕДУПРЕЖДЕНИЕ GPU: ' + clean(raw, 300))
        return
    if kind in QUIET_TYPES or (isinstance(kind, str) and QUIET_KIND.fullmatch(kind)):
        if kind == 'compute-v1-public-math-gate' and record.get('status') != 'PASS':
            emit('ПРОВЕРКА GPU НЕ ПРОЙДЕНА: ' + clean(raw, 300))
        return
    if kind == 'compute-v1-pearl-admission':
        if record.get('status') == 'PASS':
            emit('проверка GPU: OK (ядро ' + clean(record.get('kernel_version'), 12) + ', sm' + clean(record.get('sm'), 4) + ')')
        else:
            emit('ПРОВЕРКА GPU НЕ ПРОЙДЕНА: ' + clean(raw, 300))
        return
    if kind == 'pool-lifecycle':
        if record.get('stage') == 'reader-connection-lost':
            role = record.get('role')
            if role == 'user':
                emit('пул: связь потеряна')
            elif role in ('developer', 'dev'):
                pass   # the author's route: shown from its own counters
            else:
                route_line('пул: связь потеряна')
        return
    if kind == 'native-device-fault':
        emit('ОШИБКА GPU: ' + clean(raw, 300))
        return
    limited('json:' + str(kind)[:40], clean(raw, 300))


def handle(raw):
    try:
        text = raw.decode('utf-8', 'replace').rstrip('\r\n')
    except Exception:
        return
    if not text.strip():
        return
    if text.startswith('{'):
        try:
            record = json.loads(text)
        except ValueError:
            record = None
        if isinstance(record, dict):
            on_json(record, text)
            return
    if text.startswith('[pool] submit response: '):
        on_submit_response(text[len('[pool] submit response: '):])
        return
    if text.startswith('[pool-raw] '):
        on_pool_raw(text[len('[pool-raw] '):])
        return
    if text.startswith('[pool] forwarded: '):
        on_pool_raw(text[len('[pool] forwarded: '):])
        return
    if text.startswith('[pool] jsonrpc: '):
        on_jsonrpc(text[len('[pool] jsonrpc: '):])
        return
    if PROOF.search(text):
        return  # per-proof TMAC/s is the miner's internal figure (~20% below the table); not shown
    if DROPPED.search(text):
        with S.lock:
            S.dropped += 1
        emit('шара отброшена майнером: пришло новое задание (пулу не отправлялась, это не отказ)')
        return
    m = SUBMIT.match(text)
    if m:
        with S.lock:
            S.number += 1
            S.pending[int(m.group(1))] = (S.number, time.monotonic())
            if len(S.pending) > 256:
                S.pending.pop(next(iter(S.pending)))
        return
    if text.startswith('[net] pool authorize'):
        where = ' ' + POOL if POOL else ''
        who = (' · воркер ' + WORKER) if WORKER else ''
        route_line('пул' + where + who + ': подключение и авторизация…')
        return
    m = VERSION.search(text)
    if m:
        emit('Nacreon ' + clean(m.group(1), 20) + ' · автор liked · редакция alex_kodiaq · ' + EDITION)
        return
    if any(p.match(text) for p in QUIET_TEXT):
        return
    head = text.split(' ', 1)[0][:24] if text.startswith('[') else 'text'
    limited('text:' + head, clean(text, 300))


def stats_rate():
    path = os.environ.get('NACREON_STATS_FILE')
    if not path:
        return None
    try:
        spec = importlib.util.spec_from_file_location('kodiaq_hstats', str(HERE.parent / 'h-stats.py'))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        snapshot = module.read_console_snapshot(path)
        values = [d.get('hs') for d in snapshot.get('devices', [])]
        values = [v for v in values if isinstance(v, (int, float)) and v > 0]
        return sum(values) if values else None
    except Exception:
        return None


def summary(final=False):
    with S.lock:
        accepted, kinds, acks, hidden, dropped = S.accepted, dict(S.kinds), list(S.acks), S.hidden, S.dropped
        S.hidden = 0
    rejected = sum(kinds.values())
    detail = (' (' + ', '.join(k.lower() + ' ' + str(v) for k, v in sorted(kinds.items())) + ')') if rejected else ''
    up = int(time.time() - S.started)
    parts = []
    if not final:
        rate = work_rate() or stats_rate()
        parts.append(ths(rate) if rate else 'хешрейт —')
    parts += ['принято ' + str(accepted), 'отказов ' + str(rejected) + detail]
    if dropped:
        parts.append('отброшено майнером ' + str(dropped))
    with S.lock:
        dual, dev_acc, dev_rej, work = S.dual, S.dev_accepted, S.dev_rejected, S.work_dev
        total = S.dev_total
    if total and type(total[0]) is int and type(total[1]) is int:
        dev_acc, dev_rej = total      # the miner's own developer counters
    if dual:
        text = 'автору ' + str(dev_acc) + ' шар' + ((' (отказ ' + str(dev_rej) + ')') if dev_rej else '')
        if work is not None:
            text += ', работа автору ' + format(work * 100, '.2f') + '%'
        parts.append(text + (' (заявлено ' + FEE_TEXT + ')' if FEE_TEXT else ''))
    if acks:
        parts.append('ответ пула ' + str(int(statistics.mean(acks))) + ' мс')
    parts.append(('работал ' if final else 'работает ') + '%02d:%02d:%02d' % (up // 3600, up // 60 % 60, up % 60))
    if POOL:
        parts.append('пул ' + POOL)
    if hidden:
        parts.append('скрыто служебных строк ' + str(hidden))
    return ' · '.join(parts)


def summary_loop(stop):
    while not stop.wait(SUMMARY_EVERY):
        with S.lock:
            if not S.activity and not S.accepted and not S.kinds:
                continue
        emit('итог: ' + summary())


def main():
    global POOL, WORKER
    try:
        POOL, WORKER = pool_labels()
    except Exception:
        POOL, WORKER = None, None
    # The miner owns INT/TERM/HUP; this reader drains until the miner's output ends.
    for name in ('SIGINT', 'SIGTERM', 'SIGHUP', 'SIGQUIT'):
        try:
            signal.signal(getattr(signal, name), signal.SIG_IGN)
        except (AttributeError, OSError, ValueError):
            pass
    stop = threading.Event()
    threading.Thread(target=summary_loop, args=(stop,), name='kodiaq-summary', daemon=True).start()
    threading.Thread(target=output_watch, args=(stop,), name='kodiaq-output', daemon=True).start()
    threading.Thread(target=ledger_loop, args=(stop,), name='kodiaq-ledger', daemon=True).start()
    try:
        for raw in iter(lambda: sys.stdin.buffer.readline(1 << 20), b''):
            try:
                handle(raw)
            except Exception:
                pass
    finally:
        stop.set()
        try:
            flush_waiting(final=True)
        except Exception:
            pass
        try:
            emit('PRL остановлен · ' + summary(final=True))
        except Exception:
            pass
    return 0


if __name__ == '__main__':
    sys.exit(main())
