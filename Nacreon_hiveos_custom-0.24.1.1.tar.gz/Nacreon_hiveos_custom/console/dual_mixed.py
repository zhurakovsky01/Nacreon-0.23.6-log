"""Explicit multi-process DUAL display aggregation, not durable capture proof.

Per-child snapshots remain the authoritative capture/cohort inputs. Aggregate
telemetry retains source process tags and never presents one child's capture as
a complete merged capture.
"""
import copy,collections
from dual_snapshot_contract import validate_snapshot,SCHEMA
def need(ok):
    if not ok:raise ValueError('invalid dual child aggregate')
class DualMerger:
    def __init__(self,identity,started,order,version):
        self.identity=identity;self.started=started;self.order=order;self.version=version
        self.cache={};self.seen={r:{} for r in ('user','developer')};self.events={r:collections.deque(maxlen=32) for r in ('user','developer')};self.serial=dict(user=0,developer=0);self.history=collections.deque(maxlen=128)
    def update(self,arch,s):
        validate_snapshot(s,s['monotonic_seconds']);old=self.cache.get(arch)
        if old:
            need(all(s[k]==old[k] for k in ('pid','start_ticks','boot_id')) and s['monotonic_seconds']>=old['monotonic_seconds'])
            prior={d['index']:d for d in old['devices']};need(set(prior)=={d['index'] for d in s['devices']})
            for d in s['devices']:
                before=prior[d['index']];need(d['uuid']==before['uuid'] and d['bus_number']==before['bus_number'])
                for field in ('raw_macs','current_macs'):need(all(int(d[field][i])>=int(before[field][i]) for i in (0,1)))
            for role in ('user','developer'):
                for field in ('accepted','rejected','unknown'):need(s['shares'][role]['total'][field]>=old['shares'][role]['total'][field])
                need(s['shares'][role]['telemetry']['last_serial']>=old['shares'][role]['telemetry']['last_serial'])
        self.cache[arch]=copy.deepcopy(s)
    def render(self,now,fresh,running=True):
        need(self.cache and now>=self.started and set(fresh)==set(self.cache))
        out=copy.deepcopy(next(iter(self.cache.values())));out.update(self.identity)
        out.update(version=self.version,monotonic_seconds=now,uptime=int(now-self.started),running=running)
        out.pop('passive_capture_routes_v1',None) # never forge complete multi-process capture
        for role in ('user','developer'):out[role+'_ready']=running and all(fresh.values()) and all(s[role+'_ready'] for s in self.cache.values())
        devices={};uuids=set();buses=set()
        for arch,s in self.cache.items():
            for source in s['devices']:
                d=copy.deepcopy(source);need(d['index'] not in devices and d['uuid'].lower() not in uuids and d['bus_number'] not in buses)
                uuids.add(d['uuid'].lower());buses.add(d['bus_number']);b=d['batch'];done=b.get('completed_at')
                if done is not None:b['age_seconds']=max(0.,now-done)
                if not running or not fresh[arch] or (b.get('max_age_seconds') is not None and b.get('age_seconds') is not None and b['age_seconds']>b['max_age_seconds']):
                    d['hs']=None;b['valid']=False;b['scope']='stopped' if not running else 'expired'
                devices[d['index']]=d
        need(set(devices)==set(self.order));out['devices']=[devices[i] for i in self.order]
        current={i:(sum(map(int,d['raw_macs'])),sum(map(int,d['current_macs']))) for i,d in devices.items()}
        if not self.history:self.history.append((self.started,{i:(0,0) for i in self.order}))
        self.history.append((now,current))
        while len(self.history)>2 and self.history[1][0]<=now-30:self.history.popleft()
        at,prior=self.history[0];elapsed=now-at;out['full_wall_rate_window_seconds']=elapsed
        for d in out['devices']:
            raw,cur=current[d['index']];a,b=prior[d['index']]
            d['full_wall_hs']=(raw-a)/elapsed if elapsed>0 and d['valid'] else None
            d['completed_current_hs']=(cur-b)/elapsed if elapsed>0 and d['valid'] else None
        pools={}
        for role in ('user','developer'):
            total=dict(accepted=0,rejected=0,unknown=0,pending=0);per={};rejects=dict(invalid=0,stale=0,duplicate=0,other=0);connections=[];new=[];skipped=0
            for arch,s in self.cache.items():
                pool=s['shares'][role];t=pool['telemetry'];connections.append((fresh[arch],t['connection']))
                for k in total:total[k]+=pool['total'][k]
                need(not(set(per)&set(pool['devices'])));per.update(copy.deepcopy(pool['devices']))
                for k in rejects:rejects[k]+=t['rejected'][k]
                previous=self.seen[role].get(arch,0);incoming=[e for e in t['events'] if e['serial']>previous]
                skipped+=max(0,t['last_serial']-previous-len(incoming))
                for e in incoming:
                    event=copy.deepcopy(e);event['source_process']={k:s[k] for k in ('pid','start_ticks','boot_id')};event['source_role']=role
                    new.append((e['observed_at'],arch,event))
                self.seen[role][arch]=t['last_serial']
            self.serial[role]+=skipped
            for _,arch,event in sorted(new,key=lambda x:(x[0],x[1],x[2]['serial'])):
                self.serial[role]+=1;need(self.serial[role]<2**64);event['serial']=self.serial[role];self.events[role].append(event)
            connected=running and all(f and c['connected'] for f,c in connections)
            connected_at=max(c['connected_at'] for _,c in connections) if connected else None
            losses=[c['lost_at'] for f,c in connections if f and not c['connected'] and c['lost_at'] is not None]
            lost=min(losses) if losses and all(f for f,c in connections) else None
            conn=dict(connected=connected,connections=sum(c['connections'] for _,c in connections),reconnections=sum(c['reconnections'] for _,c in connections),connected_at=connected_at,connection_age_seconds=now-connected_at if connected else None,lost_at=lost,current_offline_seconds=now-lost if lost is not None else None,last_offline_seconds=None,observed_offline_seconds=None)
            jobs=[s['shares'][role]['telemetry']['job'] for s in self.cache.values()]
            same=connected and len({j['id'] for j in jobs})==1 and all(j['received_at'] is not None for j in jobs)
            received=max(j['received_at'] for j in jobs) if same else None
            events=list(self.events[role]);timed=[e['latency_ms'] for e in events if e['latency_ms'] is not None]
            telemetry=dict(schema='NACREON_POOL_TELEMETRY_V1',clock='monotonic_seconds',coverage='session_ledger_process_lifetime',ack_timing='local_submit_call_to_reply_parse',connection=conn,job=dict(id=jobs[0]['id'] if same else None,received_at=received,age_seconds=now-received if received is not None else None),rejected=rejects,last_serial=self.serial[role],events=events,last_ack_latency_ms=events[-1]['latency_ms'] if events else None,mean_recent_ack_latency_ms=sum(timed)/len(timed) if timed else None)
            pools[role]=dict(total=total,devices=per,telemetry=telemetry)
        out['shares']=pools
        from health_snapshot import merge as merge_health
        health=merge_health(self.cache,out,now,fresh,running)
        if health is None:out.pop('health_v1',None)
        else:out['health_v1']=health
        from child_idle_cohort import publish
        out['child_processes_v1']=publish(self.cache,self.identity,now,fresh,running)
        validate_snapshot(out,now);return out
