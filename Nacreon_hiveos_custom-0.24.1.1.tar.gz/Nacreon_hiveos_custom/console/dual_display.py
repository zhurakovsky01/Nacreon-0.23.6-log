"""Explicit dual-role display domain. Never recasts DUAL JSON as USER schema."""
import math,json
from dual_snapshot_contract import validate_snapshot,SCHEMA
def map_dual(snapshot,now,wall_ns,tools):
    s=validate_snapshot(snapshot,now);mono=s['monotonic_seconds']
    if s.get('pool_credited_speed_proven') is not False:raise ValueError('unproven dual speed scope')
    devices=[d['index'] for d in s['devices']];totals={};rates={};sequences={};full={};uuids={};role_work={r:{} for r in ('user','developer')}
    for d in s['devices']:
        i=d['index'];raw=[int(v) for v in d['raw_macs']]
        totals[i]=sum(raw) if d['valid'] else None;uuids[i]=d['uuid'];rates[i],sequences[i]=tools.batch_rate(d,mono,s['running'])
        full[i]=d['full_wall_hs']/1e12 if d['valid'] and tools.finite(d['full_wall_hs']) else None
        for index,role in enumerate(('user','developer')):role_work[role][i]=raw[index]
    user=s['shares']['user'];total=tools.shares(user['total']);native=None;invalid=False
    if 'telemetry' in user:
        try:native=tools.telemetry(user['telemetry'],mono,total,devices)
        except (ValueError,KeyError,TypeError):invalid=True
    counts=dict(accepted=total[0],rejected=total[1],unknown=total[2],invalid=None,stale=None,duplicate=None)
    if native is not None:counts.update({k:native['rejected'][k] for k in ('invalid','stale','duplicate')})
    per={k:dict(accepted=v['accepted'],rejected=v['rejected']) for k,v in user['devices'].items()}
    journal=None;rows={k:tools.shares(v) for k,v in user['devices'].items()}
    if all(v[2]==0 for v in rows.values()) and sum(v[0] for v in rows.values())==total[0] and sum(v[1] for v in rows.values())==total[1]:
        journal={d:rows.get(str(d),(0,0,0,0))[:2] for d in devices}
    window=s.get('full_wall_rate_window_seconds')
    return dict(source_schema=SCHEMA,work_scope='all_routes',shares_scope='user',
        generation=(s['pid'],s['start_ticks'],s['boot_id']),monotonic=mono,uptime=s['uptime'],version=s['version'],
        devices=devices,uuids=uuids,rates=rates,totals=totals,counts=counts,shares=total,per_gpu_shares=per,
        pending=total[3],rate_window=window if tools.finite(window) and window>0 else None,
        wall_ns=wall_ns-int(max(0,now-mono)*1e9),user_ready=s['user_ready'],journal_shares=journal,
        telemetry=native,telemetry_invalid=invalid,rate_method='batch',full_wall_rates=full,batch_sequences=sequences,
        route_work=role_work,developer_accounting=dict(role='developer',shares=s['shares']['developer'],ready=s['developer_ready'],credit=None,payout=None))

def convert_dual(snapshot,now,identity,allow_unmeasured=False):
    s=validate_snapshot(snapshot,now);identity(s)
    if s.get('pool_credited_speed_proven') is not False:raise ValueError('unproven dual speed scope')
    if not s['running']:raise ValueError('stopped dual statistics')
    hs=[];buses=[]
    for d in s['devices']:
        hs.append(d['hs']if d['valid']else None);buses.append(d['bus_number'])
    if allow_unmeasured and any(v is None for v in hs):return None,None
    user=s['shares']['user']['total'];developer=s['shares']['developer']['total']
    out=dict(hs=[v/1e6 if v is not None else None for v in hs],hs_available=[v is not None for v in hs],statistics_available=True,partial=any(v is None for v in hs),status=s.get('health_v1',{}).get('state','partial_statistics'if any(v is None for v in hs)else'mining'),hs_units='mhs',bus_numbers=buses,uptime=s['uptime'],ver=s['version'],algo='pearlhash',
        ar=[user['accepted'],user['rejected']],shares_scope='user',work_scope='all_routes',
        developer=dict(accepted=developer['accepted'],rejected=developer['rejected'],unknown=developer['unknown'],pending=developer['pending']))
    return format(sum(v for v in hs if v is not None)/1000,'.6f'),json.dumps(out,separators=(',',':'),allow_nan=False)
