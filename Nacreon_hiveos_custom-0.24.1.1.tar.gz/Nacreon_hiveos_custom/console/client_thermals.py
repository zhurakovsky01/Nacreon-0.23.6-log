"""Read the already collected Hive/client cache. No driver or network calls."""
import hashlib,json,math,os,re,stat,time
from pathlib import Path
DEFAULT_CACHE=Path('/run/hive/gpu-stats.json')
MAX_BYTES=131072
MAX_AGE=30.0
UUID=re.compile(r'gpu-[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}')
PCI=re.compile(r'(?:(?P<domain>[0-9a-f]{4,8}):)?(?P<bus>[0-9a-f]{2}):(?P<dev>[0-9a-f]{2})\.(?P<func>[0-7])')
def pci(value):
 if not isinstance(value,str):return None
 m=PCI.fullmatch(value.lower())
 if not m:return None
 domain=int(m['domain']or'0',16);dev=int(m['dev'],16)
 if domain>65535 or dev>31:return None
 return f'{domain:04x}:{m["bus"]}:{m["dev"]}.{m["func"]}'
def temperature(value):
 if type(value)not in(int,float,str):return None
 if isinstance(value,str)and not re.fullmatch(r'[0-9]{1,3}(?:\.[0-9]{1,3})?',value):return None
 try:value=float(value)
 except ValueError:return None
 return value if math.isfinite(value)and 0<value<=150 else None
def project(payload,expected,age):
 if type(payload)is not dict or type(expected)is not dict or not 1<=len(expected)<=128:return {}
 if type(age)not in(int,float)or not math.isfinite(age)or not 0<=age<=MAX_AGE:return {}
 target={}
 for uuid,bus in expected.items():
  if not isinstance(uuid,str)or not UUID.fullmatch(uuid.lower()):return {}
  bus=pci(bus)
  if bus is None or bus in target.values():return {}
  target[uuid.lower()]=bus
 buses=payload.get('busids')
 if type(buses)is not list or not 1<=len(buses)<=128:return {}
 normalized=[pci(b)for b in buses]
 if None in normalized or len(set(normalized))!=len(normalized):return {}
 indices={b:i for i,b in enumerate(normalized)};rows={}
 def field(key,index):
  values=payload.get(key)
  return temperature(values[index])if type(values)is list and len(values)==len(buses)else None
 for uuid,bus in target.items():
  if bus not in indices:continue
  i=indices[bus];rows[uuid]={'temp':field('temp',i),'memory_temp':field('mtemp',i),'age_seconds':age,'max_age_seconds':MAX_AGE}
 return rows
def unique(pairs):
 value={}
 for k,v in pairs:
  if k in value:raise ValueError('DUPLICATE_CACHE_KEY')
  value[k]=v
 return value
def query(expected,*,path=DEFAULT_CACHE,now=time.time):
 fd=None
 try:
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK);a=os.fstat(fd)
  if not stat.S_ISREG(a.st_mode)or a.st_uid!=0 or a.st_nlink!=1 or a.st_mode&0o022 or not 0<a.st_size<=MAX_BYTES:return {}
  raw=os.read(fd,MAX_BYTES+1);z=os.fstat(fd)
  if len(raw)!=a.st_size or(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)!=(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns):return {}
  data=json.loads(raw,object_pairs_hook=unique)
  return project(data,expected,now()-a.st_mtime)
 except (OSError,ValueError,UnicodeError,TypeError,RecursionError):return {}
 finally:
  if fd is not None:os.close(fd)
