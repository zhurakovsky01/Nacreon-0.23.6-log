"""Pure additive recovery metadata. No process, network, driver or file access."""
import copy,math
PHASES={'connecting','authorizing','no_job','ready','pool_disconnected','reconnecting','stopped','fault'}
STATES=PHASES|{'mining','unrun','stalled','statistics_unavailable'}
DEVICE_STATES={'mining','unrun','stalled','invalid','stopped'}
def need(value):
    if not value:raise ValueError('invalid recovery health')
def number(value):return type(value)in(int,float)and math.isfinite(value)and value>=0
def validate(health,snapshot):
    need(type(health)is dict and set(health)=={'schema','state','user','developer','devices','event_log','stdout_delivery'}and type(health['schema'])is int and health['schema']==1 and health['state']in STATES)
    for role in ('user','developer'):
        r=health[role];need(type(r)is dict and set(r)==({'state','ready','age_seconds'}if role=='user'else{'state','ready'})and r['state']in PHASES and type(r['ready'])is bool)
        if role=='user':need(r['age_seconds']is None or number(r['age_seconds']))
    rows=health['devices'];expected={d['index']:d for d in snapshot['devices']};seen=set();need(type(rows)is list and len(rows)==len(expected))
    for r in rows:
        need(type(r)is dict and set(r)=={'index','state','last_batch_hs','last_batch_age_seconds'}and type(r['index'])is int and r['index']in expected and r['index']not in seen and r['state']in DEVICE_STATES);seen.add(r['index'])
        for key in ('last_batch_hs','last_batch_age_seconds'):need(r[key]is None or number(r[key]))
        if r['state']=='mining':need(snapshot['running']and expected[r['index']]['valid']and expected[r['index']]['hs']is not None)
    log=health['event_log'];need(type(log)is dict and set(log)=={'available','dropped'}and type(log['available'])is bool and type(log['dropped'])is int and 0<=log['dropped']<2**64)
    need(health['stdout_delivery']=='best_effort_nonblocking');return health
def merge(cache,out,now,fresh,running):
    if not all('health_v1'in s for s in cache.values()):return None
    children=[s['health_v1']for s in cache.values()];rows={};actual={d['index']:d for d in out['devices']}
    for arch,s in cache.items():
        for row in s['health_v1']['devices']:
            r=copy.deepcopy(row);d=actual[r['index']]
            if r['last_batch_age_seconds']is not None:r['last_batch_age_seconds']+=max(0.,now-s['monotonic_seconds'])
            if not running:r['state']='stopped'
            elif not d['valid']:r['state']='invalid'
            elif not fresh[arch]or d['hs']is None:r['state']='unrun'
            rows[r['index']]=r
    priority=['fault','stalled','pool_disconnected','reconnecting','no_job','authorizing','connecting','unrun','ready','mining']
    state='stopped'if not running else'statistics_unavailable'if not all(fresh.values())else next((p for p in priority if any(h['state']==p for h in children)),'mining')
    roles={}
    for role in ('user','developer'):
        ready=bool(running and all(fresh.values())and all(h[role]['ready']for h in children));phases=[h[role]['state']for h in children]
        phase='stopped'if not running else'ready'if ready else next((p for p in priority if p in PHASES and p in phases),'reconnecting')
        roles[role]={'state':phase,'ready':ready}
        if role=='user':roles[role]['age_seconds']=None
    result={'schema':1,'state':state,**roles,'devices':[rows[d['index']]for d in out['devices']],'event_log':{'available':all(h['event_log']['available']for h in children),'dropped':min(2**64-1,sum(h['event_log']['dropped']for h in children))},'stdout_delivery':'best_effort_nonblocking'}
    return validate(result,out)
