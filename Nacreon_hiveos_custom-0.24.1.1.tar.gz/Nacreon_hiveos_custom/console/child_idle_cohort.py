"""Bounded optional mixed-child idle attribution, independent of rate/ACK accounting.

Only public /proc identity fields are read. No argv, environment or GPU access.
The kernel start tick supplies a conservative monotonic lower bound: subtract
all suspend time since boot, including time before the process was born.
"""
import math,os,re,time
from pathlib import Path
from idle_metrics import valid_record

SCHEMA='NACREON_MIXED_CHILD_PROCESSES_V1'
IDENTITY=('pid','start_ticks','boot_id')
UUID=re.compile(r'gpu-[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}')
def need(ok):
    if not ok:raise ValueError('invalid mixed child idle cohort')
def number(x):return type(x) in (int,float) and math.isfinite(x) and x>=0
def ident(row):
    need(type(row) is dict and type(row.get('pid')) is int and 0<row['pid']<2**31)
    need(type(row.get('start_ticks')) is int and 0<row['start_ticks']<2**64)
    need(type(row.get('boot_id')) is str and 1<=len(row['boot_id'])<=128)
def process(pid):
    need(type(pid) is int and 0<pid<2**31)
    root=Path('/proc')/str(pid)
    def stat():return (root/'stat').read_text().rsplit(')',1)[1].split()
    first=stat();uid=root.stat().st_uid;second=stat()
    need((first[1],first[19])==(second[1],second[19]) and first[0] not in ('Z','X') and second[0] not in ('Z','X'))
    boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    uptime=float(Path('/proc/uptime').read_text().split()[0]);mono=time.monotonic()
    ticks=int(first[19]);birth=max(0.,ticks/os.sysconf('SC_CLK_TCK')-max(0.,uptime-mono)-1.)
    return dict(pid=pid,start_ticks=ticks,boot_id=boot,uid=uid,ppid=int(first[1]),birth_lower=birth)
def same(a,b):return all(a[k]==b[k] for k in IDENTITY)
def validate(meta,s):
    need(type(meta) is dict and set(meta)=={'schema','parent','children'} and meta['schema']==SCHEMA)
    parent=meta['parent'];ident(parent);need(set(parent)==set(IDENTITY) and same(parent,s))
    children=meta['children'];need(type(children) is list and 1<=len(children)<=4)
    expected={(d['index'],d['uuid'].lower()) for d in s['devices']};seen=set();pids=set()
    need(1<=len(expected)<=8)
    for c in children:
        ident(c);need(set(c)==set(IDENTITY)|{'devices','snapshot_monotonic','fresh','verified'})
        need(c['pid']!=parent['pid'] and c['pid'] not in pids and c['boot_id']==parent['boot_id']);pids.add(c['pid'])
        need(type(c['fresh']) is bool and type(c['verified']) is bool and number(c['snapshot_monotonic']))
        need(c['snapshot_monotonic']<=s['monotonic_seconds']+1e-6)
        if c['fresh']:need(s['running'] and 0<=s['monotonic_seconds']-c['snapshot_monotonic']<=5)
        need(type(c['devices']) is list and 1<=len(c['devices'])<=8)
        for d in c['devices']:
            need(type(d) is dict and set(d)=={'index','uuid'} and type(d['index']) is int and 0<=d['index']<32)
            need(type(d['uuid']) is str and UUID.fullmatch(d['uuid'].lower()) is not None)
            key=(d['index'],d['uuid'].lower());need(key in expected and key not in seen);seen.add(key)
    need(seen==expected);return meta
def owned(c,parent,probe=process):
    p=probe(parent['pid']);v=probe(c['pid'])
    need(same(p,parent) and same(v,c) and v['ppid']==p['pid'] and v['uid']==p['uid'])
    return v
def publish(cache,parent,now,fresh,running,probe=process):
    rows=[]
    for arch,s in cache.items():
        c={k:s[k] for k in IDENTITY};c.update(devices=[dict(index=d['index'],uuid=d['uuid']) for d in s['devices']],snapshot_monotonic=s['monotonic_seconds'],fresh=bool(running and fresh[arch] and 0<=now-s['monotonic_seconds']<=5),verified=False)
        try:owned(c,parent,probe);c['verified']=True
        except (OSError,ValueError,IndexError,KeyError):pass
        rows.append(c)
    return dict(schema=SCHEMA,parent={k:parent[k] for k in IDENTITY},children=rows)
class Bindings:
    def __init__(self,pid,probe=process):self.pid=pid;self.probe=probe;self.active=False;self.rows={};self.parent=None
    def clear(self):self.rows={}
    def configure(self,s):
        if 'child_processes_v1' not in s:
            if self.active:self.clear()
            return
        self.active=True;self.clear();meta=validate(s['child_processes_v1'],s)
        need(meta['parent']['pid']==self.pid);self.parent=meta['parent']
        for c in meta['children']:
            if not(c['fresh'] and c['verified']):continue
            try:v=owned(c,self.parent,self.probe)
            except (OSError,ValueError,IndexError,KeyError):continue
            for d in c['devices']:self.rows[d['index']]=(c,v['birth_lower'],d['uuid'].lower())
    def _allows(self,r,now,row):
        d=r.get('device')
        if not valid_record(r,d):return False
        c,birth,uuid=row
        if r['uuid'].lower()!=uuid or not 0<=now-c['snapshot_monotonic']<=5:return False
        try:
            pid,ns=map(int,r['generation'].split('-'));gen=ns/1e9
            return (pid==c['pid'] and birth<=gen<=r['through']+0.1 and r['coverage_since']<=gen+0.1 and
                    birth<=r['coverage_since']<=r['through']<=now+0.1)
        except (ValueError,OverflowError):return False
    def permits(self,r,now):
        d=r.get('device');row=self.rows.get(d)
        if not row:return False
        try:
            owned(row[0],self.parent,self.probe)
            return self._allows(r,now,row)
        except (OSError,ValueError,IndexError,KeyError):return False
    def select(self,d,rows,uuid,now):
        # One process check per GPU/frame, never once per retained ring sample.
        row=self.rows.get(d)
        if not row:return []
        try:owned(row[0],self.parent,self.probe)
        except (OSError,ValueError,IndexError,KeyError):return []
        return [dict(r) for r in rows if r.get('uuid')==uuid and self._allows(r,now,row)]
