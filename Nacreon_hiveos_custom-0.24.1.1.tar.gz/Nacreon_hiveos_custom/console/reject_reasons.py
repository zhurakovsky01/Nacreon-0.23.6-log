"""Exact pool reject texts by JSON-RPC id (alex_kodiaq edit).

The native ledger only classifies rejects (invalid/stale/duplicate/other).
The pool's own message is in the raw line `[pool] submit response: {...}`;
it is captured here and shown next to the reject. Bounded memory.

From 0.24 the developer route (0.8% commission) prints its replies to the same output
and its JSON-RPC ids can repeat the user's; each text keeps the time it was read, and
lookup() takes the one closest to the miner's own reply time.
"""
import collections, json, threading, time

PREFIX = b'[pool] submit response: '
_lock = threading.Lock()
_reasons = collections.OrderedDict()
LIMIT = 64

def _text(error):
    if error is None:
        return None
    if isinstance(error, list):
        parts = [str(x) for x in error if x is not None]
        return ' '.join(parts) if parts else None
    if isinstance(error, dict):
        message = error.get('message') or error.get('msg')
        code = error.get('code')
        if message is not None:
            return (str(code) + ' ' if code is not None else '') + str(message)
        return json.dumps(error, ensure_ascii=False)
    return str(error)

def observe(raw):
    """Feed every native output line; never raises."""
    try:
        if not raw.startswith(PREFIX):
            return
        reply = json.loads(raw[len(PREFIX):].decode('utf-8', 'replace'))
        rid = reply.get('id')
        if type(rid) is not int:
            return
        text = _text(reply.get('error'))
        if text is None and reply.get('result') is False:
            text = 'result=false'
        if text is None:
            return
        text = ''.join(c for c in text if c.isprintable() and c != '\x1b')[:90]
        now = time.monotonic()
        with _lock:
            rows = _reasons.setdefault(rid, collections.deque(maxlen=4))
            rows.append((now, text))
            _reasons.move_to_end(rid)
            while len(_reasons) > LIMIT:
                _reasons.popitem(last=False)
    except Exception:
        return

def lookup(rid, at=None):
    """Pool text for this id; with `at` (monotonic reply time) the reply read closest to it."""
    with _lock:
        rows = list(_reasons.get(rid) or ())
    if not rows:
        return None
    if isinstance(at, (int, float)) and not isinstance(at, bool):
        when, text = min(rows, key=lambda r: abs(r[0] - at))
        return text if abs(when - at) <= 10 else None
    return rows[-1][1]
