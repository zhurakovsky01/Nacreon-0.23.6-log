"""Resolve one architecture and prioritize its exact companion proof library."""
import os
ARCHES={'sm75','sm86','sm89','sm120'}
def native_path(root,arch):
    if arch not in ARCHES:raise ValueError('Unsupported native architecture')
    return root/'bin'/arch/('nacreon-'+arch)
def native_environment(path,env=None):
    result=dict(os.environ if env is None else env)
    if path.parent.name=='sm120' and path.name=='nacreon-sm120':
        result.setdefault('NACREON_SM120_REUSE_A_CV','1')
    directory=str(path.parent)
    old=result.get('LD_LIBRARY_PATH','')
    result['LD_LIBRARY_PATH']=directory+(':'+old if old else '')
    return result
