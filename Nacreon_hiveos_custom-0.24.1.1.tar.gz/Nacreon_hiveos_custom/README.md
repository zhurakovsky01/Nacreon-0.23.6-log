# Nacreon 0.24.1

Pearl (PRL / PearlHash) · NVIDIA RTX20 / RTX30 / RTX40 / RTX50 · Linux / HiveOS

Комиссия Nacreon — **0,8%**. Комиссии пула и сторонних компонентов учитываются отдельно.
Nacreon developer fee: **0.8%**. Pool and third-party component fees are separate.
Python3.10+, Linux x86-64 and a compatible NVIDIA driver are required.

## Русский

Nacreon для RTX20, RTX30, RTX40 и RTX50. Инструкции запуска и настройки приведены ниже.

### Linux: установка и запуск

Нужны x86-64 Linux, glibc 2.34+, libssl/libcrypto 3, libz.so.1, совместимый драйвер NVIDIA выбранной карты, writable tmpfs /run либо /dev/shm; Python 3.10+ для консоли/Hive. Используйте приложенный Linux-архив и проверьте SHA256SUMS. Проверяйте подписи, если к выпуску приложены файлы подписей.

```bash
tar -xzf Nacreon_linux-0.24.1.tar.gz
cd nacreon
./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01 --password x
```

Замените `YOUR_PEARL_WALLET` на **свой** адрес Pearl либо логин аккаунта, который требует ваш пул. `rig01` — **ваше** имя воркера. Не вводите закрытый ключ или seed-фразу. Для имени воркера используйте латинские буквы, цифры, `_` и `-` (до 63 символов). Пароль `x` подходит, если пул не требует другой.

Для Kryptex кошелёк и имя воркера можно также передать вместе:

```bash
./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET.rig01
```

Используйте отдельный --worker либо суффикс .rig01.

### Основные параметры

| Параметр | Что задаёт | Пример |
|---|---|---|
| `--pool`, `-o` | Пул и порт; можно повторять для резервных подключений | `--pool prl.kryptex.network:7048` |
| `--wallet`, `-w` | Ваш кошелёк или логин пула | `--wallet YOUR_PEARL_WALLET` |
| `--worker`, `-r` | Ваше имя воркера | `--worker rig01` |
| `--password`, `-p` | Пароль пула, по умолчанию `x` | `--password x` |
| `--devices`, `-d` | Выбранные CUDA-номера или GPU UUID; без параметра — автоматически | `--devices 0,1` |
| `--coff` | Смещение ядра, МГц | `--coff 100` |
| `--cclk` | Фиксированная частота ядра, МГц | `--cclk 2400` |
| `--moff` | Смещение памяти, МГц драйвера | `--moff 100` |
| `--mclk` | Фиксированная частота памяти, МГц драйвера | `--mclk 810` |
| `--pl` | Power limit **каждой карты**, Вт | `--pl 180` |
| `--fan` | Вентиляторы: процент либо автоматический режим | `--fan 60` / `--fan auto` |
| `--help` | Справка | `./nacreon --help` |
| `--version` | Версия | `./nacreon --version` |

Остановка — **Ctrl+C**. Дождитесь завершения перед повторным запуском.

<a id="gpu-settings"></a>

### Linux: power limit, ядро и память

Для изменения настроек GPU нужны права **root** (`sudo`) и поддержка драйвера/карты. Без явных параметров разгона настройки ядра, лимита мощности и вентилятора сохраняются. Для памяти по умолчанию включён `--auto-memory on`: режим 405/810 МГц применяется только после проверки профиля и настроек платформы. При `--auto-memory off` автоматическое управление памятью отключено. Явные `--mclk`/`--moff` имеют приоритет; на RTX абсолютная частота платформы от 5000 МГц сохраняется. Числа ниже — примеры синтаксиса, а не универсальный профиль RTX 30: подбирайте допустимые значения для своей карты.

Лимит 180 Вт на каждую выбранную карту:

```bash
sudo ./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01 --devices 0,1 --pl 180
```

Смещение ядра +100 МГц, смещение памяти +100 МГц и лимит мощности:

```bash
sudo ./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01 --coff 100 --moff 100 --pl 180
```

Фиксированная частота памяти задаётся **вместо её смещения**. Например, если карта и драйвер поддерживают 810 МГц:

```bash
sudo ./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01 --coff 100 --mclk 810 --pl 180
```

`--coff 100` означает **+100 к ядру**, а `--cclk 2400` — **задать ядро 2400 МГц**. Аналогично `--moff` — смещение памяти, `--mclk` — фиксированная частота. Значения памяти указаны в единицах драйвера, их нельзя автоматически приравнивать к эффективной частоте памяти или числам из другого ПО. Недопустимые или неподдерживаемые настройки приводят к сообщению об ошибке; это не подтверждение, что настройка применена.

Одно значение действует на все выбранные GPU. Список через запятую соответствует порядку `--devices`; `*` оставляет настройку этой карты без изменений. Пример: GPU 0 — 180 Вт / +100 МГц ядро; GPU 1 — 190 Вт / +125 МГц:

```bash
sudo ./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01 --devices 0,1 --pl 180,190 --coff 100,125 --fan 60,auto
```

Чтобы оставить смещение GPU 1 прежним: `--coff '100,*'`. Не задавайте противоречащие настройки одновременно в нескольких программах. Проверяйте температуру, принятые/отклонённые шары и стабильность после изменения разгона.

### Резервный пул

```bash
./nacreon --pool prl.kryptex.network:7048 --pool prl-ru.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01
```

Повторный `--pool` добавляет резерв подключения, а не второй одновременно работающий пул. Для пользовательского майнинга выбираются указанные вами адреса.

### HiveOS

Создайте кошелёк со **своим адресом**, выберите его в полётном листе и настройте **Custom miner**:

| Поле | Значение |
|---|---|
| Miner name | `Nacreon_hiveos_custom` |
| Installation URL | PRIVATE_ARCHIVE_URL_FROM_OPERATOR |
| Algorithm | `pearlhash` |
| Wallet / worker template | `%WAL%.%WORKER_NAME%` |
| Pool URL | `prl.kryptex.network:7048` |
| Password | `x` |
| Extra config | Пусто либо, например, `--devices 0,1` |

`%WAL%` подставляет выбранный кошелёк, `%WORKER_NAME%` — имя вашего воркера HiveOS. Введите шаблон целиком. Разгон и power limit удобно задавать штатно в HiveOS. Не дублируйте их противоречащими значениями в Extra config. Консоль — команда `miner`; запуск и остановка — средствами HiveOS.

### Экран и обновление

Экран обновляется раз в 5 секунд. «Сеанс связи» — длительность текущего подключения к пулу. Подтверждённые отказы пула учитываются отдельно от ошибок выполнения майнера. Внизу — три последние принятые пользовательские шары и время ответа пула (ACK). Для сырых диагностических сообщений: `NACREON_RAW_CONSOLE=1 ./nacreon ...`.

Перед обновлением остановите майнер, сохраните прежнюю версию и свои настройки. Распакуйте новую версию в отдельный каталог. Для возврата остановите её и запустите прежнюю. Условия использования — `LICENSE.txt`, сторонние лицензии — `licenses/`.

## English

Nacreon for RTX20, RTX30, RTX40 and RTX50. See the installation and tuning instructions below.

### Linux: install and run

Requires x86-64 Linux, glibc 2.34+, libssl/libcrypto 3, libz.so.1, a compatible NVIDIA driver for the selected GPU, writable tmpfs /run or /dev/shm, and Python 3.10+ for console/Hive. Use the supplied Linux archive and verify SHA256SUMS. Verify signatures when signature files are published with the release.

```bash
tar -xzf Nacreon_linux-0.24.1.tar.gz
cd nacreon
./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01 --password x
```

Replace `YOUR_PEARL_WALLET` with **your own** Pearl address or the account login required by your pool. Replace `rig01` with **your own** worker name. Never enter a private key or seed phrase. Worker names accept Latin letters, digits, `_` and `-`, up to 63 characters. The default pool password is `x`; use a different one if required by your pool.

For Kryptex, the combined form is also supported:

```bash
./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET.rig01
```

Use either --worker or a .rig01 suffix.

### Main options

| Option | Purpose | Example |
|---|---|---|
| `--pool`, `-o` | Pool host and port; repeat for connection failover | `--pool prl.kryptex.network:7048` |
| `--wallet`, `-w` | Your wallet or pool account login | `--wallet YOUR_PEARL_WALLET` |
| `--worker`, `-r` | Your worker name | `--worker rig01` |
| `--password`, `-p` | Pool password; default `x` | `--password x` |
| `--devices`, `-d` | CUDA ordinals or GPU UUIDs; automatic selection by default | `--devices 0,1` |
| `--coff` | Core clock offset, MHz | `--coff 100` |
| `--cclk` | Locked core clock, MHz | `--cclk 2400` |
| `--moff` | Memory clock offset, driver MHz | `--moff 100` |
| `--mclk` | Locked memory clock, driver MHz | `--mclk 810` |
| `--pl` | Power limit **per GPU**, watts | `--pl 180` |
| `--fan` | Fan percentage or automatic control | `--fan 60` / `--fan auto` |
| `--help` | Command help | `./nacreon --help` |
| `--version` | Miner version | `./nacreon --version` |

Stop with **Ctrl+C** and wait for exit before starting again.

### Linux: power limit, core and memory settings

GPU tuning requires **root** (`sudo`) and support from your GPU/driver. Without explicit tuning options, existing core, power-limit and fan settings are preserved. Memory control defaults to `--auto-memory on`: the 405/810 MHz mode requires a qualified profile and platform settings. `--auto-memory off` disables automatic memory control. Explicit `--mclk`/`--moff` take priority; on RTX, platform absolute memory clocks of 5000 MHz or higher are preserved. The numbers below demonstrate syntax; they are not a universal RTX 30 profile. Choose values supported by your own cards.

Set a 180 W limit for each selected GPU:

```bash
sudo ./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01 --devices 0,1 --pl 180
```

Apply a +100 MHz core offset, +100 driver MHz memory offset and a power limit:

```bash
sudo ./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01 --coff 100 --moff 100 --pl 180
```

Use a memory lock **instead of a memory offset**. For example, if your card and driver support 810 MHz:

```bash
sudo ./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01 --coff 100 --mclk 810 --pl 180
```

`--coff 100` adds **100 MHz to the core clock**; `--cclk 2400` requests a **2400 MHz core lock**. Likewise, `--moff` is a memory offset and `--mclk` is a memory lock. Memory settings use driver MHz: do not assume they match effective memory rates or values shown by other software. Unsupported or out-of-range settings produce an error; an error does not mean the requested setting was applied.

One value applies to all selected GPUs. Comma-separated values follow `--devices` order; `*` preserves that GPU's setting. Example: GPU 0 at 180 W / +100 MHz core, GPU 1 at 190 W / +125 MHz core:

```bash
sudo ./nacreon --pool prl.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01 --devices 0,1 --pl 180,190 --coff 100,125 --fan 60,auto
```

Use `--coff '100,*'` to preserve GPU 1's core offset. Avoid conflicting settings from multiple tools. Check temperatures, accepted/rejected shares and stability after changing clocks.

### Backup pool

```bash
./nacreon --pool prl.kryptex.network:7048 --pool prl-ru.kryptex.network:7048 --wallet YOUR_PEARL_WALLET --worker rig01
```

Repeating `--pool` adds connection failover, not a second pool mining simultaneously. User mining uses the pool addresses you supply.

### HiveOS

Create a wallet with **your own address**, select it in the Flight Sheet and configure **Custom miner**:

| Field | Value |
|---|---|
| Miner name | `Nacreon_hiveos_custom` |
| Installation URL | PRIVATE_ARCHIVE_URL_FROM_OPERATOR |
| Algorithm | `pearlhash` |
| Wallet / worker template | `%WAL%.%WORKER_NAME%` |
| Pool URL | `prl.kryptex.network:7048` |
| Password | `x` |
| Extra config | Empty, or e.g. `--devices 0,1` |

`%WAL%` expands to your selected wallet; `%WORKER_NAME%` expands to your HiveOS worker name. Enter the complete template. Use HiveOS overclocking controls for clocks and power limits; avoid conflicting values in Extra config. Open the console with `miner`; start and stop through HiveOS.

### Display and updates

The screen refreshes every 5 seconds. Connection session shows the duration of the current pool connection. The footer shows the last three accepted shares and the pool response time.

Before updating, stop the miner and keep the previous version and your settings. Extract the update into a separate directory. To roll back, stop it and start the previous version. Terms: `LICENSE.txt`; third-party notices: `licenses/`.

RU: Майнер работает самостоятельно. Автоматическое управление памятью описано ниже; явные параметры памяти имеют приоритет. Сведения о компонентах: COMPUTE_NOTICE.md.

EN: Standalone miner. Automatic memory control is described below; explicit memory options take priority. Component notices: COMPUTE_NOTICE.md.


## Примечания / Notes

В 0.23.4 наблюдались временные паузы майнинга. Проверенные исправления и оставшиеся ограничения указаны в описании выпуска.


## Смешанные риги / Mixed GPU rigs

Поддерживаемые RTX20, RTX30, RTX40 и RTX50 могут работать на одном риге. Выбор карт выполняется автоматически; параметр `--devices` ограничивает список GPU. Статистика доступна в консоли и HiveOS.

Supported RTX20, RTX30, RTX40 and RTX50 cards can run together. Selection is automatic; use `--devices` to limit the GPUs. Statistics are available in the console and HiveOS.

## Журнал отклонённых шар / Rejected-share journal

Включение и экспорт доступны из каталога установленного майнера: `./nacreon-log on`, `./nacreon-log status`, `./nacreon-log off`, `./nacreon-log export`. При запуске можно добавить `--reject-log`. Подробности: [диагностика отклонений](REJECT_LOGGING.md). Журнал сохраняет доступную очищенную причину; неизвестные сведения остаются неизвестными.

Run these commands from the installed miner directory. See [rejected-share diagnostics](REJECT_LOGGING.md). Unavailable details remain unknown.

Температуры GPU/VRAM отображаются при наличии свежих данных клиента/HiveOS. Если данных нет, показано «—».

GPU/VRAM temperatures are displayed when fresh client/HiveOS data is available. Missing data is shown as «—».



**USDT · BSC (BEP20):** `0x48bb148cb49cb5527574ef26a663639802ed3c25`

## Автоматическая память / Automatic memory

`--auto-memory on|off` — автоматическое управление памятью, по умолчанию `on`.
Для Pearl на CMP 40HX/50HX/70HX/90HX автопрофиль выбирает 405 МГц при пустых дополнительных параметрах, если драйвер поддерживает профиль и исходные настройки можно восстановить. На RTX режим 405/810 МГц требует подтверждённого профиля и известной безопасной исходной настройки.
На RTX абсолютная частота платформы 5000 МГц и выше сохраняется: 5000, 5001, 7000, 7001 и другие значения не заменяются на 405 МГц.
Ниже 5000 МГц автоматический режим возможен после проверки профиля; это не гарантия применения 405 МГц на любой карте.
Параметры `--mclk` и `--moff` всегда имеют приоритет, включая `--mclk 810` и `--moff 0`.
На RTX ненулевое смещение памяти платформы сохраняется. При неизвестной настройке RTX автоматическое управление пропускается.
Текущая частота простоя 405/810 МГц сама по себе не является настройкой пользователя.
Обнаружение изменения платформенной настройки завершает автоматическое управление до перезапуска майнера.
Эта частная сборка ещё не прошла полную проверку переключения настроек на работающем риге.

`--auto-memory on|off` enables automatic memory control; default: `on`.
For Pearl on CMP 40HX/50HX/70HX/90HX, automatic memory control selects 405 MHz with empty extra options when the driver supports the profile and the original settings can be restored. On RTX, the 405/810 MHz mode requires a qualified profile and a known safe original setting.
On RTX, platform absolute memory clocks of 5000 MHz or higher are preserved. Explicit `--mclk` or `--moff` always takes priority, including 810 and zero.
On RTX, nonzero platform memory offsets are preserved and unknown settings disable automatic control. Idle readback alone never establishes user intent.
A detected platform-setting change retires automatic control until the miner restarts.
Live configuration handoff on this private build still requires physical qualification.

## Статус частного кандидата / Private candidate status

0.24.1: исходники и CPU-проверки не заменяют физические GPU-тесты окончательных SHA.
Сравнение скорости и потребления с эталоном для этих файлов: —. Публикация не выполнена.
Source and CPU checks do not replace GPU qualification of the final artifact hashes. Measured speed and power comparisons for these files: —. Not published.
