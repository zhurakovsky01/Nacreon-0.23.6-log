"""Own optional journal boundary. No CUDA, network or native-library calls."""
import collections,ctypes,hashlib,io,json,os,pathlib,re,select,signal,stat,subprocess,sys,tempfile,threading,time
from reject_journal import Journal,Projector,unique
MAGIC=b'NACREON_ARGS_V1\0';LIMIT=65536
H=lambda b:hashlib.sha256(b).hexdigest()

def strip_options(tokens):
 # Pass1 removes ONLY own flags. Protect explicit known credential/config
 # values, but do not guess the arity of unknown/boolean native options.
 known={'--wallet','--user','-w','--password','--pass','-p','--worker','-r'}
 out=[];secrets=['x'];enabled=False;i=0
 while i<len(tokens):
  token=tokens[i];i+=1
  if token=='--reject-log':enabled=True;continue
  if token.startswith('--reject-log='):
   value=token.split('=',1)[1]
   if value not in ('on','off'):raise ValueError('reject-log expects on or off')
   enabled=value=='on';continue
  out.append(token)
  if token in known|{'--config'} and i<len(tokens):out.append(tokens[i]);i+=1
 # Pass2 extracts ONLY known credential options, preserving every other token.
 for i,token in enumerate(out):
  key=token.split('=',1)[0]
  if key not in known:continue
  if '=' in token:value=token.split('=',1)[1]
  elif i+1<len(out):value=out[i+1]
  else:continue
  secrets.append(value)
  if key in ('--wallet','--user','-w'):secrets.extend(value.rsplit('.',1))
 return out,tuple(secrets),enabled

def prepare_args(args,stdin=None):
 """Strip own option BEFORE old native/config parser. Snapshot config once.

 Config bytes read from stdin are returned as bytes for the caller to hand off
 exactly once. No credentials are put in environment, journal or helper argv.
 """
 original=list(args);args,outer_secrets,outer_enabled=strip_options(original)
 outer_flag=len(args)!=len(original)
 if len(args)==2 and args[0]=='--config':
  if args[1]=='-':data=(stdin or sys.stdin.buffer).read(LIMIT+1)
  else:
   try:
    fd=os.open(args[1],os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
    with os.fdopen(fd,'rb') as f:data=f.read(LIMIT+1)
   except OSError:
    # Keep old native behavior for a config the optional observer cannot read.
    # No journal can be enabled without a complete known-secret set.
    return list(args),None,False,None
  if len(data)>LIMIT or not data.startswith(MAGIC) or not data.endswith(b'\0'):raise ValueError('invalid generated configuration')
  tokens=[s.decode('utf-8') for s in data[len(MAGIC):-1].split(b'\0')]
  clean,secrets,enabled=strip_options(tokens)
  data=MAGIC+b''.join(s.encode()+b'\0' for s in clean)
  secrets=tuple(dict.fromkeys(outer_secrets+secrets))
  return ['--config','-'],secrets,outer_enabled if outer_flag else enabled,data
 return args,outer_secrets,outer_enabled,None

def config_stdin(data):
 if data is None:return
 fd=os.memfd_create('nacreon-config',os.MFD_CLOEXEC)
 try:os.write(fd,data);os.lseek(fd,0,0);os.dup2(fd,0)
 finally:os.close(fd)

def ticks(pid):return int((pathlib.Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()[19])
def tmpfs(path):
 if os.name!='posix':return False
 api=ctypes.CDLL(None,use_errno=True);buf=(ctypes.c_long*64)();fn=api.statfs;fn.argtypes=[ctypes.c_char_p,ctypes.c_void_p];fn.restype=ctypes.c_int
 return fn(os.fsencode(path),ctypes.byref(buf))==0 and buf[0]==0x01021994

class Store:
 """All accesses relative to an owned, pinned tmpfs directory FD."""
 def __init__(self,path,create=False):
  path=pathlib.Path(path)
  if not path.is_absolute() or not tmpfs(path):raise ValueError('journal requires tmpfs')
  self.path=path;self.fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
  st=os.fstat(self.fd)
  if not stat.S_ISDIR(st.st_mode) or st.st_uid!=os.geteuid() or st.st_mode&0o077:
   os.close(self.fd);raise ValueError('unowned journal directory')
 def close(self):
  if self.fd is not None:os.close(self.fd);self.fd=None
 def read(self,name,cap):
  if not re.fullmatch(r'[a-z0-9.-]{1,64}',name):raise ValueError('filename')
  fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=self.fd)
  with os.fdopen(fd,'rb') as f:
   st=os.fstat(f.fileno())
   if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.geteuid() or st.st_nlink!=1 or st.st_mode&0o077 or st.st_size>cap:raise ValueError('unowned journal file')
   b=f.read(cap+1)
  if len(b)>cap:raise ValueError('journal file too large')
  return b
 def write(self,name,data):
  if not re.fullmatch(r'[a-z0-9.-]{1,64}',name) or len(data)>262144:raise ValueError('journal file bound')
  try:
   old=os.stat(name,dir_fd=self.fd,follow_symlinks=False)
   if not stat.S_ISREG(old.st_mode) or old.st_uid!=os.geteuid() or old.st_nlink!=1 or old.st_mode&0o077:raise ValueError('unsafe existing journal file')
  except FileNotFoundError:pass
  temp='tmp-'+os.urandom(12).hex()
  fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.fd)
  try:
   with os.fdopen(fd,'wb') as f:f.write(data)
   os.rename(temp,name,src_dir_fd=self.fd,dst_dir_fd=self.fd)
  finally:
   try:os.unlink(temp,dir_fd=self.fd)
   except FileNotFoundError:pass

def create_runtime(pid):
 # Fixed atomic slots bound BOTH journal and stats storage, including stale
 # processes and failed starts. No independent unbounded stats directories.
 root=next(p for p in ('/dev/shm','/run') if os.access(p,os.W_OK) and tmpfs(p))
 for slot in range(32):
  path=pathlib.Path(root)/('nacreon-reject-%d-slot%d'%(os.geteuid(),slot))
  try:os.mkdir(path,0o700)
  except FileExistsError:continue
  store=Store(path);store.close();return path
 raise ValueError('journal runtime capacity')

def cleanup_failed_runtime(path):
 if path is None:return
 store=Store(path)
 try:
  names=os.listdir(store.fd)
  if len(names)>12:return
  for name in names:
   if not re.fullmatch(r'owner\.json|control\.json|state\.json|segment[0-3]\.jsonl|stats\.json(?:\.lock)?',name):return
   store.read(name,1048576)
  for name in names:os.unlink(name,dir_fd=store.fd)
 finally:store.close()
 os.rmdir(path)

def snapshot(path,owner):
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 with os.fdopen(fd,'rb') as f:
  st=os.fstat(f.fileno())
  if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.geteuid() or st.st_nlink!=1 or st.st_mode&0o077 or st.st_size>1048576:raise ValueError('snapshot ownership')
  b=f.read(1048577)
 if len(b)>1048576:raise ValueError('snapshot bound')
 s=json.loads(b,object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
 from snapshot_contract import canonical_snapshot,validate_snapshot
 s=canonical_snapshot(s);validate_snapshot(s,time.monotonic())
 if s['pid']!=owner[0] or s['start_ticks']!=owner[1] or ticks(owner[0])!=owner[1]:raise ValueError('snapshot process changed')
 from public_console import telemetry,shares
 telemetry(s['shares']['user']['telemetry'],s['monotonic_seconds'],shares(s['shares']['user']['total']),[d['index'] for d in s['devices']])
 return s

class Service:
 def __init__(self,meta):
  self.meta=meta;self.owner=(meta['pid'],meta['start'],meta['slot']);self.stop=threading.Event();self.lock=threading.Lock()
  self.journal=Journal(max_bytes=1000000);self.projector=Projector(self.journal,meta['secrets']);self.generation=0;self.serial=0;self.failed=False;self.last_control=None;self.since=time.monotonic()
  directory=meta.get('runtime') or create_runtime(meta['pid']);self.store=Store(directory)
  self.store.write('owner.json',json.dumps({k:meta[k] for k in ('pid','start','slot','sha','version')}).encode())
  self.store.write('control.json',json.dumps({'enabled':bool(meta['enabled']),'generation':time.time_ns()}).encode())
  self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
 def line(self,raw):
  if not self.journal.enabled or self.failed:return
  if not self.lock.acquire(False):self.journal.dropped+=1;return
  try:self.projector.observe_line(self.owner,raw,time.monotonic())
  except Exception:self.failed=True;self.journal.control('off')
  finally:self.lock.release()
 def flush(self):
  data=self.journal.export();segments=[]
  # Split on complete JSONL rows: no record is cut across files.
  chunk=bytearray()
  for line in data.splitlines(keepends=True):
   if len(chunk)+len(line)>262144:segments.append(bytes(chunk));chunk.clear()
   chunk.extend(line)
  if chunk:segments.append(bytes(chunk))
  if len(segments)>4:raise ValueError('journal rotation bound')
  rows=[]
  for i,b in enumerate(segments):
   name='segment%d.jsonl'%i;self.store.write(name,b);rows.append({'name':name,'sha256':H(b),'bytes':len(b)})
  self.generation+=1
  self.store.write('state.json',json.dumps({'generation':self.generation,'segments':rows,'enabled':self.journal.enabled,'failed':self.failed,'dropped':self.journal.dropped,'evicted':self.journal.evicted,'control_generation':self.last_control or 0}).encode())
 def run(self):
  try:
   while not self.stop.is_set():
    try:
     c=json.loads(self.store.read('control.json',256),object_pairs_hook=unique)
     if set(c)!={'enabled','generation'} or type(c['enabled'])is not bool or type(c['generation'])is not int:raise ValueError('control')
     if c['generation']!=self.last_control:
      # An idempotent on must not move the capture frontier past a rejection
      # already observed while logging was on. Only a genuine off->on starts
      # a new interval. Publish the exact applied request before acknowledging.
      if c['enabled'] and not self.journal.enabled:self.since=time.monotonic()
      self.last_control=c['generation'];self.failed=False;self.journal.control('on' if c['enabled'] else 'off');self.flush()
     if self.journal.enabled and not self.failed:
      s=snapshot(self.meta['stats'],self.owner)
      changed=False
      for e in s['shares']['user']['telemetry']['events']:
       if e['serial']<=self.serial:continue
       if e['observed_at']>time.monotonic()-2:break # bounded grace for stdout delivery
       self.serial=e['serial']
       if e['result']!='rejected' or e['observed_at']<self.since:continue
       with self.lock:added=self.projector.ledger_event(self.owner,e,build=s['version'],native_sha256=self.meta['sha'],totals=s['shares']['user']['total'],snapshot_monotonic=s['monotonic_seconds'])
       changed=changed or added
      if changed:self.flush()
    except (OSError,ValueError,KeyError,TypeError):pass # missing stats is unknown, never a rejection
    except Exception:self.failed=True;self.journal.control('off')
    self.stop.wait(1.)
  finally:
   try:self.flush()
   except Exception:pass
 def close(self):self.stop.set();self.thread.join(2);self.store.close()

def pump(stream,meta,write=None):
 """Forward bytes in every mode; optional journal errors never escape."""
 write=write or (lambda b:os.write(1,b));service=None
 try:
  try:service=Service(meta)
  except Exception:pass
  while True:
   b=stream.readline(65536)
   if not b:break
   # stdout backpressure already exists; journal work never writes that pipe.
   try:
    view=memoryview(b)
    while view:
     n=write(view)
     if not n:raise OSError('output unavailable')
     view=view[n:]
   except (OSError,BrokenPipeError):pass # keep draining so logging cannot SIGPIPE native
   if service is not None:
    try:service.line(b)
    except Exception:
     try:service.close()
     except Exception:pass
     service=None
 finally:
  if service is not None:
   try:service.close()
   except Exception:pass

def metadata(path,pid,stats,secrets,enabled,slot=1):
 return {'pid':pid,'start':ticks(pid),'slot':slot,'sha':H(pathlib.Path(path).read_bytes()),'version':'0.23.8','stats':str(stats),'secrets':list(secrets),'enabled':enabled}

def attach_single(root,path,secrets,enabled):
 """exec PID stays native PID. Optional observer is a sibling pipe reader."""
 r=w=fd=ackr=ackw=None;child=None;runtime=None;old_stats=os.environ.get('NACREON_STATS_FILE')
 try:
  # Raw/non-TTY wrappers may not have supplied a stats file. Only a private
  # tmpfs path is added; existing supplied Hive/console stats stay unchanged.
  runtime=create_runtime(os.getpid());stats=old_stats
  if not stats:
   stats=str(runtime/'stats.json')
  meta=metadata(path,os.getpid(),stats,secrets,enabled)
  meta['runtime']=str(runtime)
  fd=os.memfd_create('nacreon-log-metadata',os.MFD_CLOEXEC);os.write(fd,json.dumps(meta).encode());os.lseek(fd,0,0)
  r,w=os.pipe();ackr,ackw=os.pipe()
  child=subprocess.Popen([sys.executable,'-I','-B',str(root/'reject_tap.py'),str(fd),str(ackw)],stdin=r,pass_fds=(fd,ackw),stderr=subprocess.DEVNULL)
  # Import/metadata failures must be known BEFORE replacing native stdout.
  if not select.select([ackr],[],[],2.)[0] or os.read(ackr,1)!=b'R':raise OSError('observer unavailable')
  os.dup2(w,1)
  if old_stats is None:os.environ['NACREON_STATS_FILE']=stats
  return True
 except Exception:
  if w is not None:
   try:os.close(w)
   except OSError:pass
   w=None
  if child is not None:
   try:child.wait(2)
   except Exception:
    try:child.kill();child.wait(2)
    except Exception:pass
  try:cleanup_failed_runtime(runtime)
  except Exception:pass
  return False
 finally:
  for d in (r,w,fd,ackr,ackw):
   if d is not None:
    try:os.close(d)
    except OSError:pass

def mixed_reader(root,path,stats,secrets,enabled,slot):
 """Create reader thread BEFORE deciding to pipe a child, for fail-open startup."""
 ready=threading.Event();holder={}
 def run():
  ready.wait()
  child=holder.get('child')
  if child is None:return
  try:meta=metadata(path,child.pid,stats,secrets,enabled,slot)
  except Exception:meta={}
  pump(child.stdout,meta)
 try:
  thread=threading.Thread(target=run,daemon=True);thread.start()
 except Exception:return None
 def bind(child):holder['child']=child;ready.set()
 return bind

def tap_main():
 fd=int(sys.argv[1]);data=os.read(fd,32769);os.close(fd)
 if len(data)>32768:raise ValueError('metadata bound')
 meta=json.loads(data,object_pairs_hook=unique)
 for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,signal.SIG_IGN)
 ack=int(sys.argv[2]);os.write(ack,b'R');os.close(ack)
 pump(sys.stdin.buffer,meta)
