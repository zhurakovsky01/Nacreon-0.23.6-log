"""alex_kodiaq: readable line log when the output is not a terminal.

Used for the oxzd `gpu_idle_command` (its output goes to /var/log/miner/custom/custom.log
through tee) and for pipes. One short line per event instead of ~27 telemetry lines a second:

  [2026/10/27 12:00:01 PRL] пул: авторизация OK
  [2026/10/27 12:00:02 PRL] задание 97f834f1 · высота 134518
  [2026/10/27 12:00:15 PRL] шара №1 принята [83 мс] · 431.2 TH/s
  [2026/10/27 12:01:02 PRL] ОТКАЗ STALE шара №2 (id 3) [1397 мс]: 21 stale-work
  [2026/10/27 12:02:00 PRL] итог: 430.8 TH/s · принято 57 · отказов 1 (stale 1) · ответ пула 85 мс · работает 00:02:00

The [мс] after a share is the miner's own send-to-reply time from its stats ledger
(the same figure as «Ответ пула» in the table); the share line waits for it at most a few seconds.

Errors, faults and unknown lines are always shown (rate-limited per kind, never dropped
silently). Wording avoids the patterns oxzd's h-stats.sh parses ("Total |", "GPU0 [",
"Solution was accepted", "OXZD x.y.z").
"""
import collections, datetime, json, os, re, select, signal, statistics, sys, threading, time, importlib.util, pathlib

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
try:
    import local_clock
    ZONE = local_clock.ZONE
except Exception:
    ZONE = None
try:
    import branding
    EDITION = branding.EDITION
except Exception:
    EDITION = ''
try:
    from work_counter import advance
except Exception:
    def advance(previous, raw):
        if previous is not None and raw < previous:
            raise ValueError('counter went back')
        return raw

WORK_WINDOW = 30.0  # seconds, same window as the console table

SUMMARY_EVERY = int(os.environ.get('NACREON_LINE_SUMMARY', '60') or 60)
LEDGER_WAIT = 4.0   # seconds a share line waits for its time in the miner's stats ledger
LEDGER_POLL = 0.25
LIMIT_PER_MIN = 5  # visible unknown/diagnostic lines per kind per minute

QUIET_TYPES = {
    'native-device-work', 'native-device-idle', 'native-job-owner', 'native-job',
    'native-batch-timing', 'native-row-slice', 'native-row-admission', 'native-lazy-repack',
    'native-lazy-basis', 'native-input-prep', 'native-computation-cycle',
    'native-byte-conversion-admission', 'host-phase', 'compute-v1-public-preparation-chunk',
    'compute-v1-public-math-gate',
}
QUIET_TEXT = (
    re.compile(r'\[compute-resource\] '),
    re.compile(r'\[share-map\] '),
    re.compile(r'\[native-pool-response\] '),
    re.compile(r'\[v383-fence-occupancy\] '),
    re.compile(r'\[plain\] verify OK '),
    re.compile(r'\[plain\] share submitted; pool ack pending'),
    re.compile(r'\[net\] plain_proof submit sent '),
    re.compile(r'\[net\] pool reader started'),
    re.compile(r'\[net\] new job \S+ while mining'),
    re.compile(r'Developed by '),
)
PROOF = re.compile(r'\[plain\] proof ready .*\(hs=(\d+)\)')
DROPPED = re.compile(r'\[plain\] stale share nonce=\d+ dropped before submit')
SUBMIT = re.compile(r'\[net\] plain_proof submit id=(\d+) job=(\S+)')
VERSION = re.compile(r'Nacreon \| (\S+)\s*$')


class State:
    def __init__(self):
        self.lock = threading.Lock()
        self.started = time.time()
        self.number = 0
        self.pending = {}          # rpc id -> (share number, sent monotonic)
        self.accepted = 0
        self.kinds = {}            # reject kind -> count
        self.acks = []             # recent reply latencies, ms
        self.work = {}             # device -> deque of (miner monotonic s, lifetime completed MACs)
        self.dropped = 0           # shares the miner discarded itself because a newer job had arrived
        self.hidden = 0
        self.budget = {}           # kind -> (window start, shown)
        self.activity = False
        self.waiting = collections.deque()  # pool replies whose line waits for the ledger time
        self.serial = 0            # last ledger serial already used


S = State()
OUT = sys.stdout.buffer
ALIVE = [True]
LOST = threading.Event()
BIN_DIR = str((HERE.parent / 'bin').resolve())


def miner_pid():
    """PID of this run's miner (h-run.sh exports it), only while it is still our Nacreon."""
    try:
        pid = int(os.environ.get('NACREON_EXPECTED_PID', ''))
    except ValueError:
        return None
    try:
        exe = os.readlink('/proc/%d/exe' % pid).replace(' (deleted)', '')
        argv = pathlib.Path('/proc/%d/cmdline' % pid).read_bytes().split(b'\0')
    except OSError:
        return None
    paths = [exe] + [os.path.realpath(a.decode('utf-8', 'replace')) for a in argv[1:2] if a]
    return pid if any(p.startswith(BIN_DIR + os.sep) for p in paths) else None


def stop_miner():
    """Nobody reads our output any more (oxzd stopped or died): stop the miner like a broken pipe would."""
    pid = miner_pid()
    if pid is None:
        return
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        return
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        time.sleep(0.5)
        if miner_pid() != pid:
            return
    try:
        os.kill(pid, signal.SIGKILL)
    except OSError:
        pass


def lost():
    if not LOST.is_set():
        LOST.set()
        ALIVE[0] = False
        threading.Thread(target=stop_miner, name='kodiaq-stop', daemon=True).start()


def output_watch(stop):
    """POLLERR on our stdout means the reading side (oxzd / its tee) is gone."""
    try:
        poller = select.poll()
        poller.register(sys.stdout.fileno(), select.POLLERR | select.POLLHUP)
    except (OSError, ValueError, AttributeError):
        return
    while not stop.wait(2):
        try:
            events = poller.poll(0)
        except (OSError, ValueError):
            return
        if events and events[0][1] & (select.POLLERR | select.POLLHUP):
            lost()
            return


def stamp(now=None):
    now = time.time() if now is None else now
    when = datetime.datetime.fromtimestamp(now, ZONE) if ZONE is not None else datetime.datetime.fromtimestamp(now)
    return when.strftime('%Y/%m/%d %H:%M:%S')


def emit(text):
    line = ('[' + stamp() + ' PRL] ' + text.rstrip('\r\n') + '\n').encode('utf-8', 'replace')
    with S.lock:
        if not ALIVE[0]:
            return
        try:
            OUT.write(line)
            OUT.flush()
            return
        except (OSError, ValueError):
            pass
    lost()  # keep draining the miner so it never blocks; stop it because nobody reads the output


def limited(kind, text):
    now = time.monotonic()
    with S.lock:
        start, shown = S.budget.get(kind, (now, 0))
        if now - start >= 60:
            start, shown = now, 0
        if shown >= LIMIT_PER_MIN:
            S.budget[kind] = (start, shown)
            S.hidden += 1
            return
        S.budget[kind] = (start, shown + 1)
    emit(text)


def clean(text, limit=160):
    return ''.join(c for c in str(text) if c.isprintable() and c != '\x1b')[:limit]


def ths(value):
    return format(value / 1e12, '.1f') + ' TH/s'


def pool_labels():
    """Pool host:port and worker from the same private config the console reads; never the wallet."""
    path = os.environ.get('NACREON_CONSOLE_CONFIG')
    try:
        with open(path, 'rb') as f:
            payload = f.read(65537)
    except (OSError, TypeError):
        return None, None
    if len(payload) > 65536 or not payload.startswith(b'NACREON_ARGS_V1\0'):
        return None, None
    args = [v.decode('utf-8', 'replace') for v in payload.split(b'\0')[1:-1]]
    pools, worker = [], None
    for i, key in enumerate(args[:-1]):
        if key in ('--pool', '-o'):
            pools.append(args[i + 1])
        elif key in ('--worker', '-r'):
            worker = args[i + 1]
        elif key in ('--wallet', '-w') and worker is None and '.' in args[i + 1]:
            worker = args[i + 1].rsplit('.', 1)[1]
    pool = None
    if pools:
        scheme, rest = pools[0].split('://', 1) if '://' in pools[0] else ('', pools[0])
        rest = rest.split('/', 1)[0].rsplit('@', 1)[-1]  # never show credentials embedded in a URL
        pool = clean(rest, 80) + (' (ssl)' if 'ssl' in scheme or 'tls' in scheme else '')
        if len(pools) > 1:
            pool += ' (+' + str(len(pools) - 1) + ' резерв)'
    worker = worker if isinstance(worker, str) and re.fullmatch(r'[A-Za-z0-9_.-]{1,63}', worker) else None
    return pool, worker


POOL, WORKER = None, None


def record_work(record):
    """native-device-work: the same completed-work counter the console table uses for TH/s."""
    d, raw, t = record.get('device'), record.get('raw_completed_macs_total'), record.get('monotonic_seconds')
    if type(d) is not int or type(raw) is not int or not isinstance(t, (int, float)):
        return
    t = float(t)
    with S.lock:
        hist = S.work.setdefault(d, collections.deque())
        try:
            total = advance(hist[-1][1] if hist else None, raw)
        except ValueError:
            hist.clear()  # counter reset: start a fresh window
            total = raw
        hist.append((t, total))
        while len(hist) > 2 and hist[1][0] <= t - WORK_WINDOW:
            hist.popleft()


def work_rate():
    """Completed MACs per second over the last ~30 s, summed over GPUs (like the console table)."""
    total, seen = 0.0, False
    with S.lock:
        for hist in S.work.values():
            if len(hist) >= 2:
                (t0, n0), (t1, n1) = hist[0], hist[-1]
                if t1 - t0 >= 1.0:
                    total += (n1 - n0) / (t1 - t0)
                    seen = True
    return total if seen else None


def kind_of(code, message):
    low = (message or '').lower()
    if code == 21 or 'stale' in low or 'job not found' in low or 'expired' in low:
        return 'STALE'
    if code == 22 or 'duplicate' in low:
        return 'DUPLICATE'
    if code == 23 or 'invalid' in low or 'low difficulty' in low or 'bad' in low:
        return 'INVALID'
    return 'ОТКАЗ'


def error_parts(error):
    code = message = None
    if isinstance(error, dict):
        code = error.get('code')
        message = error.get('message') or error.get('msg')
    elif isinstance(error, list) and error:
        code = error[0]
        message = error[1] if len(error) > 1 else None
    elif isinstance(error, (int, str)):
        code, message = (error, None) if isinstance(error, int) else (None, error)
    return (code if isinstance(code, int) else None), (clean(message, 120) if message else '')


def ledger():
    """(serial, wire id, ms) of THIS run from the miner's stats file — the table's «Ответ пула» source."""
    path = os.environ.get('NACREON_STATS_FILE')
    try:
        pid = int(os.environ.get('NACREON_EXPECTED_PID', ''))
    except ValueError:
        pid = None
    if not path:
        return []
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        with os.fdopen(fd, 'rb') as f:
            data = f.read((1 << 20) + 1)
        if len(data) > 1 << 20:
            return []
        snap = json.loads(data)
        if pid is not None and snap.get('pid') != pid:
            return []  # left over from an earlier run (oxzd restarts PRL often)
        tel = snap['shares']['user']['telemetry']
        if tel.get('schema') != 'NACREON_POOL_TELEMETRY_V1':
            return []
        rows = []
        for e in tel.get('events') or []:
            serial, rid, ms = e.get('serial'), e.get('id'), e.get('latency_ms')
            if (type(serial) is int and type(rid) is int and isinstance(ms, (int, float))
                    and not isinstance(ms, bool) and 0 <= ms < 600000):
                rows.append((serial, rid, ms))
        return rows
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return []


def share_line(item, ms):
    """Print one pool reply; ms is None when the time is unknown."""
    if ms is not None:
        with S.lock:
            S.acks = (S.acks + [int(ms)])[-50:]
    lat = (' [' + str(int(round(ms))) + ' мс]') if ms is not None else ''
    if item['ok']:
        rate = work_rate()
        emit('шара №' + str(item['number']) + ' принята' + lat + ((' · ' + ths(rate)) if rate else ''))
    else:
        emit('ОТКАЗ ' + item['kind'] + ' шара №' + str(item['number']) + ' (id ' + str(item['rid']) + ')' + lat + ': ' + item['reason'])


FLUSH = threading.Lock()  # one printer at a time keeps share lines in reply order


def flush_waiting(final=False):
    with FLUSH:
        _flush_waiting(final)


def _flush_waiting(final):
    """Print waiting replies in order: with the ledger time once it is there, without it after LEDGER_WAIT."""
    with S.lock:
        if not S.waiting:
            return
    rows = ledger()
    while True:
        with S.lock:
            if not S.waiting:
                return
            item = S.waiting[0]
            found = None
            for serial, rid, ms in rows:
                if serial > S.serial and rid == item['rid']:
                    found = (serial, ms)
                    break
            if found is None and not final and time.monotonic() - item['seen'] < LEDGER_WAIT:
                return  # keep the order: later replies wait behind this one
            S.waiting.popleft()
            if found is not None:
                S.serial = found[0]
        share_line(item, found[1] if found is not None else None)


def ledger_loop(stop):
    while not stop.wait(LEDGER_POLL):
        try:
            flush_waiting()
        except Exception:
            pass


def on_submit_response(body):
    try:
        reply = json.loads(body)
    except ValueError:
        limited('pool', 'пул: ' + clean(body))
        return
    if not isinstance(reply, dict):
        return
    rid = reply.get('id')
    now = time.monotonic()
    error = reply.get('error')
    ok = reply.get('result') is True and error is None
    item = dict(rid=rid, ok=ok, seen=now)
    if not ok:
        code, message = error_parts(error)
        item['kind'] = kind_of(code, message)
        item['reason'] = ' '.join(x for x in (str(code) if code is not None else '', message) if x) or 'причина не указана'
    with S.lock:
        number, sent = S.pending.pop(rid, (None, None))
        if number is None:
            S.number += 1
            number = S.number
        item['number'] = number
        S.activity = True
        if ok:
            S.accepted += 1
        else:
            S.kinds[item['kind']] = S.kinds.get(item['kind'], 0) + 1
        direct = sent is not None and not S.waiting
        if not direct:
            S.waiting.append(item)
    if direct:
        share_line(item, (now - sent) * 1000)  # older miners print the submit id: time it here
    else:
        flush_waiting()


def on_pool_raw(body):
    try:
        message = json.loads(body)
    except ValueError:
        return
    if not isinstance(message, dict):
        return
    method = message.get('method')
    params = message.get('params')
    if method == 'mining.notify':
        job = height = None
        if isinstance(params, dict):
            job, height = params.get('job_id'), params.get('height')
        elif isinstance(params, list) and params:
            job = params[0]
        short = clean(str(job).split('_')[0], 16) if job is not None else '?'
        with S.lock:
            S.activity = True
        emit('задание ' + short + ((' · высота ' + str(height)) if isinstance(height, int) else ''))
    elif method == 'mining.set_difficulty':
        emit('пул: сложность ' + clean(json.dumps(params), 60))
    elif method:
        limited('pool-method', 'пул: ' + clean(method, 40) + ' ' + clean(json.dumps(params), 100))


def on_jsonrpc(body):
    try:
        reply = json.loads(body)
    except ValueError:
        return
    if not isinstance(reply, dict) or reply.get('id') != 1:
        if isinstance(reply, dict) and reply.get('error') is not None:
            code, message = error_parts(reply['error'])
            limited('pool-error', 'пул: ошибка ' + ' '.join(x for x in (str(code) if code is not None else '', message) if x))
        return
    if reply.get('result') is True and reply.get('error') is None:
        emit('пул: авторизация OK')
    else:
        code, message = error_parts(reply.get('error'))
        emit('пул: ОШИБКА авторизации ' + ' '.join(x for x in (str(code) if code is not None else '', message) if x))


def on_json(record, raw):
    if record.get('type') == 'native-device-work':
        record_work(record)
    for key in ('error', 'last_execution_error'):
        if record.get(key) is not None:
            limited('json-error', 'ОШИБКА: ' + clean(raw, 300))
            return
    kind = record.get('type')
    if kind == 'native-device-idle' and not (record.get('valid') is True and record.get('execution_valid') is True
                                             and record.get('execution_errors_total') == 0):
        limited('device-idle', 'ПРЕДУПРЕЖДЕНИЕ GPU: ' + clean(raw, 300))
        return
    if kind in QUIET_TYPES:
        if kind == 'compute-v1-public-math-gate' and record.get('status') != 'PASS':
            emit('ПРОВЕРКА GPU НЕ ПРОЙДЕНА: ' + clean(raw, 300))
        return
    if kind == 'compute-v1-pearl-admission':
        if record.get('status') == 'PASS':
            emit('проверка GPU: OK (ядро ' + clean(record.get('kernel_version'), 12) + ', sm' + clean(record.get('sm'), 4) + ')')
        else:
            emit('ПРОВЕРКА GPU НЕ ПРОЙДЕНА: ' + clean(raw, 300))
        return
    if kind == 'pool-lifecycle':
        if record.get('stage') == 'reader-connection-lost':
            emit('пул: связь потеряна')
        return
    if kind == 'native-device-fault':
        emit('ОШИБКА GPU: ' + clean(raw, 300))
        return
    limited('json:' + str(kind)[:40], clean(raw, 300))


def handle(raw):
    try:
        text = raw.decode('utf-8', 'replace').rstrip('\r\n')
    except Exception:
        return
    if not text.strip():
        return
    if text.startswith('{'):
        try:
            record = json.loads(text)
        except ValueError:
            record = None
        if isinstance(record, dict):
            on_json(record, text)
            return
    if text.startswith('[pool] submit response: '):
        on_submit_response(text[len('[pool] submit response: '):])
        return
    if text.startswith('[pool-raw] '):
        on_pool_raw(text[len('[pool-raw] '):])
        return
    if text.startswith('[pool] jsonrpc: '):
        on_jsonrpc(text[len('[pool] jsonrpc: '):])
        return
    if PROOF.search(text):
        return  # per-proof TMAC/s is the miner's internal figure (~20% below the table); not shown
    if DROPPED.search(text):
        with S.lock:
            S.dropped += 1
        emit('шара отброшена майнером: пришло новое задание (пулу не отправлялась, это не отказ)')
        return
    m = SUBMIT.match(text)
    if m:
        with S.lock:
            S.number += 1
            S.pending[int(m.group(1))] = (S.number, time.monotonic())
            if len(S.pending) > 256:
                S.pending.pop(next(iter(S.pending)))
        return
    if text.startswith('[net] pool authorize'):
        where = ' ' + POOL if POOL else ''
        who = (' · воркер ' + WORKER) if WORKER else ''
        emit('пул' + where + who + ': подключение и авторизация…')
        return
    m = VERSION.search(text)
    if m:
        emit('Nacreon ' + clean(m.group(1), 20) + ' · автор liked · редакция alex_kodiaq · ' + EDITION)
        return
    if any(p.match(text) for p in QUIET_TEXT):
        return
    head = text.split(' ', 1)[0][:24] if text.startswith('[') else 'text'
    limited('text:' + head, clean(text, 300))


def stats_rate():
    path = os.environ.get('NACREON_STATS_FILE')
    if not path:
        return None
    try:
        spec = importlib.util.spec_from_file_location('kodiaq_hstats', str(HERE.parent / 'h-stats.py'))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        snapshot = module.read_console_snapshot(path)
        values = [d.get('hs') for d in snapshot.get('devices', [])]
        values = [v for v in values if isinstance(v, (int, float)) and v > 0]
        return sum(values) if values else None
    except Exception:
        return None


def summary(final=False):
    with S.lock:
        accepted, kinds, acks, hidden, dropped = S.accepted, dict(S.kinds), list(S.acks), S.hidden, S.dropped
        S.hidden = 0
    rejected = sum(kinds.values())
    detail = (' (' + ', '.join(k.lower() + ' ' + str(v) for k, v in sorted(kinds.items())) + ')') if rejected else ''
    up = int(time.time() - S.started)
    parts = []
    if not final:
        rate = work_rate() or stats_rate()
        parts.append(ths(rate) if rate else 'хешрейт —')
    parts += ['принято ' + str(accepted), 'отказов ' + str(rejected) + detail]
    if dropped:
        parts.append('отброшено майнером ' + str(dropped))
    if acks:
        parts.append('ответ пула ' + str(int(statistics.mean(acks))) + ' мс')
    parts.append(('работал ' if final else 'работает ') + '%02d:%02d:%02d' % (up // 3600, up // 60 % 60, up % 60))
    if POOL:
        parts.append('пул ' + POOL)
    if hidden:
        parts.append('скрыто служебных строк ' + str(hidden))
    return ' · '.join(parts)


def summary_loop(stop):
    while not stop.wait(SUMMARY_EVERY):
        with S.lock:
            if not S.activity and not S.accepted and not S.kinds:
                continue
        emit('итог: ' + summary())


def main():
    global POOL, WORKER
    try:
        POOL, WORKER = pool_labels()
    except Exception:
        POOL, WORKER = None, None
    # The miner owns INT/TERM/HUP; this reader drains until the miner's output ends.
    for name in ('SIGINT', 'SIGTERM', 'SIGHUP', 'SIGQUIT'):
        try:
            signal.signal(getattr(signal, name), signal.SIG_IGN)
        except (AttributeError, OSError, ValueError):
            pass
    stop = threading.Event()
    threading.Thread(target=summary_loop, args=(stop,), name='kodiaq-summary', daemon=True).start()
    threading.Thread(target=output_watch, args=(stop,), name='kodiaq-output', daemon=True).start()
    threading.Thread(target=ledger_loop, args=(stop,), name='kodiaq-ledger', daemon=True).start()
    try:
        for raw in iter(lambda: sys.stdin.buffer.readline(1 << 20), b''):
            try:
                handle(raw)
            except Exception:
                pass
    finally:
        stop.set()
        try:
            flush_waiting(final=True)
        except Exception:
            pass
        try:
            emit('PRL остановлен · ' + summary(final=True))
        except Exception:
            pass
    return 0


if __name__ == '__main__':
    sys.exit(main())
