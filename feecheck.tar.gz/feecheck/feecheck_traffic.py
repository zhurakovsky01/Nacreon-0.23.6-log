#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""feecheck: сколько байт риг отправил и получил по каждому адресу - весь трафик, без содержимого.

Читает построчный вывод `tcpdump -nn -l -q -tt` (только заголовки) и раз в 30 с сохраняет
итоги в JSON: адрес и порт на той стороне -> отправлено/получено байт, пакетов, первый/последний раз.
Итоги копятся между перезапусками (отключениями света). Содержимое пакетов не читается и не хранится.
Запуск (делает feecheck.sh): tcpdump ... | python3 -I feecheck_traffic.py data/traffic.json 192.168.1.216,fe80::1
"""
import json, os, re, signal, sys, time

LINE = re.compile(r'^(\d+)\.\d+ (IP6?) (\S+) > (\S+?): (.*)$')
LEN = re.compile(r'(?:tcp |length )(\d+)')
LIMIT = 20000          # адресов максимум; остальное в «прочее»


def split(addr, v6):
    """'1.2.3.4.443' -> ('1.2.3.4', '443'); у ICMP порта нет."""
    host, _, port = addr.rpartition('.')
    if host and port.isdigit():
        return host, port
    return addr, ''


def main():
    out_path, local = sys.argv[1], {a for a in sys.argv[2].split(',') if a}
    try:
        with open(out_path, encoding='utf-8') as f:
            stats = json.load(f)
    except (OSError, ValueError):
        stats = {}
    last_save = time.monotonic()

    def save():
        tmp = out_path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(stats, f)
        os.replace(tmp, out_path)

    def stop(*_):
        save()
        sys.exit(0)
    signal.signal(signal.SIGTERM, stop)

    for line in sys.stdin:
        m = LINE.match(line)
        if m:
            t, v6, src, dst, rest = int(m.group(1)), m.group(2) == 'IP6', m.group(3), m.group(4), m.group(5)
            n = LEN.search(rest)
            size = int(n.group(1)) if n else 0
            proto = 'tcp' if rest.startswith('tcp') else ('udp' if 'UDP' in rest[:5] else rest.split(' ', 1)[0].lower())
            sh, sp = split(src, v6)
            dh, dp = split(dst, v6)
            if sh in local:
                key, i = '%s %s %s' % (proto, dh, dp), 0      # отправлено с рига
            elif dh in local:
                key, i = '%s %s %s' % (proto, sh, sp), 1      # получено ригом
            else:
                key = None
            if key:
                if key not in stats and len(stats) >= LIMIT:
                    key = 'other - -'
                s = stats.setdefault(key, [0, 0, 0, 0, t, t])
                s[i] += size
                s[i + 2] += 1
                s[5] = t
        if time.monotonic() - last_save > 30:
            save()
            last_save = time.monotonic()
    save()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
