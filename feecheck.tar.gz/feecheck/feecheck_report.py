#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""feecheck: сколько работы майнер реально отдаёт чужому кошельку - по трафику с пулом, а не по его словам.

Читает записи tcpdump (порт пула, по умолчанию 5500, без шифрования), склеивает потоки TCP,
разбирает сообщения stratum и считает по каждому кошельку принятые пулом шары и их работу
(работа шары = 2^256 / цель задания). Доля чужих кошельков = настоящая комиссия.
Плюс: все адреса, к которым подключался процесс Nacreon (conns.log), и совпадает ли кошелёк
автора с отпечатком SHA-256, зашитым в бинарник.

Запуск: python3 -I feecheck_report.py /home/user/feecheck/data
Автор скрипта - alex_kodiaq (через Claude). Ничего не отправляет, только читает файлы.
"""
import glob, hashlib, json, math, os, pathlib, re, struct, sys

DECLARED = 0.008   # 0.8%, как пишет автор Nacreon 0.24.0
DEV_SHA256 = os.environ.get('FEECHECK_DEV_SHA256', '8887a213a378adfea13e6621c03a85bb9c6e9bc5d74c85986ad74bf379b3ad4e')  # из бинарника 0.24.0
PORTS = {int(x) for x in re.split(r'[\s,]+', os.environ.get('FEECHECK_PORT', '5500').strip()) if x.isdigit()}
SHARE_BYTES = 25800   # одна шара Pearl в stratum ~ 25,8 КБ (доказательство ~25,6 КБ + JSON)


# ---------------------------------------------------------------- pcap

def packets(path):
    """(time, src, sport, dst, dport, flags, seq, payload) из одного файла; обрыв в конце - не ошибка."""
    with open(path, 'rb') as f:
        head = f.read(24)
        if len(head) < 24:
            return
        magic = head[:4]
        if magic in (b'\xd4\xc3\xb2\xa1', b'\x4d\x3c\xb2\xa1'):
            e = '<'
        elif magic in (b'\xa1\xb2\xc3\xd4', b'\xa1\xb2\x3c\x4d'):
            e = '>'
        else:
            return
        nano = magic in (b'\x4d\x3c\xb2\xa1', b'\xa1\xb2\x3c\x4d')
        link = struct.unpack(e + 'I', head[20:24])[0]
        while True:
            rec = f.read(16)
            if len(rec) < 16:
                return
            sec, frac, incl, _ = struct.unpack(e + 'IIII', rec)
            data = f.read(incl)
            if len(data) < incl:
                return  # файл оборвался (свет)
            t = sec + frac / (1e9 if nano else 1e6)
            ip = None
            if link == 1:            # Ethernet
                off, proto = 14, data[12:14]
                while proto in (b'\x81\x00', b'\x88\xa8') and len(data) >= off + 4:
                    proto, off = data[off + 2:off + 4], off + 4
                ip = (proto, data[off:])
            elif link == 113:        # Linux cooked v1 (-i any)
                ip = (data[14:16], data[16:])
            elif link == 276:        # Linux cooked v2 (-i any)
                ip = (data[0:2], data[20:])
            elif link in (101, 12):  # raw IP
                ip = (b'\x86\xdd' if data[:1] and data[0] >> 4 == 6 else b'\x08\x00', data)
            elif link == 0:          # BSD loopback
                ip = (b'\x08\x00' if data[:4] in (b'\x02\x00\x00\x00', b'\x00\x00\x00\x02') else b'\x86\xdd', data[4:])
            if not ip:
                continue
            proto, pkt = ip
            if proto == b'\x08\x00' and len(pkt) >= 20 and pkt[9] == 6:
                ihl = (pkt[0] & 15) * 4
                total = struct.unpack('!H', pkt[2:4])[0]
                src, dst = '.'.join(map(str, pkt[12:16])), '.'.join(map(str, pkt[16:20]))
                tcp = pkt[ihl:total] if total else pkt[ihl:]
            elif proto == b'\x86\xdd' and len(pkt) >= 40 and pkt[6] == 6:
                plen = struct.unpack('!H', pkt[4:6])[0]
                src, dst = pkt[8:24].hex(), pkt[24:40].hex()
                tcp = pkt[40:40 + plen]
            else:
                continue
            if len(tcp) < 20:
                continue
            sport, dport, seq = struct.unpack('!HHI', tcp[:8])
            doff = (tcp[12] >> 4) * 4
            yield t, src, sport, dst, dport, tcp[13], seq, tcp[doff:]


class Flow:
    """Один направленный поток TCP -> готовые строки (stratum = JSON по строкам)."""

    def __init__(self):
        self.next = None
        self.pending = b''
        self.skip_first = False

    def feed(self, seq, data, syn):
        if syn:
            self.next = (seq + 1) & 0xffffffff
            self.pending, self.skip_first = b'', False
            return []
        if not data:
            return []
        if self.next is None:            # запись началась посреди соединения
            self.next, self.skip_first = seq, True
        off = (seq - self.next) & 0xffffffff
        if off >= 0x80000000:            # повтор уже полученного, возможно частично новый
            back = (self.next - seq) & 0xffffffff
            if back >= len(data):
                return []
            data, off = data[back:], 0
        if off > 0:                      # часть потока не записана (перезапуск записи, свет) - начинаем с этого места
            self.next, self.pending, self.skip_first = seq, b'', True
        self.pending += data
        self.next = (self.next + len(data)) & 0xffffffff
        *lines, self.pending = self.pending.split(b'\n')
        if self.skip_first and lines:
            lines, self.skip_first = lines[1:], False
        if len(self.pending) > 8 << 20:
            self.pending, self.skip_first = b'', True
        return lines


# ---------------------------------------------------------------- stratum

def login_of(params):
    if isinstance(params, dict):
        for k in ('wallet', 'login', 'user', 'username', 'address'):
            if isinstance(params.get(k), str):
                return params[k]
        return None
    if isinstance(params, list) and params and isinstance(params[0], str):
        return params[0]
    return None


def wallet_part(login):
    return re.split(r'[.+/:]', login, maxsplit=1)[0] if login else login


def target_of(params):
    t = None
    if isinstance(params, dict):
        t = params.get('target')
    elif isinstance(params, list):
        t = next((x for x in params if isinstance(x, str) and re.fullmatch(r'[0-9a-fA-F]{64}', x)), None)
    if isinstance(t, str) and re.fullmatch(r'[0-9a-fA-F]{8,64}', t):
        v = int(t, 16)
        return v if v > 0 else None
    return None


class Conn:
    def __init__(self, key):
        self.key = key            # (адрес рига, порт рига, адрес пула)
        self.logins = []          # входы (логины) на этом подключении
        self.jobs = {}            # job_id -> цель
        self.target = None        # последняя цель (если в задании её нет)
        self.wait = {}            # id отправки -> (кошелёк, работа)
        self.first = self.last = None


def private(ip):
    if ':' in ip:
        return ip.lower().startswith(('fe80', 'fc', 'fd', '::1'))
    a = [int(x) for x in ip.split('.')[:2]] if re.fullmatch(r'[\d.]+', ip) else [0, 0]
    return a[0] in (10, 127) or (a[0] == 172 and 16 <= a[1] <= 31) or (a[0] == 192 and a[1] == 168)


def traffic_table(data_dir, ends, mine):
    """Весь трафик рига по адресам: что и куда уходило, независимо от программы и шифрования."""
    path = data_dir / 'traffic.json'
    try:
        stats = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        print('')
        print('Итогов по всему трафику рига пока нет (traffic.json).')
        return
    by_ip = {}
    for key, (bo, bi, po, pi, first, last) in stats.items():
        proto, ip, port = (key.split(' ') + ['', '', ''])[:3]
        e = by_ip.setdefault(ip, dict(out=0, inn=0, ports={}))
        e['out'] += bo
        e['inn'] += bi
        e['ports'][proto + '/' + port] = e['ports'].get(proto + '/' + port, 0) + bo
    progs = {}
    try:
        for line in (data_dir / 'procs.log').read_text(errors='replace').splitlines():
            parts = line.split()
            if len(parts) >= 3:
                progs.setdefault(parts[1].rsplit(':', 1)[0].strip('[]'), set()).add(parts[2])
    except OSError:
        pass
    labels = {}
    for ep, e in ends.items():
        ip = ep.rsplit(':', 1)[0]
        labels[ip] = 'твой пул' if mine in e['wallets'] or (not e['wallets'] and ep.endswith(':3333')) else 'пул автора (записан)'
    import socket
    socket.setdefaulttimeout(2)
    print('')
    print('Весь трафик рига по адресам (больше всего отправлено сверху):')
    shown = 0
    for ip, e in sorted(by_ip.items(), key=lambda kv: -kv[1]['out']):
        if private(ip) or ip == '-':
            continue
        if shown >= 15:
            break
        shown += 1
        try:
            name = socket.gethostbyaddr(ip)[0]
        except (OSError, UnicodeError):
            name = ''
        ports = ', '.join(p for p, _ in sorted(e['ports'].items(), key=lambda x: -x[1])[:3])
        mark = labels.get(ip, '')
        who = ', '.join(sorted(progs.get(ip, ())))
        print('  %-16s отправлено %8.2f МБ, получено %8.2f МБ  [%s] %s%s%s' % (
            ip, e['out'] / 1e6, e['inn'] / 1e6, ports, name,
            (' · программа: ' + who) if who else '', (' - ' + mark) if mark else ''))
    print('  (локальная сеть не показана. К комиссии Nacreon относится только трафик программы nacreon-sm*;')
    print('   xmrig/cpuminer - твой XMR, его скрипт не считает и не трогает)')


def main():
    data_dir = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '/home/user/feecheck/data')
    files = sorted(glob.glob(str(data_dir / 'pool-*.pcap*')), key=lambda p: (os.path.getmtime(p), p))
    if not files:
        print('Нет записей в ' + str(data_dir) + ' - запись ещё не шла (feecheck.sh start).')
        return 2
    flows, conns = {}, {}
    ends = {}                     # адрес:порт на той стороне -> объём и сколько сообщений прочитано
    stats = {}                    # кошелёк -> счётчики
    span = [None, None]
    lost = 0

    def st(w):
        return stats.setdefault(w, dict(sent=0, ok=0, bad=0, work=0.0, known=0))

    for path in files:
        for t, src, sport, dst, dport, flags, seq, payload in packets(path):
            if sport not in PORTS and dport not in PORTS:
                continue
            span[0] = t if span[0] is None else min(span[0], t)
            span[1] = t if span[1] is None else max(span[1], t)
            up = dport in PORTS
            ckey = (src, sport, dst, dport) if up else (dst, dport, src, sport)
            fkey = (src, sport, dst, dport)
            end = ends.setdefault('%s:%d' % (ckey[2], ckey[3]), dict(up=0, down=0, msgs=0, conns=set(), wallets=set()))
            end['conns'].add(ckey[1])
            end['up' if up else 'down'] += len(payload)
            flow = flows.setdefault(fkey, Flow())
            conn = conns.setdefault(ckey, Conn(ckey))
            conn.first = t if conn.first is None else conn.first
            conn.last = t
            for line in flow.feed(seq, payload, bool(flags & 0x02)):
                if not line.strip():
                    continue
                try:
                    msg = json.loads(line)
                except ValueError:
                    lost += 1
                    continue
                if not isinstance(msg, dict):
                    continue
                end['msgs'] += 1
                method = msg.get('method')
                params = msg.get('params')
                if up:
                    if method in ('mining.authorize', 'login', 'mining.login', 'eth_submitLogin'):
                        lg = login_of(params)
                        if lg:
                            conn.logins.append(wallet_part(lg))
                    elif method == 'mining.submit':
                        who = login_of(params) if isinstance(params, dict) and any(
                            k in params for k in ('wallet', 'login', 'user', 'address')) else None
                        who = wallet_part(who) if who else (conn.logins[-1] if conn.logins else '(без входа)')
                        job = params.get('job_id') if isinstance(params, dict) else (params[1] if isinstance(params, list) and len(params) > 1 else None)
                        tgt = conn.jobs.get(job, conn.target)
                        work = (2 ** 256 / tgt) if tgt else None
                        st(who)['sent'] += 1
                        end['wallets'].add(who)
                        conn.wait[msg.get('id')] = (who, work)
                else:
                    if method == 'mining.notify':
                        tgt = target_of(params)
                        job = params.get('job_id') if isinstance(params, dict) else (params[0] if isinstance(params, list) and params else None)
                        if tgt:
                            conn.target = tgt
                            if job is not None:
                                conn.jobs[job] = tgt
                                if len(conn.jobs) > 5000:
                                    conn.jobs.pop(next(iter(conn.jobs)))
                    elif method == 'mining.set_difficulty' and isinstance(params, list) and params:
                        try:
                            d = float(params[0])
                            if d > 0:
                                conn.target = int(0xFFFF * 2 ** 208 / d)
                        except (TypeError, ValueError):
                            pass
                    elif method is None and msg.get('id') in conn.wait:
                        who, work = conn.wait.pop(msg.get('id'))
                        s = st(who)
                        if msg.get('result') is True and msg.get('error') in (None, False):
                            s['ok'] += 1
                            if work:
                                s['work'] += work
                                s['known'] += 1
                        else:
                            s['bad'] += 1

    hours = (span[1] - span[0]) / 3600 if span[0] is not None else 0
    print('Записей: %d файлов, %.1f МБ, охват %.1f ч (с перерывами на отключения)' % (
        len(files), sum(os.path.getsize(p) for p in files) / 1e6, hours))
    print('Записанные адреса (порты %s):' % ', '.join(map(str, sorted(PORTS))))
    for ep, e in sorted(ends.items(), key=lambda kv: -kv[1]['up']):
        line = '  %s: подключений %d, отправлено %.1f МБ, сообщений stratum %d' % (ep, len(e['conns']), e['up'] / 1e6, e['msgs'])
        if not e['msgs'] and e['up'] > SHARE_BYTES:
            line += ' - НЕ ЧИТАЕТСЯ (шифрование), по объёму это ~%d шар' % (e['up'] // SHARE_BYTES)
        print(line)
    multi = [c for c in conns.values() if len(set(c.logins)) > 1]
    if multi:
        print('  ! на %d подключениях входили под разными кошельками' % len(multi))

    if not stats:
        print('Шар пока нет - майнер ещё не работал под записью.')
        return 2
    mine = None
    try:
        blob = pathlib.Path('/run/nacreon/hive-args.conf').read_bytes().split(b'\0')
        if b'--wallet' in blob:
            mine = wallet_part(blob[blob.index(b'--wallet') + 1].decode('utf-8', 'replace'))
    except (OSError, IndexError):
        pass
    if mine not in stats:
        mine = max(stats, key=lambda w: stats[w]['ok'])
    print('')
    print('Кошельки, на которые майнер сдавал шары:')
    for w, s in sorted(stats.items(), key=lambda kv: -kv[1]['ok']):
        tag = 'твой' if w == mine else 'ЧУЖОЙ'
        sha = hashlib.sha256(w.encode('utf-8')).hexdigest() if w else ''
        dev = ' - это кошелёк автора из бинарника (SHA-256 совпадает)' if sha == DEV_SHA256 else ''
        short = (w[:12] + '…' + w[-6:]) if w and len(w) > 24 else w
        print('  %-5s %s: отправлено %d, принято %d, отказов %d%s' % (tag, short, s['sent'], s['ok'], s['bad'], dev))
    others = [w for w in stats if w != mine]
    if others and not any(hashlib.sha256(w.encode('utf-8')).hexdigest() == DEV_SHA256 for w in others):
        print('  ! чужой кошелёк не совпадает с отпечатком из бинарника')

    n_dev = sum(stats[w]['ok'] for w in others)
    n_all = sum(s['ok'] for s in stats.values())
    known = sum(s['known'] for s in stats.values())
    avg_all = (sum(s['work'] for s in stats.values()) / known) if known else 1.0

    def est(s):  # шары с неизвестной сложностью считаем по средней сложности этого кошелька
        per = s['work'] / s['known'] if s['known'] else avg_all
        return s['work'] + (s['ok'] - s['known']) * per
    total = sum(est(s) for s in stats.values())
    dev_work = sum(est(stats[w]) for w in others)
    print('')
    if not known:
        print('Сложность шар определить не удалось - считаю по количеству шар.')
    if total <= 0:
        print('Принятых шар пока нет.')
        return 2
    frac = dev_work / total
    # 95% интервал по числу чужих шар (Пуассон, приближение Уилсона-Хилферти)
    def lo(k):
        return 0.0 if k == 0 else k * (1 - 1 / (9 * k) - 1.96 / (3 * math.sqrt(k))) ** 3
    def hi(k):
        k += 1
        return k * (1 - 1 / (9 * k) + 1.96 / (3 * math.sqrt(k))) ** 3
    avg = (dev_work / n_dev) if n_dev else (total / n_all if n_all else 0)
    low, high = lo(n_dev) * avg / total, hi(n_dev) * avg / total
    print('Принято шар всего: %d, из них чужих: %d' % (n_all, n_dev))
    print('Доля работы на чужие кошельки: %.2f%%  (95%%: %.2f%% … %.2f%%)  заявлено: %.1f%%' % (
        frac * 100, low * 100, high * 100, DECLARED * 100))
    hidden = sum(e['up'] // SHARE_BYTES for e in ends.values() if not e['msgs'] and e['up'] > SHARE_BYTES)
    if hidden:
        print('По зашифрованным подключениям ушло ~%d шар - их кошелёк и сложность не видны.' % hidden)
        print('Оценка по КОЛИЧЕСТВУ шар (без учёта сложности): %.2f%%' % (100.0 * (n_dev + hidden) / (n_all + hidden)))
        verdict = 'ТОЧНО НЕ ПРОВЕРИТЬ - часть работы уходит по шифрованному каналу'
    elif low > DECLARED * 1.3:
        verdict = 'НЕ OK - майнер отдаёт заметно больше заявленных 0,8%'
    elif high <= DECLARED * 1.5 and low <= DECLARED * 1.3:
        verdict = 'OK - в пределах заявленных 0,8%'
    else:
        need = max(0, int(30 / DECLARED) - n_all)
        verdict = 'ПОКА НЕЯСНО - данных мало, копим дальше (нужно ещё примерно %d шар)' % need
    print('ИТОГ: ' + verdict)

    traffic_table(data_dir, ends, mine)

    conns_log = data_dir / 'conns.log'
    if conns_log.exists():
        seen = {}
        for line in conns_log.read_text(errors='replace').splitlines():
            parts = line.split()
            if len(parts) >= 2:
                seen[parts[1]] = seen.get(parts[1], 0) + 1
        foreign = {ep: n for ep, n in seen.items() if ep.rsplit(':', 1)[-1] not in {str(x) for x in PORTS}}
        print('')
        print('Куда подключался сам Nacreon (проверка раз в 10 с): ' + ', '.join(
            '%s (%d)' % (ep, n) for ep, n in sorted(seen.items(), key=lambda x: -x[1])[:6]))
        if foreign:
            print('  ! НЕ OK: есть подключения не к порту пула - их трафик в подсчёт не попал: ' + ', '.join(foreign))
    return 0


if __name__ == '__main__':
    sys.exit(main())
