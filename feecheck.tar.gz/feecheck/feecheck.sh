#!/bin/bash
# feecheck - проверка реальной комиссии Nacreon по трафику с пулом (alex_kodiaq).
#   bash feecheck.sh start 3333 7048   записывать эти порты (по умолчанию 5500) и включаться после света
#   bash feecheck.sh report   посчитать по всему, что уже записано
#   bash feecheck.sh status   идёт ли запись, сколько набралось
#   bash feecheck.sh stop     выключить запись и автозапуск (записи остаются)
#   bash feecheck.sh clean    удалить записи
# Пишет только трафик порта пула и список подключений процесса Nacreon. Ничего никуда не отправляет.
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA="$DIR/data"
PORT="$(cat "$DIR/port" 2>/dev/null || echo 5500)"
FILTER="tcp and ($(echo $PORT | sed 's/\([0-9]*\)/port \1/g; s/ port/ or port/g'))"
UNIT=/etc/systemd/system/feecheck.service

case "$1" in
run)    # вызывается службой
    mkdir -p "$DATA"
    ( while :; do
        t=$(date +%s)
        ss -tnp 2>/dev/null | grep 'nacreon-sm' | awk -v t="$t" '{print t, $5}' >> "$DATA/conns.log"
        sleep 10
      done ) &
    exec tcpdump -i any -s 0 -nn -U -Z root -C 50 -w "$DATA/pool-$(date +%Y%m%d-%H%M%S).pcap" "$FILTER"
    ;;
start)
    if [[ -n "$2" ]]; then
        shift
        for p in "$@"; do [[ "$p" =~ ^[0-9]+$ ]] || { echo "Порты - числа через пробел, например: start 3333 7048"; exit 1; }; done
        echo "$*" > "$DIR/port"; PORT="$*"
        systemctl restart feecheck >/dev/null 2>&1
    fi
    if ! command -v tcpdump >/dev/null; then
        apt-get install -y tcpdump >/dev/null 2>&1 || { apt-get update >/dev/null 2>&1; apt-get install -y tcpdump; }
    fi
    command -v tcpdump >/dev/null || { echo "Не удалось поставить tcpdump"; exit 1; }
    cat > "$UNIT" <<EOF
[Unit]
Description=Nacreon fee check (pool traffic capture)
After=network-online.target

[Service]
ExecStart=/bin/bash $DIR/feecheck.sh run
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload && systemctl enable --now feecheck >/dev/null 2>&1
    sleep 2
    systemctl is-active --quiet feecheck && echo "Запись идёт (порты: $PORT). После отключения света включится сама." || echo "Служба не запустилась: systemctl status feecheck"
    ;;
stop)
    systemctl disable --now feecheck >/dev/null 2>&1
    rm -f "$UNIT"; systemctl daemon-reload
    echo "Запись выключена, автозапуск убран. Записи остались в $DATA"
    ;;
status)
    systemctl is-active --quiet feecheck && echo "Запись: идёт, порты: $PORT" || echo "Запись: не идёт"
    du -sh "$DATA" 2>/dev/null
    ;;
report)
    FEECHECK_PORT="$PORT" python3 -I "$DIR/feecheck_report.py" "$DATA"
    ;;
clean)
    systemctl is-active --quiet feecheck && { echo "Сначала: bash $DIR/feecheck.sh stop"; exit 1; }
    rm -rf "$DATA"; echo "Записи удалены"
    ;;
*)
    sed -n '2,8p' "$0"
    ;;
esac
